"""
CTE builder for retrieve optimization.

This module creates retrieve CTEs with precomputed columns.
"""

from __future__ import annotations

import logging
from typing import Dict, List, Optional, Set, Tuple, TYPE_CHECKING

logger = logging.getLogger(__name__)

from ..errors import TranslationError
from .types import (
    SQLSelect,
    SQLIdentifier,
    SQLLiteral,
    SQLBinaryOp,
    SQLCase,
    SQLUnaryOp,
    SQLCast,
    SQLFunctionCall,
    SQLAlias,
    SQLQualifiedIdentifier,
    SQLRaw,
    SQLNull,
    SQLExists,
    SQLSubquery,
    SQLEvidenceItem,
)
from .column_registry import ColumnInfo
from .profile_registry import ProfileRegistry
from .column_generation import (
    ColumnDefinition,
    build_column_definitions,
    property_to_column_name,
    infer_fhirpath_function,
    infer_sql_type_from_function,
    is_choice_type_column,
)
from .temporal_fields import (
    TEMPORAL_CHOICE_PATHS,
    TEMPORAL_CHOICE_SUFFIXES,
    TEMPORAL_FHIR_TYPES,
)
from .fhirpath_builder import escape_fhirpath_string_literal

if TYPE_CHECKING:
    from .context import SQLTranslationContext


def _build_column_value_expression(col_def: ColumnDefinition):
    """Build the SQL value expression for a ColumnDefinition."""
    path_exprs = [
        SQLFunctionCall(
            name=col_def.fhirpath_function,
            args=[
                SQLQualifiedIdentifier(parts=["r", "resource"]),
                SQLLiteral(value=path)
            ],
        )
        for path in col_def.paths
    ]
    if len(path_exprs) == 1:
        return path_exprs[0]
    return SQLFunctionCall(name="COALESCE", args=path_exprs)


def _build_column_expression(col_def: ColumnDefinition) -> SQLAlias:
    """Build SQL expression for a ColumnDefinition."""
    return SQLAlias(
        expr=_build_column_value_expression(col_def),
        alias=col_def.column_name,
    )


def _temporal_bound_expression(expr, boundary_func: str):
    """Build a nullable temporal-bound expression from a scalar or interval value."""
    value = SQLCast(expression=expr, target_type="VARCHAR")
    return SQLCase(
        when_clauses=[
            (
                SQLBinaryOp(operator="IS", left=expr, right=SQLNull()),
                SQLNull(),
            ),
            (
                SQLFunctionCall(
                    name="starts_with",
                    args=[
                        SQLFunctionCall(name="LTRIM", args=[value]),
                        SQLLiteral(value="{"),
                    ],
                ),
                SQLFunctionCall(name=boundary_func, args=[expr]),
            ),
        ],
        else_clause=value,
    )


def _is_simple_fhir_field_path(path: str) -> bool:
    """Return true for plain dotted element paths that map directly to JSON fields."""
    return bool(path) and all(part.isidentifier() for part in path.split("."))


def _schema_element_for_path(fhir_schema, resource_type: str, element_path: str):
    """Return the schema element for an exact or concrete choice element path."""
    resource = fhir_schema.resources.get(resource_type)
    if not resource:
        return None

    element = resource.elements.get(f"{resource_type}.{element_path}")
    if element is not None:
        return element

    for choice_name in resource.choice_elements:
        if element_path.startswith(choice_name) and len(element_path) > len(choice_name):
            return resource.elements.get(f"{resource_type}.{choice_name}[x]")
    return None


def _can_extract_period_bound_from_json(
    resource_type: str,
    path: str,
    fhir_schema,
) -> bool:
    """Return true when a Period path can be read by scalar JSON field traversal."""
    if (
        fhir_schema.get_element_type(resource_type, path) != "Period"
        or not _is_simple_fhir_field_path(path)
    ):
        return False

    parts = path.split(".")
    for index in range(1, len(parts) + 1):
        prefix = ".".join(parts[:index])
        element = _schema_element_for_path(fhir_schema, resource_type, prefix)
        if element is None:
            return False
        if element.cardinality and element.cardinality.endswith("*"):
            return False
    return True


def _can_extract_temporal_scalar_from_json(
    resource_type: str,
    path: str,
    fhir_schema,
) -> bool:
    """Return true when a scalar temporal path can be read by JSON traversal."""
    if (
        fhir_schema.get_element_type(resource_type, path) not in {"dateTime", "date", "instant"}
        or not _is_simple_fhir_field_path(path)
    ):
        return False

    parts = path.split(".")
    for index in range(1, len(parts) + 1):
        prefix = ".".join(parts[:index])
        element = _schema_element_for_path(fhir_schema, resource_type, prefix)
        if element is None:
            return False
        if element.cardinality and element.cardinality.endswith("*"):
            return False
    return True


def _temporal_json_bound_expression(
    resource_type: str,
    path: str,
    fhir_schema,
    suffix: str,
):
    """Build a direct JSON extraction for a temporal scalar or Period bound."""
    if _can_extract_period_bound_from_json(resource_type, path, fhir_schema):
        json_path = f"$.{path}.{suffix}"
    elif _can_extract_temporal_scalar_from_json(resource_type, path, fhir_schema):
        json_path = f"$.{path}"
    else:
        return None

    return SQLFunctionCall(
        name="json_extract_string",
        args=[
            SQLQualifiedIdentifier(parts=["r", "resource"]),
            SQLLiteral(value=json_path),
        ],
    )


def _build_period_bound_expression(
    resource_type: str,
    col_def: ColumnDefinition,
    fhir_schema,
    suffix: str,
    fallback_boundary_func: str,
):
    """Build a reusable Period start/end expression for a precomputed column."""
    json_extracts = []
    for path in col_def.paths:
        bound_expr = _temporal_json_bound_expression(resource_type, path, fhir_schema, suffix)
        if bound_expr is not None:
            json_extracts.append(bound_expr)
            continue

        resource = fhir_schema.resources.get(resource_type)
        if resource and path in resource.choice_elements:
            for choice_suffix in TEMPORAL_CHOICE_SUFFIXES:
                bound_expr = _temporal_json_bound_expression(
                    resource_type,
                    f"{path}{choice_suffix}",
                    fhir_schema,
                    suffix,
                )
                if bound_expr is not None:
                    json_extracts.append(bound_expr)
    if len(json_extracts) == 1:
        return json_extracts[0]
    if len(json_extracts) > 1:
        return SQLFunctionCall(name="COALESCE", args=json_extracts)

    return _temporal_bound_expression(
        _build_column_value_expression(col_def),
        fallback_boundary_func,
    )


def _is_temporal_bound_column(
    resource_type: str,
    col_def: ColumnDefinition,
    fhir_schema,
) -> bool:
    """Return true when a precomputed property can expose temporal bounds."""
    resource = fhir_schema.resources.get(resource_type)
    for path in col_def.paths:
        if fhir_schema.get_element_type(resource_type, path) in TEMPORAL_FHIR_TYPES:
            return True
        if resource and path in TEMPORAL_CHOICE_PATHS and path in resource.choice_elements:
            for suffix in TEMPORAL_CHOICE_SUFFIXES:
                if fhir_schema.get_element_type(resource_type, f"{path}{suffix}") in TEMPORAL_FHIR_TYPES:
                    return True
    return False


def _resolve_profile_registry(context) -> "ProfileRegistry":
    """Resolve profile registry from context.

    The context is guaranteed to have a profile_registry after __post_init__
    (Context SSOT invariant). This helper handles the Optional[context] case
    for functions that accept context=None.
    """
    if context is not None and context.profile_registry is not None:
        return context.profile_registry
    # Only reachable when called without a context (e.g., standalone utility use).
    logger.warning(
        "CTE builder called without context.profile_registry; "
        "falling back to default. Fix the call site to pass context."
    )
    from .profile_registry import get_default_profile_registry
    return get_default_profile_registry()


# ---------------------------------------------------------------------------
# CQL 2.0 multi-filter retrieve (FHIR-31397) encoding
#
# Additional comma-separated retrieve filters are carried on the retrieve
# valueset string (the same carrier doctrine as the '~' equivalent-terminology
# marker) so retrieve keys, CTE grouping, and the provisional-name resolver
# distinguish filtered retrieves without changing the 3-tuple key shape.
#
# Encoding:  "<base-valueset>|@<prop>|@<kind>|@<target>" (repeated), where
# kind is one of: 'in' (exact ValueSet membership), '~in' (equivalent
# membership), 'code' (exact direct-code), '~code' (equivalent direct-code).
# ---------------------------------------------------------------------------

_MF_MARKER = "|@"


def encode_retrieve_filter(prop: str, kind: str, target: str) -> str:
    """Encode one additional retrieve filter onto the valueset string."""
    return f"{_MF_MARKER}{prop}{_MF_MARKER}{kind}{_MF_MARKER}{target}"


def decode_retrieve_filters(valueset: Optional[str]) -> tuple:
    """Split a (possibly filter-encoded) valueset string.

    Returns (base_valueset, [(prop, kind, target), ...]).
    """
    if not valueset or _MF_MARKER not in valueset:
        return valueset, []
    base, _, rest = valueset.partition(_MF_MARKER)
    filters = []
    # Each filter is three _MF_MARKER-separated fields; filters concatenate.
    parts = rest.split(_MF_MARKER)
    while len(parts) >= 3:
        prop, kind, target = parts[0], parts[1], parts[2]
        parts = parts[3:]
        filters.append((prop, kind, target))
    if parts:
        # Malformed trailing fragment — treat as part of the base to stay
        # row-resilient (defensive; the translator only writes well-formed
        # encodings).
        base = base + _MF_MARKER + _MF_MARKER.join(parts)
    return base, filters


def _multi_filter_label(filters: list) -> str:
    """Distinguishing CTE-name suffix for a multi-filter retrieve."""
    props = ", ".join(p for p, _, _ in filters)
    return f"[{props}]"


def build_retrieve_cte(
    resource_type: str,
    valueset: Optional[str],
    properties: Set[str],
    context: Optional[SQLTranslationContext] = None,
    profile_url: Optional[str] = None,
    profile_urls: Optional[List[str]] = None,
    code_property: Optional[str] = None,
) -> Tuple[str, SQLSelect, Dict[str, ColumnInfo]]:
    """
    Build a retrieve CTE with precomputed columns.

    Creates SQL like:
        "Condition: Essential Hypertension" AS (
            SELECT DISTINCT
                r.patient_ref AS patient_id,
                r.resource,
                fhirpath_date(r.resource, 'onsetDateTime') AS onset_date,
                fhirpath_text(r.resource, 'verificationStatus.coding.code') AS verification_status
            FROM resources r
            WHERE r.resourceType = 'Condition'
              AND in_valueset(r.resource, 'code', 'http://...')
        )

    Multiple QICore profiles (e.g., ConditionEncounterDiagnosis vs ConditionProblemsHealthConcerns)
    that map to the same FHIR resource type and valueset are deduplicated into a single CTE.
    Profile-specific precomputed columns from all profiles are merged.

    Args:
        resource_type: FHIR resource type (e.g., "Condition")
        valueset: ValueSet URL or name (None for unfiltered retrieve)
        properties: Set of property paths to precompute
        context: Translation context for valueset resolution
        profile_url: Optional single FHIR profile URL (for backward compatibility)
        profile_urls: Optional list of all FHIR profile URLs to merge columns from

    Returns:
        Tuple of (cte_name, cte_ast, column_info_map)
    """
    # CQL 2.0 equivalent-terminology retrieves (FHIR-31392/31675:
    # `[X: code ~in "VS"]`, `[X: path ~contains "Code"]`) arrive with a
    # leading '~' marker on the valueset string so retrieve keys and CTE
    # names distinguish them from the exact-match (1.5 `in`) retrieve on
    # the same terminology. Strip it here and select equivalence-based
    # membership semantics.
    equivalent_terminology = bool(valueset) and valueset.startswith("~")
    if equivalent_terminology:
        valueset = valueset[1:]
    # CQL 2.0 multi-filter retrieves (FHIR-31397): additional
    # comma-separated filters arrive encoded on the valueset string; decode
    # them here so name derivation and terminology filtering see the base
    # valueset and the filters become ANDed WHERE predicates.
    valueset, additional_filters = decode_retrieve_filters(valueset)
    # (debug removed)
    # Normalize profile_urls: merge single profile_url into the list
    all_profile_urls: List[str] = []
    if profile_urls:
        all_profile_urls = list(profile_urls)
    elif profile_url:
        all_profile_urls = [profile_url]

    # Debug logging for CTE building
    logger.debug(
        f"Building CTE for resource_type={resource_type}, valueset={valueset}, profiles={all_profile_urls}"
    )

    # Generate CTE name.
    # Negation profiles (MedicationNotRequested, ProcedureNotDone, etc.)
    # need separate CTEs since they have different WHERE clauses.
    #
    # _valueset_friendly_label holds the best human-readable label for the valueset
    # (CQL alias name > code display name > URL suffix).  Used both for the CTE
    # name and for the _audit_item "threshold" field.
    _valueset_friendly_label: "Optional[str]" = None
    if valueset:
        # Try to get friendly name from context
        valueset_name = None
        if context and hasattr(context, 'valuesets'):
            for name, url in context.valuesets.items():
                if url == valueset:
                    valueset_name = name
                    break

        if valueset_name:
            cte_name = f"{resource_type}: {valueset_name}"
            _valueset_friendly_label = valueset_name
            logger.debug(f"  Found valueset name '{valueset_name}' for URL '{valueset}'")
        elif valueset.startswith("urn:cql:code:") and context and hasattr(context, 'codes'):
            # Code-based retrieve: look up the code's display name
            code_display = None
            for code_name, code_info in context.codes.items():
                cs_name = code_info.get("codesystem", "")
                cs_url = context.codesystems.get(cs_name, cs_name) if hasattr(context, 'codesystems') else cs_name
                code_val = code_info.get("code", "")
                if valueset == f"urn:cql:code:{cs_url}|{code_val}":
                    code_display = code_name
                    break
            _valueset_friendly_label = code_display or valueset.split('|')[-1]
            cte_name = f"{resource_type}: {_valueset_friendly_label}"
        else:
            # Use resource type + truncated URL
            cte_name = f"{resource_type}: {valueset.split('/')[-1]}"
            logger.debug(f"  No valueset name found, using URL suffix")

        # Only add profile suffix for profiles that actually change the SQL output
        # (e.g., us-core-blood-pressure adds component columns).
        # Condition profiles (encounter vs problems) map to the same FHIR Condition
        # with identical SQL, so no suffix is needed.
        _profile_registry = _resolve_profile_registry(context)
        profile_suffix = _get_distinguishing_profile_suffix(all_profile_urls, profile_registry=_profile_registry)
        if not profile_suffix:
            # Check for negation profile suffix via registry
            for _url in all_profile_urls:
                if _url:
                    neg_suffix = _profile_registry.get_suffix(_url)
                    if neg_suffix:
                        profile_suffix = neg_suffix
                        break
        if profile_suffix:
            cte_name = f"{cte_name} ({profile_suffix})"
    else:
        cte_name = resource_type
        _profile_registry = _resolve_profile_registry(context)
        profile_suffix = _get_distinguishing_profile_suffix(all_profile_urls, profile_registry=_profile_registry)
        if profile_suffix:
            cte_name = f"{cte_name} ({profile_suffix})"
    if equivalent_terminology:
        # Distinct CTE name so an exact-match retrieve on the same
        # terminology does not collide with the equivalence variant.
        cte_name = f"{cte_name} (equiv)"
    if additional_filters:
        # Distinct CTE name so retrieves that differ only in additional
        # filters (FHIR-31397) do not collide.
        cte_name = f"{cte_name} {_multi_filter_label(additional_filters)}"

    logger.debug(f"  Generated CTE name: {cte_name}")

    # Build column list
    columns = [
        # Always include these base columns
        SQLAlias(
            expr=SQLQualifiedIdentifier(parts=["r", "patient_ref"]),
            alias="patient_id"
        ),
        SQLQualifiedIdentifier(parts=["r", "resource"]),
    ]

    # Track column info for registry
    column_info_map: Dict[str, ColumnInfo] = {}

    # Gap 6: Filter properties to only those valid for this resource type
    # Uses schema-driven validation (always available)
    fhir_schema = (context.fhir_schema if context else None)
    column_mappings = (context.column_mappings if context else None)
    choice_type_prefixes = (context.choice_type_prefixes if context else None)
    if fhir_schema is None:
        raise RuntimeError(
            "SQLTranslationContext.fhir_schema is required for build_retrieve_cte. "
            "Ensure the translator wires fhir_schema into the context."
        )
    properties = set(properties) | fhir_schema.default_precomputed_paths
    filtered_properties = set()
    for prop in properties:
        col_name = property_to_column_name(
            prop, resource_type=resource_type,
            fhir_schema=fhir_schema, column_mappings=column_mappings,
        )
        if fhir_schema.is_valid_precomputed_column(resource_type, col_name):
            filtered_properties.add(prop)
    properties = filtered_properties

    # Build column definitions using schema-aware helper
    column_defs = build_column_definitions(
        resource_type, properties, fhir_schema=fhir_schema,
        column_mappings=column_mappings, choice_type_prefixes=choice_type_prefixes,
    )
    generated_paths: Set[str] = set()
    for col_name in sorted(column_defs):
        col_def = column_defs[col_name]
        col_value_expr = _build_column_value_expression(col_def)
        col_expr = SQLAlias(expr=col_value_expr, alias=col_def.column_name)
        columns.append(col_expr)
        column_info_map[col_name] = ColumnInfo(
            column_name=col_name,
            fhirpath=", ".join(col_def.paths),
            sql_type=col_def.sql_type,
            is_choice_type=col_def.is_choice_type,
        )
        if _is_temporal_bound_column(resource_type, col_def, fhir_schema):
            for suffix, boundary_func in (("start", "intervalStart"), ("end", "intervalEnd")):
                bound_col_name = f"{col_name}_{suffix}"
                if bound_col_name in column_info_map:
                    continue
                columns.append(SQLAlias(
                    expr=_build_period_bound_expression(
                        resource_type,
                        col_def,
                        fhir_schema,
                        suffix,
                        boundary_func,
                    ),
                    alias=bound_col_name,
                ))
                column_info_map[bound_col_name] = ColumnInfo(
                    column_name=bound_col_name,
                    fhirpath=f"{', '.join(col_def.paths)}.{suffix}",
                    sql_type="VARCHAR",
                    is_choice_type=False,
                )
        generated_paths.update(col_def.paths)

    # Fallback: ensure every requested property has a column
    for prop in sorted(properties):
        if prop in generated_paths:
            continue
        col_name = property_to_column_name(
            prop, resource_type=resource_type,
            fhir_schema=fhir_schema, column_mappings=column_mappings,
        )
        if col_name in column_info_map:
            continue
        if prop.count('.') == 1:
            col_ast = SQLFunctionCall(
                name="json_extract_string",
                args=[
                    SQLQualifiedIdentifier(parts=["r", "resource"]),
                    SQLLiteral(value=f"$.{prop}"),
                ],
            )
        else:
            fhirpath_func = infer_fhirpath_function(prop, resource_type=resource_type, fhir_schema=fhir_schema)
            col_ast = SQLFunctionCall(
                name=fhirpath_func,
                args=[
                    SQLQualifiedIdentifier(parts=["r", "resource"]),
                    SQLLiteral(value=prop),
                ],
            )
        columns.append(SQLAlias(expr=col_ast, alias=col_name))
        column_info_map[col_name] = ColumnInfo(
            column_name=col_name,
            fhirpath=prop,
            sql_type=infer_sql_type_from_function(col_ast.name),
            is_choice_type=is_choice_type_column(
                col_name, choice_type_prefixes=choice_type_prefixes,
            ),
        )

    # Gap 16: Add property chain columns for deep paths (2+ dots)
    for prop in sorted(properties):
        if "." not in prop:
            continue
        col_name = property_to_column_name(
            prop, resource_type=resource_type,
            fhir_schema=fhir_schema, column_mappings=column_mappings,
        )
        if col_name in column_info_map:
            continue
        if prop.count(".") == 1:
            chain_ast = SQLFunctionCall(
                name="json_extract_string",
                args=[
                    SQLQualifiedIdentifier(parts=["r", "resource"]),
                    SQLLiteral(value=f"$.{prop}"),
                ],
            )
        else:
            fhirpath_func = infer_fhirpath_function(prop, resource_type=resource_type, fhir_schema=fhir_schema)
            chain_ast = SQLFunctionCall(
                name=fhirpath_func,
                args=[
                    SQLQualifiedIdentifier(parts=["r", "resource"]),
                    SQLLiteral(value=prop),
                ],
            )
        columns.append(SQLAlias(expr=chain_ast, alias=col_name))
        column_info_map[col_name] = ColumnInfo(
            column_name=col_name,
            fhirpath=prop,
            sql_type=infer_sql_type_from_function(chain_ast.name),
            is_choice_type=is_choice_type_column(col_name),
        )

    # Build WHERE clause
    where_conditions = [
        # Filter by resource type
        SQLBinaryOp(
            operator="=",
            left=SQLQualifiedIdentifier(parts=["r", "resourceType"]),
            right=SQLLiteral(resource_type)
        )
    ]

    # Add valueset filter if present
    if valueset:
        if valueset.startswith("urn:cql:code:"):
            # Direct code reference: urn:cql:code:<system>|<code>
            parts = valueset[len("urn:cql:code:"):].split("|", 1)
            system_url = parts[0] if len(parts) > 0 else ""
            code_val = parts[1] if len(parts) > 1 else ""
            from ..translator.patterns.retrieve import _TERMINOLOGY_PROPERTY_DEFAULTS
            effective_code_property = code_property or _TERMINOLOGY_PROPERTY_DEFAULTS.get(resource_type, "code")
            escaped_system = escape_fhirpath_string_literal(system_url)
            escaped_code = escape_fhirpath_string_literal(code_val)
            if equivalent_terminology:
                # CQL 2.0 retrieve `~contains` comparator (FHIR-31392): the
                # element at the code path equivalently-contains the declared
                # code — Code `~` semantics. FHIRPath `~` is String
                # equivalence (case-insensitive, whitespace-normalized) in
                # both the native and fallback FHIRPath engines (FP-13
                # doctrine), matching CQL Code equivalence on the
                # code/system elements.
                fhirpath_expr = (
                    f"{effective_code_property}.coding.where(system ~ '{escaped_system}' "
                    f"and code ~ '{escaped_code}').exists()"
                )
            else:
                fhirpath_expr = f"{effective_code_property}.coding.where(system='{escaped_system}' and code='{escaped_code}').exists()"
            where_conditions.append(
                SQLFunctionCall(
                    name="fhirpath_bool",
                    args=[
                        SQLQualifiedIdentifier(parts=["r", "resource"]),
                        SQLLiteral(fhirpath_expr),
                    ]
                )
            )
        else:
            # Use resource-type-specific code property path
            from ..translator.patterns.retrieve import _TERMINOLOGY_PROPERTY_DEFAULTS, _MEDICATION_REFERENCE_ALTERNATIVES
            effective_code_property = code_property or _TERMINOLOGY_PROPERTY_DEFAULTS.get(resource_type, "code")
            # CQL 2.0 retrieve `~in` comparator (FHIR-31675): equivalent-based
            # ValueSet membership on the code path (Code `~` semantics) vs
            # the exact-match in_valueset surface of the 1.5 `in` retrieve.
            membership_udf = "cql_equivalent_in_valueset" if equivalent_terminology else "in_valueset"
            primary_check = SQLFunctionCall(
                name=membership_udf,
                args=[
                    SQLQualifiedIdentifier(parts=["r", "resource"]),
                    SQLLiteral(effective_code_property),
                    SQLLiteral(valueset)
                ]
            )
            # For medication[x] choice types, also check medicationReference
            med_ref_alt = _MEDICATION_REFERENCE_ALTERNATIVES.get(resource_type)
            if med_ref_alt and not code_property:
                ref_prop = med_ref_alt["reference_property"]
                target_type = med_ref_alt["target_type"]
                target_code = med_ref_alt["target_code_property"]
                # Match: fhirpath_text(r.resource, 'medicationReference.reference') ends with Medication.id
                # Use direct JSON extraction for the target resource id.
                ref_id_expr = SQLFunctionCall(
                    name="LIST_EXTRACT",
                    args=[
                        SQLFunctionCall(
                            name="STR_SPLIT",
                            args=[
                                SQLFunctionCall(
                                    name="fhirpath_text",
                                    args=[
                                        SQLQualifiedIdentifier(parts=["r", "resource"]),
                                        SQLLiteral(f"{ref_prop}.reference"),
                                    ]
                                ),
                                SQLLiteral("/"),
                            ]
                        ),
                        SQLRaw("-1"),
                    ]
                )
                ref_check = SQLExists(
                    subquery=SQLSubquery(
                        query=SQLSelect(
                            columns=[SQLLiteral("1")],
                            from_clause=SQLAlias(
                                expr=SQLIdentifier(name="resources"),
                                alias="m"
                            ),
                            where=SQLBinaryOp(
                                operator="AND",
                                left=SQLBinaryOp(
                                    operator="AND",
                                    left=SQLBinaryOp(
                                        operator="=",
                                        left=SQLQualifiedIdentifier(parts=["m", "resourceType"]),
                                        right=SQLLiteral(target_type)
                                    ),
                                    right=SQLBinaryOp(
                                        operator="=",
                                        left=ref_id_expr,
                                        right=SQLFunctionCall(
                                            name="json_extract_string",
                                            args=[
                                                SQLQualifiedIdentifier(parts=["m", "resource"]),
                                                SQLLiteral("$.id"),
                                            ]
                                        )
                                    )
                                ),
                                right=SQLFunctionCall(
                                    name=membership_udf,
                                    args=[
                                        SQLQualifiedIdentifier(parts=["m", "resource"]),
                                        SQLLiteral(target_code),
                                        SQLLiteral(valueset)
                                    ]
                                )
                            )
                        )
                    )
                )
                where_conditions.append(
                    SQLBinaryOp(
                        operator="OR",
                        left=primary_check,
                        right=ref_check,
                    )
                )
            else:
                where_conditions.append(primary_check)

    # CQL 2.0 multi-filter retrieves (FHIR-31397): additional
    # comma-separated filters are ANDed into the retrieve predicate.
    for _mf_prop, _mf_kind, _mf_target in additional_filters:
        if _mf_kind == "in":
            where_conditions.append(
                SQLFunctionCall(
                    name="in_valueset",
                    args=[
                        SQLQualifiedIdentifier(parts=["r", "resource"]),
                        SQLLiteral(_mf_prop),
                        SQLLiteral(_mf_target),
                    ],
                )
            )
        elif _mf_kind == "~in":
            where_conditions.append(
                SQLFunctionCall(
                    name="cql_equivalent_in_valueset",
                    args=[
                        SQLQualifiedIdentifier(parts=["r", "resource"]),
                        SQLLiteral(_mf_prop),
                        SQLLiteral(_mf_target),
                    ],
                )
            )
        else:
            # Direct-code kinds ('code' exact / '~code' equivalent): mirror
            # the primary urn:cql:code surface — a coding.where membership
            # test on the filter's property path.
            if not _mf_target.startswith("urn:cql:code:"):
                raise TranslationError(
                    f"Retrieve additional filter on '{_mf_prop}' requires a "
                    f"declared code or value set reference; got '{_mf_target}'."
                )
            _mf_system, _, _mf_code = _mf_target[len("urn:cql:code:"):].partition("|")
            _eq = "~" if _mf_kind == "~code" else "="
            _mf_expr = (
                f"{_mf_prop}.coding.where(system {_eq} "
                f"'{escape_fhirpath_string_literal(_mf_system)}' and code {_eq} "
                f"'{escape_fhirpath_string_literal(_mf_code)}').exists()"
            )
            where_conditions.append(
                SQLFunctionCall(
                    name="fhirpath_bool",
                    args=[
                        SQLQualifiedIdentifier(parts=["r", "resource"]),
                        SQLLiteral(_mf_expr),
                    ],
                )
            )

    # Add negation filter for negation profiles (e.g., MedicationNotRequested)
    _registry = _resolve_profile_registry(context)
    _negation_filter = None
    _is_negation = False
    for _np_name, _np_info in _registry._named_profiles.items():
        _np_urls = [_np_info.get("url")] + list(_np_info.get("alternate_urls") or [])
        if any(u in all_profile_urls for u in _np_urls if u) and "negation_filter" in _np_info:
            _negation_filter = _np_info["negation_filter"]
            _is_negation = True
            break

    if _negation_filter == "doNotPerform":
        where_conditions.append(
            SQLFunctionCall(
                name="fhirpath_bool",
                args=[
                    SQLQualifiedIdentifier(parts=["r", "resource"]),
                    SQLLiteral("doNotPerform"),
                ]
            )
        )
    elif _negation_filter == "status_not_done":
        where_conditions.append(
            SQLBinaryOp(
                operator="=",
                left=SQLFunctionCall(
                    name="fhirpath_text",
                    args=[
                        SQLQualifiedIdentifier(parts=["r", "resource"]),
                        SQLLiteral("status"),
                    ],
                ),
                right=SQLLiteral("not-done"),
            )
        )
    elif _negation_filter == "status_cancelled":
        where_conditions.append(
            SQLBinaryOp(
                operator="=",
                left=SQLFunctionCall(
                    name="fhirpath_text",
                    args=[
                        SQLQualifiedIdentifier(parts=["r", "resource"]),
                        SQLLiteral("status"),
                    ],
                ),
                right=SQLLiteral("cancelled"),
            )
        )
    elif not _is_negation:
        # For base type retrieves, exclude negated resources if a negation subtype exists.
        # We use the profile URL as the canonical discriminator: if a resource declares
        # the negation profile (e.g. qicore-servicenotrequested), exclude it.
        # We do NOT filter on doNotPerform here because QI-Core allows
        # doNotPerform=true on the base profile (e.g. qicore-servicerequest) — it's
        # a data property that CQL authors can filter on explicitly, not a
        # classification property for retrieve semantics.
        for _np_name, _np_info in _registry._named_profiles.items():
            if _np_info.get("base_type") == resource_type and "negation_filter" in _np_info:
                neg_type = _np_info["negation_filter"]
                if neg_type == "status_not_done":
                    # status=not-done is a reliable classification signal even without
                    # profile metadata, so keep it as an exclusion filter.
                    where_conditions.append(
                        SQLBinaryOp(
                            operator="OR",
                            left=SQLBinaryOp(
                                operator="IS",
                                left=SQLFunctionCall(
                                    name="fhirpath_text",
                                    args=[SQLQualifiedIdentifier(parts=["r", "resource"]), SQLLiteral("status")],
                                ),
                                right=SQLNull(),
                            ),
                            right=SQLBinaryOp(
                                operator="!=",
                                left=SQLFunctionCall(
                                    name="fhirpath_text",
                                    args=[SQLQualifiedIdentifier(parts=["r", "resource"]), SQLLiteral("status")],
                                ),
                                right=SQLLiteral(value="not-done"),
                            ),
                        )
                    )

                # Exclude resources that declare the negation profile URL.
                # Alternate-aware: a named negation profile carries a primary
                # URL (typically the QI-Core canonical) plus registry
                # alternates (the US Quality Core canonical used by the CMS
                # 2025 fixtures). Matching only the primary left USQC-declared
                # negation resources (e.g. us-quality-core-servicenotrequested)
                # visible to POSITIVE base-type retrieves (CMS645 d07cf359
                # counted a doNotPerform DEXA order as a real order).
                neg_profile_url = _np_info.get("url")
                _neg_urls = [
                    u
                    for u in ([neg_profile_url] + list(_np_info.get("alternate_urls") or []))
                    if u
                ]
                if _neg_urls:
                    _meta_profile = SQLFunctionCall(
                        name="json_extract",
                        args=[
                            SQLQualifiedIdentifier(parts=["r", "resource"]),
                            SQLLiteral("$.meta.profile"),
                        ],
                    )
                    _profile_list = SQLFunctionCall(
                        name="from_json",
                        args=[
                            _meta_profile,
                            SQLLiteral('["VARCHAR"]'),
                        ],
                    )
                    _contains_any = SQLFunctionCall(
                        name="list_contains",
                        args=[_profile_list, SQLLiteral(_neg_urls[0])],
                    )
                    for _alt_url in _neg_urls[1:]:
                        _contains_any = SQLBinaryOp(
                            operator="OR",
                            left=_contains_any,
                            right=SQLFunctionCall(
                                name="list_contains",
                                args=[_profile_list, SQLLiteral(_alt_url)],
                            ),
                        )
                    where_conditions.append(
                        SQLBinaryOp(
                            operator="OR",
                            left=SQLBinaryOp(
                                operator="IS",
                                left=_meta_profile,
                                right=SQLNull(),
                            ),
                            right=SQLUnaryOp(
                                operator="NOT",
                                operand=_contains_any,
                            ),
                        )
                    )
                break

    # Add meta.profile filter for non-base profiles.
    # Profile-constrained retrieves (e.g., [ConditionEncounterDiagnosis])
    # must only return resources that claim conformance to the specific profile
    # URL in their meta.profile array.  The generic/base profile for the
    # resource type (e.g., qicore-condition) does NOT get filtered — it
    # matches all resources of that type.
    # STRICT PROFILE MODE (default ON). Off = do not require the canonical in
    # `meta.profile`; the retrieve matches the base resource type instead. The
    # negation-profile EXCLUSION below is deliberately NOT gated: it only ever
    # removes not-done resources and already tolerates a missing meta.profile
    # (`IS NULL OR NOT (...)`), so keeping it avoids surfacing negated records
    # as positive evidence in non-strict mode.
    _strict_profiles = getattr(context, "strict_profiles", True)
    if (
        profile_url
        and _strict_profiles
        and _registry.needs_profile_filter(resource_type, profile_url)
    ):
        # OR-chain the primary URL and any registry alternates (name-collision
        # alternates — CMS 2025 US Core data declares USQualityCore
        # canonicals for QI-Core-primary names; matching only the primary
        # returned zero resources).
        _filter_urls = _registry.profile_filter_urls(profile_url)
        _profile_json = SQLFunctionCall(
            name="from_json",
            args=[
                SQLFunctionCall(
                    name="json_extract",
                    args=[
                        SQLQualifiedIdentifier(parts=["r", "resource"]),
                        SQLLiteral("$.meta.profile"),
                    ],
                ),
                SQLLiteral('["VARCHAR"]'),
            ],
        )
        _contains_checks = [
            SQLFunctionCall(
                name="list_contains",
                args=[_profile_json, SQLLiteral(u)],
            )
            for u in _filter_urls
        ]
        _profile_check = _contains_checks[0]
        for _extra_check in _contains_checks[1:]:
            _profile_check = SQLBinaryOp(
                operator="OR", left=_profile_check, right=_extra_check,
            )
        where_conditions.append(_profile_check)

    # Add audit evidence item column when audit_mode is enabled
    if context and context.audit_mode:
        # Build CQL retrieve syntax: [TypeAlias: "ValueSetName"]
        # Resolve profile URL → CQL type alias (e.g., ConditionEncounterDiagnosis)
        _type_alias = resource_type
        _registry = _resolve_profile_registry(context)
        if _registry and all_profile_urls:
            for _purl in all_profile_urls:
                _alias = _registry.get_type_alias(_purl) if _purl else None
                if _alias:
                    _type_alias = _alias
                    break
        if _valueset_friendly_label:
            right_label = f'[{_type_alias}: "{_valueset_friendly_label}"]'
        else:
            right_label = f'[{_type_alias}]'

        # Store the retrieve syntax on the context so that definition-level
        # evidence (Strategy 2) can display the CQL retrieve syntax in
        # the 'right' field instead of the raw definition CTE name.
        if not hasattr(context, '_retrieve_right_labels'):
            context._retrieve_right_labels = {}
        context._retrieve_right_labels[cte_name] = right_label
        audit_item = SQLEvidenceItem(
            target=SQLBinaryOp(
                operator="||",
                left=SQLBinaryOp(
                    operator="||",
                    left=SQLQualifiedIdentifier(parts=["r", "resourceType"]),
                    right=SQLLiteral("/"),
                ),
                right=SQLFunctionCall(
                    name="fhirpath_text",
                    args=[
                        SQLQualifiedIdentifier(parts=["r", "resource"]),
                        SQLLiteral("id"),
                    ],
                ),
            ),
            attribute=SQLLiteral(code_property) if code_property else SQLNull(),
            value=SQLNull(),
            operator_str="exists",
            threshold=SQLLiteral(right_label),
        )
        columns.append(SQLAlias(expr=audit_item, alias="_audit_item"))

    # Combine WHERE conditions with AND
    where_clause = where_conditions[0]
    for condition in where_conditions[1:]:
        where_clause = SQLBinaryOp(
            operator="AND",
            left=where_clause,
            right=condition
        )

    # Build SELECT
    cte_ast = SQLSelect(
        columns=columns,
        from_clause=SQLAlias(expr=SQLIdentifier(name="resources"), alias="r", implicit_alias=True),
        where=where_clause,
        distinct=True  # Avoid duplicates
    )

    return cte_name, cte_ast, column_info_map


# Profiles that require distinguishing suffixes because they add unique precomputed columns
# to retrieve CTEs. Most QICore profiles (like ConditionEncounterDiagnosis vs ConditionProblemsHealthConcerns)
# map to the same FHIR resource with identical SQL, so no suffix is needed.
# Only profiles that change the SQL output (like us-core-blood-pressure with BP component columns)
# should get a suffix.
# Profile suffix resolution delegated to ProfileRegistry.get_suffix() (B-6 migration complete).


def _get_distinguishing_profile_suffix(
    profile_urls: List[str],
    profile_registry=None,
) -> Optional[str]:
    """
    Get a distinguishing suffix for profiles that change SQL output.

    Most QICore profiles for the same FHIR resource type (e.g., ConditionEncounterDiagnosis
    vs ConditionProblemsHealthConcerns) produce identical SQL queries. Only profiles that
    add unique precomputed columns need a distinguishing suffix.

    Args:
        profile_urls: List of profile URLs to check
        profile_registry: ProfileRegistry to use; falls back to default if None.

    Returns:
        Suffix string (e.g., "us-core-blood-pressure") or None if no suffix needed

    Example:
        >>> _get_distinguishing_profile_suffix(["http://hl7.org/fhir/us/core/StructureDefinition/us-core-blood-pressure"])
        'us-core-blood-pressure'
        >>> _get_distinguishing_profile_suffix(["http://hl7.org/fhir/us/qicore/StructureDefinition/qicore-condition-encounter-diagnosis"])
        None  # No suffix - same SQL as other Condition profiles
    """
    if not profile_urls:
        return None

    registry = profile_registry or _resolve_profile_registry(None)
    for url in profile_urls:
        suffix = registry.get_suffix(url)
        if suffix is not None:
            return suffix

    return None


def build_patient_demographics_cte() -> Tuple[str, SQLSelect, Dict[str, ColumnInfo]]:
    """
    Build a patient demographics CTE with precomputed birthDate.

    This CTE is used for birthday-aware age calculations when AgeInYearsAt
    or similar functions are used in population mode. Instead of creating
    a correlated subquery for each row, we pre-compute birthDate once per
    patient.

    Creates SQL like:
        _patient_demographics AS (
            SELECT
                r.patient_ref AS patient_id,
                r.resource,
                fhirpath_date(r.resource, 'birthDate') AS birth_date
            FROM resources r
            WHERE r.resourceType = 'Patient'
        )

    Returns:
        Tuple of (cte_name, cte_ast, column_info_map)

    Note:
        The CTE is named with underscore prefix to avoid collision with
        user-defined CTEs. The birth_date column is pre-computed using
        fhirpath_date for efficient age calculations.
    """
    cte_name = "_patient_demographics"

    # Build column list
    columns = [
        SQLAlias(
            expr=SQLQualifiedIdentifier(parts=["r", "patient_ref"]),
            alias="patient_id"
        ),
        SQLQualifiedIdentifier(parts=["r", "resource"]),
        SQLAlias(
            expr=SQLFunctionCall(
                    name="fhirpath_date",
                    args=[
                        SQLQualifiedIdentifier(parts=["r", "resource"]),
                        SQLLiteral("birthDate")
                    ]
                ),
            alias="birth_date"
        ),
    ]

    # Column info for registry
    column_info_map: Dict[str, ColumnInfo] = {
        "birth_date": ColumnInfo(
            column_name="birth_date",
            fhirpath="birthDate",
            sql_type="VARCHAR",
            is_choice_type=False,
        ),
    }

    # WHERE clause: only Patient resources
    where_clause = SQLBinaryOp(
        operator="=",
        left=SQLQualifiedIdentifier(parts=["r", "resourceType"]),
        right=SQLLiteral("Patient")
    )

    # Build SELECT
    cte_ast = SQLSelect(
        columns=columns,
        from_clause=SQLAlias(expr=SQLIdentifier(name="resources"), alias="r", implicit_alias=True),
        where=where_clause,
        distinct=True
    )

    return cte_name, cte_ast, column_info_map


def _flatten_and_chain(node):
    """Flatten a left-deep AND chain of SQL expressions into a list of leaves."""
    if isinstance(node, SQLBinaryOp) and node.operator == "AND":
        return _flatten_and_chain(node.left) + _flatten_and_chain(node.right)
    return [node]


def _is_resource_type_predicate(node, resource_type: str) -> bool:
    """True when *node* is ``r.resourceType = '<resource_type>'``."""
    if not isinstance(node, SQLBinaryOp) or node.operator != "=":
        return False
    left, right = node.left, node.right
    if not (isinstance(left, SQLQualifiedIdentifier) and left.parts == ["r", "resourceType"]):
        return False
    return isinstance(right, SQLLiteral) and right.value == resource_type


def extract_retrieve_resource_type(cte_ast) -> Optional[str]:
    """Return the resource type a retrieve CTE AST filters on, if any.

    A retrieve CTE reads ``FROM resources r`` with a leading
    ``r.resourceType = '<T>'`` predicate. Returns None for anything else
    (let CTEs, definition CTEs, already-rewritten children).
    """
    if not isinstance(cte_ast, SQLSelect) or cte_ast.where is None:
        return None
    fc = cte_ast.from_clause
    if not (isinstance(fc, SQLAlias) and isinstance(fc.expr, SQLIdentifier)
            and fc.expr.name == "resources"):
        return None
    for leaf in _flatten_and_chain(cte_ast.where):
        if isinstance(leaf, SQLBinaryOp) and leaf.operator == "=":
            left, right = leaf.left, leaf.right
            if (isinstance(left, SQLQualifiedIdentifier)
                    and left.parts == ["r", "resourceType"]
                    and isinstance(right, SQLLiteral)
                    and isinstance(right.value, str)):
                return right.value
    return None


def rewrite_retrieve_to_base(
    cte_ast: SQLSelect,
    base_name: str,
    resource_type: str,
) -> SQLSelect:
    """Rewrite a retrieve CTE body to read from a per-type base CTE.

    Drops the ``r.resourceType = '<T>'`` predicate and repoints
    ``FROM resources r`` → ``FROM "<base_name>" r``. The base CTE projects
    ``patient_ref AS patient_id`` and ``resource``, so child references to
    ``r.patient_ref`` are rewritten to ``r.patient_id``.
    """
    leaves = [leaf for leaf in _flatten_and_chain(cte_ast.where)
              if not _is_resource_type_predicate(leaf, resource_type)]
    if not leaves:
        new_where = None
    elif len(leaves) == 1:
        new_where = leaves[0]
    else:
        new_where = leaves[0]
        for leaf in leaves[1:]:
            new_where = SQLBinaryOp(operator="AND", left=new_where, right=leaf)

    def rewrite_ref(node):
        if isinstance(node, SQLQualifiedIdentifier):
            if node.parts == ["r", "patient_ref"]:
                return SQLQualifiedIdentifier(parts=["r", "patient_id"])
            return node
        if isinstance(node, SQLBinaryOp):
            return SQLBinaryOp(
                operator=node.operator,
                left=rewrite_ref(node.left),
                right=rewrite_ref(node.right),
            )
        if isinstance(node, SQLAlias):
            return SQLAlias(expr=rewrite_ref(node.expr), alias=node.alias,
                            implicit_alias=node.implicit_alias)
        if isinstance(node, SQLFunctionCall):
            return SQLFunctionCall(
                name=node.name,
                args=[rewrite_ref(a) for a in node.args],
                distinct=node.distinct,
            )
        if isinstance(node, SQLUnaryOp):
            # CORE-003: preserve the prefix/postfix form — the default
            # (prefix=True) corrupted postfix `X IS NOT NULL` into the
            # invalid `IS NOT NULL X`.
            return SQLUnaryOp(
                operator=node.operator,
                operand=rewrite_ref(node.operand),
                prefix=node.prefix,
            )
        if isinstance(node, SQLCast):
            return SQLCast(
                expression=rewrite_ref(node.expression),
                target_type=node.target_type,
                try_cast=node.try_cast,
            )
        if isinstance(node, SQLCase):
            return SQLCase(
                operand=rewrite_ref(node.operand) if node.operand else None,
                when_clauses=[
                    (rewrite_ref(cond), rewrite_ref(res))
                    for cond, res in node.when_clauses
                ],
                else_clause=rewrite_ref(node.else_clause) if node.else_clause else None,
            )
        # SQLExists / SQLSubquery: their internals correlate against the
        # CHILD's alias scope (or their own inner aliases like `m` in the
        # medication-reference EXISTS), never against outer r.patient_ref —
        # descending and rewriting here would corrupt inner-scope references.
        # If that assumption ever breaks, the tripwire assert below fires.
        return node

    new_select = SQLSelect(
        columns=[rewrite_ref(c) for c in cte_ast.columns],
        from_clause=SQLAlias(
            expr=SQLIdentifier(name=base_name, quoted=True),
            alias="r",
            implicit_alias=True,
        ),
        where=new_where,
        joins=list(cte_ast.joins) if cte_ast.joins else None,
        group_by=cte_ast.group_by,
        having=cte_ast.having,
        order_by=cte_ast.order_by,
        limit=cte_ast.limit,
        distinct=cte_ast.distinct,
    )

    # Tripwire (second-opinion risk 1): after the rewrite, no reference to
    # r.patient_ref may survive — the base CTE does not project it. A leak
    # would surface as a DuckDB binder error at execution; this turns it
    # into a translate-time failure with the CTE's name attached.
    _rendered = new_select.to_sql()
    if "patient_ref" in _rendered:
        raise TranslationError(
            f"retrieve-cache rewrite leaked r.patient_ref into a child CTE "
            f"reading from {base_name!r} (unhandled SQL AST node type in "
            f"rewrite_retrieve_to_base). SQL: {_rendered[:300]}"
        )
    return new_select


def build_resource_type_base_cte(resource_type: str) -> SQLSelect:
    """Build the per-resourceType base CTE body all retrieves of that type share.

    ``"_rt_<Type>" AS MATERIALIZED (
        SELECT r.patient_ref AS patient_id, r.resourceType, r.resource
        FROM resources r WHERE r.resourceType = '<Type>'
    )``
    """
    return SQLSelect(
        columns=[
            SQLAlias(
                expr=SQLQualifiedIdentifier(parts=["r", "patient_ref"]),
                alias="patient_id",
            ),
            SQLQualifiedIdentifier(parts=["r", "resourceType"]),
            SQLQualifiedIdentifier(parts=["r", "resource"]),
        ],
        from_clause=SQLAlias(expr=SQLIdentifier(name="resources"), alias="r",
                             implicit_alias=True),
        where=SQLBinaryOp(
            operator="=",
            left=SQLQualifiedIdentifier(parts=["r", "resourceType"]),
            right=SQLLiteral(resource_type),
        ),
    )
