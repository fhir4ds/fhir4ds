# src/cql_py/loader/fhir_loader.py
from __future__ import annotations

import json
import logging
import re
import threading
from pathlib import Path
from typing import Union, List, Optional, Any, TYPE_CHECKING
from urllib.parse import urlparse
from weakref import WeakKeyDictionary, WeakSet
try:
    import duckdb
except ImportError:
    duckdb = None  # type: ignore[assignment]

from fhir4ds.sources.base import quote_identifier

if TYPE_CHECKING:  # pragma: no cover - import-time only
    # Forward-import AutoCoder and NotesPipeline only for type checkers —
    # never imported at runtime to preserve the loader's zero-dep default.
    # Both are passed in by callers; we never construct one inside the
    # loader.
    from .auto_coder import AutoCoder
    from .notes_pipeline import NotesPipeline

_logger = logging.getLogger(__name__)

# Per-connection caches. WeakKeyDictionary ensures entries are cleaned up
# when DuckDB connections are garbage-collected.  Protected by a lock for
# thread safety when multiple threads register UDFs on different connections.
_CACHE_LOCK = threading.Lock()
_VALUESET_UDF_CACHE_BY_CONNECTION = WeakKeyDictionary()
_VALUESET_UDF_REGISTERED_CONNECTIONS = WeakSet()
_FHIR_RESOURCE_TYPE_RE = re.compile(r"^[A-Z][A-Za-z0-9]*$")
_FHIR_ID_RE = re.compile(r"^[A-Za-z0-9\-.]{1,64}$")
#: Lone surrogate escapes in serialized JSON. A real surrogate pair
#: (U+1F600 etc.) is an adjacent high+low escape pair and must NOT match;
#: a literal backslash-u text sequence is double-escaped by json.dumps and
#: rejected by the leading lookbehind.
_LONE_SURROGATE_JSON_RE = re.compile(
    r'(?<!\\)(?:\\ud[89ab][0-9a-f]{2}(?!\\ud[c-f][0-9a-f]{2})'
    r'|(?<!\\ud[89ab][0-9a-f]{2})\\ud[c-f][0-9a-f]{2})'
)

#: FHIR R4 Bundle.type is 1..1, code, required binding to BundleType.
#: Source: https://hl7.org/fhir/R4/valueset-bundle-type.html
_FHIR_BUNDLE_TYPES: frozenset[str] = frozenset({
    "document",
    "message",
    "transaction",
    "transaction-response",
    "batch",
    "batch-response",
    "history",
    "searchset",
    "collection",
})


def _fhir_json_loads(text: str) -> Any:
    """json.loads rejecting duplicate JSON members.

    FHIR R4 json.html: "Property names SHALL be unique." — a FHIR JSON
    document with duplicate members is invalid, so decode boundaries reject
    it instead of silently keeping the last value.
    """

    def _unique_members(pairs: list[tuple[str, Any]]) -> dict:
        obj: dict = {}
        for key, value in pairs:
            if key in obj:
                raise ValueError(
                    f"Duplicate JSON member {key!r}; FHIR requires property "
                    "names to be unique (FHIR R4 json.html)"
                )
            obj[key] = value
        return obj

    try:
        return json.loads(text, object_pairs_hook=_unique_members)
    except RecursionError:
        raise ValueError(
            "Resource nesting is too deep to parse as standard JSON."
        ) from None


def _validate_resource_identity(resource: dict) -> tuple[str, str | None]:
    resource_type = resource.get("resourceType")
    if not resource_type:
        raise ValueError(
            "Resource must have a 'resourceType' field. "
            f"Got keys: {sorted(resource.keys())}"
        )
    if not isinstance(resource_type, str):
        raise ValueError(
            f"'resourceType' must be a string, got {type(resource_type).__name__}: "
            f"{resource_type!r}"
        )
    if not _FHIR_RESOURCE_TYPE_RE.match(resource_type):
        raise ValueError(
            f"'resourceType' must be an ASCII FHIR resource type name, got {resource_type!r}"
        )

    resource_id = resource.get("id")
    if resource_id is not None:
        if not isinstance(resource_id, str):
            raise ValueError(
                f"Resource 'id' must be a string per FHIR R4 spec, "
                f"got {type(resource_id).__name__}: {resource_id!r}"
            )
        if not _FHIR_ID_RE.match(resource_id):
            raise ValueError(
                f"Resource 'id' must match the FHIR id pattern [A-Za-z0-9-.]{{1,64}}, "
                f"got {resource_id!r}"
            )
    return resource_type, resource_id


def _serialize_resource(resource: dict) -> str:
    try:
        serialized = json.dumps(resource, allow_nan=False)
    except RecursionError as exc:
        raise ValueError(
            "Resource nesting is too deep to serialize as standard JSON."
        ) from exc
    except ValueError as exc:
        raise ValueError(
            "Resource contains values that cannot be represented as standard JSON "
            "(for example NaN/Infinity values or circular references)."
        ) from exc
    except TypeError as exc:
        raise ValueError(
            "Resource contains values that cannot be represented as standard JSON "
            f"(for example datetime, Decimal, bytes, or set values): {exc}"
        ) from exc
    if _LONE_SURROGATE_JSON_RE.search(serialized):
        # DuckDB rejects lone surrogates at INSERT time with a byte-offset
        # ConversionException and no location attribution; fail at the
        # validation boundary instead (RFC 8259 §7).
        raise ValueError(
            "Resource contains unpaired Unicode surrogates that cannot be "
            "represented in standard JSON (RFC 8259 §7)."
        )
    return serialized


def _extract_codes_from_valueset_resource(valueset: dict) -> list[dict[str, str | None]]:
    """Extract codes from a raw FHIR ValueSet compose/expansion resource."""
    codes: list[dict[str, str | None]] = []

    # FHIR JSON parsing treats null members as absent (FHIR R4 json.html);
    # "expansion": null must not crash extraction.
    expansion_contains = (valueset.get("expansion") or {}).get("contains") or []
    if isinstance(expansion_contains, list):
        for item in expansion_contains:
            if not isinstance(item, dict):
                raise TypeError("ValueSet.expansion.contains entries must be objects")
            system = item.get("system")
            code = item.get("code")
            if system is not None or code is not None:
                codes.append({
                    "system": system,
                    "code": code,
                    "display": item.get("display"),
                })

    compose_includes = (valueset.get("compose") or {}).get("include") or []
    if isinstance(compose_includes, list):
        for include in compose_includes:
            if not isinstance(include, dict):
                raise TypeError("ValueSet.compose.include entries must be objects")
            system = include.get("system")
            concepts = include.get("concept", [])
            if concepts is None:
                concepts = []
            if not isinstance(concepts, list):
                raise TypeError("ValueSet.compose.include.concept must be a list")
            for concept in concepts:
                if not isinstance(concept, dict):
                    raise TypeError("ValueSet.compose.include.concept entries must be objects")
                codes.append({
                    "system": system,
                    "code": concept.get("code"),
                    "display": concept.get("display"),
                })

    return codes


class FHIRDataLoader:
    """
    Load FHIR resources into DuckDB for CQL evaluation.

    Creates a single `resources` table with columns:
    - id VARCHAR
    - resourceType VARCHAR
    - resource JSON
    - patient_ref VARCHAR

    Example:
        loader = FHIRDataLoader(con)
        loader.load_directory(Path("./fhir-data"))
        loader.load_file(Path("./bundle.json"))
        loader.load_ndjson(Path("./patients.ndjson"))
    """

    def __init__(
        self,
        con: duckdb.DuckDBPyConnection,
        table_name: str = "resources",
        create_table: bool = True,
        auto_coder: "Optional[AutoCoder]" = None,
        notes_pipeline: "Optional[NotesPipeline]" = None,
    ):
        if con is None:
            raise TypeError("Expected a DuckDB connection for 'con', got None")
        if not isinstance(con, duckdb.DuckDBPyConnection):
            raise TypeError(
                f"Expected a DuckDB connection for 'con', got {type(con).__name__}"
            )
        # Closed-connection guard, mirroring load_resource so construction
        # fails with the same actionable wrap instead of a raw error from
        # _create_table.
        try:
            con.execute("SELECT 1").fetchone()
        except duckdb.ConnectionException:
            raise duckdb.ConnectionException(
                "Cannot create FHIRDataLoader: DuckDB connection is closed"
            ) from None
        except duckdb.Error:
            pass  # connection is alive, other DuckDB errors are expected
        self.con = con
        if not isinstance(table_name, str) or not table_name.isidentifier():
            raise ValueError(
                f"table_name must be a valid SQL identifier, got {table_name!r}"
            )
        self.table_name = table_name
        self._quoted_table_name = quote_identifier(table_name)
        # Optional Phase 2 auto-coder. With ``auto_coder=None`` (default),
        # loader behavior is byte-identical to pre-Phase-2 (INV-1).
        # Stored on the instance so all entry points (load_resource,
        # load_resources, load_bundle/load_file/load_ndjson/load_directory/
        # load_from_url which delegate) get the augmentation hook for free.
        self._auto_coder = auto_coder
        # Optional Phase 4 notes pipeline. With ``notes_pipeline=None``
        # (default), loader behavior is byte-identical to pre-Phase-4
        # (INV-1 / Phase 4 SCOPE REDUCTION invariant). When set, the
        # loader appends derived Conditions alongside each source
        # resource via ``notes_pipeline.extract_conditions(resource)``.
        self._notes_pipeline = notes_pipeline
        # Share one mutable cache per DuckDB connection so repeated FHIRDataLoader
        # instances update the same _in_valueset_python closure in-place.
        with _CACHE_LOCK:
            shared_cache = _VALUESET_UDF_CACHE_BY_CONNECTION.get(con)
            if shared_cache is None:
                shared_cache = {}
                _VALUESET_UDF_CACHE_BY_CONNECTION[con] = shared_cache
        self._valueset_udf_cache: dict = shared_cache
        if create_table:
            self._create_table()

    def _create_table(self) -> None:
        """Create the resources table if it doesn't exist.

        Deduplication is handled at the application level by
        ``load_resource()``, which performs delete-before-insert for
        resources with matching (id, resourceType).  No UNIQUE index
        is added because external callers (e.g., the benchmark runner)
        may legitimately insert rows with the same (id, resourceType)
        but different context (e.g., source_measure scoping).
        """
        tbl = self._quoted_table_name
        self.con.execute(f"""
            CREATE TABLE IF NOT EXISTS {tbl} (
                id VARCHAR,
                resourceType VARCHAR,
                resource JSON,
                patient_ref VARCHAR
            )
        """)
        self._register_resolve_macro()

    def _register_resolve_macro(self) -> None:
        """Register the CQL resolve() macro that follows FHIR references.

        The macro performs a correlated subquery against the resources table
        to look up the referenced resource by ``ResourceType/id``, a full URL
        ending in ``ResourceType/id``, a bare resource id, or a JSON Reference
        object containing any of those reference forms. Version-specific
        references (``ResourceType/id/_history/{vid}``, FHIR R4
        references.html §2.3.0.4) have the version suffix stripped and
        resolve to the current stored version of the resource.
        """
        tbl = self._quoted_table_name
        try:
            self.con.execute(f"""
                CREATE OR REPLACE MACRO resolve(ref) AS (
                    WITH _raw AS (
                        SELECT CASE
                            WHEN ref IS NULL THEN NULL
                            WHEN LTRIM(ref::VARCHAR) LIKE '{{%'
                                THEN json_extract_string(ref::VARCHAR, '$.reference')
                            ELSE regexp_replace(ref::VARCHAR, '^"|"$', '', 'g')
                        END AS raw_ref
                    ),
                    _ref AS (
                        SELECT raw_ref,
                               regexp_replace(raw_ref, '/_history/[^/]+$', '') AS path_ref
                        FROM _raw
                    )
                    SELECT r.resource FROM {tbl} r
                    CROSS JOIN _ref
                    WHERE ref IS NOT NULL
                    AND raw_ref IS NOT NULL
                    AND r.id = regexp_replace(split_part(path_ref, '/', -1), '^urn:uuid:', '')
                    AND (
                        split_part(path_ref, '/', -2) = ''
                        OR r.resourceType = split_part(path_ref, '/', -2)
                    )
                    LIMIT 1
                )
            """)
        except Exception:
            _logger.debug("resolve() macro registration skipped (table may not exist)")

    def _extract_patient_ref(self, resource: dict) -> Optional[str]:
        """
        Extract the patient identity from a FHIR resource.

        - For Patient resources: returns the resource id.
        - For other resources: extracts from ``subject``, ``patient``, or
          ``beneficiary`` when the reference is Patient-typed
          (``Patient/{id}``, an absolute URL ending ``/Patient/{id}``, or a
          version-specific ``Patient/{id}/_history/{vid}`` resolved to the
          current id), or a bundle-local ``urn:uuid:`` reference whose
          target type is not expressed in the URL.
        - Returns None when the reference targets another resource type
          (e.g. ``Group/{id}``, ``Location/{id}``) or is a bare id, so
          non-patient subjects cannot fabricate phantom patient ids in
          patient-context evaluation.
        """
        resource_type = resource.get("resourceType")

        if resource_type == "Patient":
            return resource.get("id")

        for path in ("subject", "patient", "beneficiary"):
            value = resource.get(path)
            # List-valued patient references (e.g. Appointment.patient 0..*
            # in FHIR R4) are scanned for the first Patient-typed entry.
            candidates = value if isinstance(value, list) else [value]
            for ref_obj in candidates:
                if not isinstance(ref_obj, dict):
                    continue
                reference = ref_obj.get("reference")
                if not reference or not isinstance(reference, str):
                    continue
                if reference.startswith("urn:uuid:"):
                    # Bundle-local references carry no target type in the URL.
                    return reference[9:]  # len("urn:uuid:") == 9
                if "/" not in reference:
                    # Bare ids are not valid FHIR R4 references (which must
                    # be Type/id, absolute, or a URN) and carry no target
                    # type, so they cannot be safely attributed to a patient.
                    continue
                segments = [s for s in reference.split("/") if s]
                if len(segments) >= 2 and segments[-2] == "_history":
                    segments = segments[:-2]
                if len(segments) >= 2 and segments[-2] == "Patient":
                    return segments[-1]

        return None

    def load_resource(self, resource: dict) -> None:
        """Load a single FHIR resource.

        If a resource with the same (id, resourceType) already exists,
        it is replaced with the new version.  Resources without an id
        are inserted without deduplication.

        Raises:
            TypeError: If resource is not a dict.
            ValueError: If resource lacks a valid 'resourceType' field.
            duckdb.ConnectionException: If the underlying connection is
                closed (mirrors the ``evaluate_measure`` wrap pattern so
                callers get an actionable fhir4ds-typed message instead
                of the raw DuckDB string).
        """
        if not isinstance(resource, dict):
            raise TypeError(
                f"Expected dict, got {type(resource).__name__}"
            )
        # Closed-connection guard (QA-015). Mirrors cql/__init__.py:384-389.
        try:
            self.con.execute("SELECT 1").fetchone()
        except duckdb.ConnectionException:
            raise duckdb.ConnectionException(
                "Cannot load FHIR resource: DuckDB connection is closed"
            ) from None
        except duckdb.Error:
            pass  # connection is alive, other DuckDB errors are expected
        # Phase 2 augmentation hook — runs BEFORE validate/serialize so the
        # auto-coder can append Codings to text-only CodeableConcepts. With
        # ``self._auto_coder is None`` (the default) this branch is skipped
        # entirely and behavior is byte-identical to pre-Phase-2 (INV-1).
        if self._auto_coder is not None:
            self._auto_coder.augment_resource(resource)
        resource_type, resource_id = _validate_resource_identity(resource)
        patient_ref = self._extract_patient_ref(resource)
        resource_json = _serialize_resource(resource)

        if resource_id is not None and resource_type is not None:
            # Delete existing resource with same identity, then insert
            self.con.execute(
                f"DELETE FROM {self._quoted_table_name} WHERE id = ? AND resourceType = ?",
                [resource_id, resource_type],
            )
        self.con.execute(
            f"INSERT INTO {self._quoted_table_name} VALUES (?, ?, ?, ?)",
            [resource_id, resource_type, resource_json, patient_ref],
        )

        # Phase 4 notes-pipeline hook — runs AFTER the source resource is
        # loaded so derived Conditions join the same batch. With
        # ``self._notes_pipeline is None`` (default) this branch is
        # skipped entirely and behavior is byte-identical to pre-Phase-4.
        # ``extract_conditions`` NEVER raises (Phase 4 INV-3) and returns
        # ``[]`` for Condition source resources (Phase 4 INV-4) so batch
        # loads cannot enter an infinite loop.
        if self._notes_pipeline is not None:
            derived = self._notes_pipeline.extract_conditions(resource)
            for derived_resource in derived or []:
                if not isinstance(derived_resource, dict):
                    continue
                try:
                    d_type, d_id = _validate_resource_identity(derived_resource)
                    d_patient_ref = self._extract_patient_ref(derived_resource)
                    d_json = _serialize_resource(derived_resource)
                except (TypeError, ValueError) as exc:
                    _logger.warning(
                        "Skipping invalid derived Condition from %s/%s: %s",
                        resource_type, resource_id, exc,
                    )
                    continue
                if d_id is not None and d_type is not None:
                    self.con.execute(
                        f"DELETE FROM {self._quoted_table_name} WHERE id = ? AND resourceType = ?",
                        [d_id, d_type],
                    )
                self.con.execute(
                    f"INSERT INTO {self._quoted_table_name} VALUES (?, ?, ?, ?)",
                    [d_id, d_type, d_json, d_patient_ref],
                )

    def load_resources(self, resources: list[dict]) -> int:
        """Load multiple FHIR resources in a single batch.

        Uses executemany for better performance than individual
        load_resource() calls. Deduplicates by (id, resourceType) — when
        the same identity appears multiple times, only the last entry is kept.

        Args:
            resources: List of FHIR resource dicts.

        Returns:
            Number of unique resources loaded.

        Raises:
            TypeError: If any resource is not a dict.
            ValueError: If any resource lacks a valid 'resourceType' field.
        """
        if resources is None:
            raise TypeError("Expected list of FHIR resource dicts, got None")
        if not isinstance(resources, list):
            raise TypeError(
                f"Expected list of FHIR resource dicts, got {type(resources).__name__}"
            )
        if not resources:
            return 0

        # Phase 2 augmentation pre-pass (FDD Step 3). When an AutoCoder
        # is configured, run its batch-aware augmentation once over the
        # entire input list BEFORE the row-build loop. With
        # ``batch_size=1`` (the default), ``augment_resources`` delegates
        # to ``augment_resource`` per resource — byte-identical to the
        # pre-feature code path. ``augment_resources`` MUST NOT raise
        # (INV-9 propagated through the batch boundary).
        if self._auto_coder is not None:
            self._auto_coder.augment_resources(resources)

        # Phase 4 notes-pipeline pre-pass (FDD Step 3). When a
        # NotesPipeline is configured, run its batch-aware extraction
        # once. The returned list-of-lists is indexed by input position
        # so the row-build loop can attach derived Conditions to the
        # right source resource. ``extract_conditions_batch`` MUST NOT
        # raise (INV-3 / INV-A4 propagated through the batch boundary).
        derived_per_resource: list[list[dict]] | None = None
        if self._notes_pipeline is not None:
            derived_per_resource = self._notes_pipeline.extract_conditions_batch(
                resources
            )
            # Defensive: batch contract is len(out) == len(resources).
            # If a future bug returns a different shape, fall back to
            # per-resource extraction so the load still completes.
            if derived_per_resource is None or len(derived_per_resource) != len(resources):
                _logger.warning(
                    "extract_conditions_batch returned shape %r; falling "
                    "back to per-resource extraction.",
                    None if derived_per_resource is None else len(derived_per_resource),
                )
                derived_per_resource = [
                    self._notes_pipeline.extract_conditions(r) for r in resources
                ]

        # Build rows and deduplicate: last-write-wins for same (id, resourceType)
        seen: dict[tuple[str, str], int] = {}
        rows: list[tuple] = []
        dedup_count = 0
        for index, resource in enumerate(resources):
            if not isinstance(resource, dict):
                raise TypeError(f"Expected dict, got {type(resource).__name__}")
            # Phase 2 augmentation already ran in the pre-pass above.
            resource_type, resource_id = _validate_resource_identity(resource)
            patient_ref = self._extract_patient_ref(resource)
            resource_json = _serialize_resource(resource)
            row = (resource_id, resource_type, resource_json, patient_ref)
            if resource_id is not None:
                key = (resource_id, resource_type)
                if key in seen:
                    # Distinguish source-source dedup (a repeat of the
                    # same input row, last-write-wins per FHIR R4 id
                    # uniqueness) from cross-source/derived collisions
                    # (a derived Condition sharing a source resource's
                    # ``(id, resourceType)``). Both are logged WARNING
                    # rather than DEBUG so silent data corruption is
                    # surfaced (loader "no silent corruption" contract,
                    # QA-010). Realistic collision likelihood is low
                    # (sha256-derived ids) but the warning costs nothing.
                    _logger.warning(
                        "Duplicate resource %s/%s — overwriting earlier "
                        "row in the same batch (last-write-wins).",
                        resource_type, resource_id,
                    )
                    rows[seen[key]] = None  # type: ignore[assignment]
                    dedup_count += 1
                seen[key] = len(rows)
            rows.append(row)

            # Phase 4 notes-pipeline hook (batch path). Derived
            # Conditions were extracted in the pre-pass above; this loop
            # just serializes and inserts them. ``extract_conditions``
            # NEVER raises (Phase 4 INV-3) so a single bad resource
            # cannot poison the batch.
            if derived_per_resource is not None:
                derived_list = derived_per_resource[index]
                for derived_resource in derived_list or []:
                    if not isinstance(derived_resource, dict):
                        continue
                    try:
                        d_type, d_id = _validate_resource_identity(derived_resource)
                        d_patient_ref = self._extract_patient_ref(derived_resource)
                        d_json = _serialize_resource(derived_resource)
                    except (TypeError, ValueError) as exc:
                        _logger.warning(
                            "Skipping invalid derived Condition from %s/%s: %s",
                            resource_type, resource_id, exc,
                        )
                        continue
                    d_row = (d_id, d_type, d_json, d_patient_ref)
                    if d_id is not None:
                        d_key = (d_id, d_type)
                        if d_key in seen:
                            # Cross-source/derived collision (QA-010):
                            # the derived Condition's deterministic id
                            # matched an earlier row. Surface this as a
                            # WARNING so silent overwrites are debuggable.
                            _logger.warning(
                                "Derived Condition %s/%s collides with an "
                                "earlier resource in the same batch — "
                                "overwriting earlier row.",
                                d_type, d_id,
                            )
                            rows[seen[d_key]] = None  # type: ignore[assignment]
                            dedup_count += 1
                        seen[d_key] = len(rows)
                    rows.append(d_row)

        # Filter out replaced duplicates
        final_rows = [r for r in rows if r is not None]
        if dedup_count:
            _logger.info(
                "Loaded %d resources (%d duplicates removed)",
                len(final_rows), dedup_count,
            )

        # Remove existing duplicates in batch, then bulk insert. Prefer the
        # Arrow register + INSERT SELECT path (mirroring ``load_valuesets``):
        # duckdb ``executemany`` executes one prepared statement per row
        # (~150x slower than the bulk path for 10k+ resource batches).
        dedup_keys = [(rid, rtype) for rid, rtype in seen.keys()]
        used_arrow = False
        try:
            import pyarrow as pa

            if dedup_keys:
                key_table = pa.table({
                    "id": pa.array([k[0] for k in dedup_keys], pa.string()),
                    "resourceType": pa.array([k[1] for k in dedup_keys], pa.string()),
                })
                key_temp = f"_{self.table_name}_bulk_dedup"
                quoted_key_temp = quote_identifier(key_temp)
                self.con.register(key_temp, key_table)
                try:
                    self.con.execute(
                        f"DELETE FROM {self._quoted_table_name} "
                        f"WHERE (id, resourceType) IN "
                        f"(SELECT id, resourceType FROM {quoted_key_temp})"
                    )
                finally:
                    self.con.unregister(key_temp)
            if final_rows:
                arrow_table = pa.table({
                    "id": pa.array([r[0] for r in final_rows], pa.string()),
                    "resourceType": pa.array([r[1] for r in final_rows], pa.string()),
                    "resource": pa.array([r[2] for r in final_rows], pa.string()),
                    "patient_ref": pa.array([r[3] for r in final_rows], pa.string()),
                })
                row_temp = f"_{self.table_name}_bulk_rows"
                quoted_row_temp = quote_identifier(row_temp)
                self.con.register(row_temp, arrow_table)
                try:
                    self.con.execute(
                        f"INSERT INTO {self._quoted_table_name} "
                        f"SELECT id, resourceType, resource::JSON, patient_ref "
                        f"FROM {quoted_row_temp}"
                    )
                finally:
                    self.con.unregister(row_temp)
            used_arrow = True
        except ImportError:
            used_arrow = False

        if not used_arrow:
            if dedup_keys:
                self.con.executemany(
                    f"DELETE FROM {self._quoted_table_name} WHERE id = ? AND resourceType = ?",
                    dedup_keys,
                )
            self.con.executemany(
                f"INSERT INTO {self._quoted_table_name} VALUES (?, ?, ?, ?)",
                final_rows,
            )
        return len(final_rows)

    def load_bundle(self, bundle: dict) -> int:
        """
        Load all resources from a FHIR Bundle.

        Returns the number of resources loaded.

        Raises:
            TypeError: If bundle is not a dict.
            ValueError: If bundle is not a FHIR Bundle resource, if
                Bundle.type is missing/invalid (FHIR R4 requires 1..1
                Bundle.type with required binding to BundleType), or if
                any entry resource is not a valid FHIR resource. Invalid
                entries are reported with their entry index (mirroring
                the ``load_ndjson`` per-line attribution).
        """
        if not isinstance(bundle, dict):
            raise TypeError(
                f"Expected dict for bundle, got {type(bundle).__name__}"
            )
        if bundle.get("resourceType") != "Bundle":
            raise ValueError("Expected a FHIR Bundle resource")

        # FHIR R4: Bundle.type is 1..1, code, required binding to
        # BundleType, IsModifier=true. Reject missing or unknown types
        # per the loader's fail-fast contract (GLOBAL_RULES "No Silent
        # Fallbacks"). See:
        # https://hl7.org/fhir/R4/bundle-definitions.html#Bundle.type
        bundle_type = bundle.get("type")
        if not isinstance(bundle_type, str) or not bundle_type:
            raise ValueError(
                "Bundle.type is required (FHIR R4 1..1 cardinality) but "
                f"got {bundle_type!r}"
            )
        if bundle_type not in _FHIR_BUNDLE_TYPES:
            raise ValueError(
                f"Bundle.type {bundle_type!r} is not a valid FHIR R4 "
                f"BundleType code. Expected one of: "
                f"{sorted(_FHIR_BUNDLE_TYPES)}"
            )

        entries = bundle.get("entry") or []
        if not isinstance(entries, list):
            raise TypeError("Bundle.entry must be a list")

        resources = []
        for index, entry in enumerate(entries):
            if entry is None:
                continue
            if not isinstance(entry, dict):
                raise TypeError(f"Bundle.entry[{index}] must be an object")
            resource = entry.get("resource")
            if resource is None:
                continue
            if not isinstance(resource, dict):
                raise TypeError(f"Bundle.entry[{index}].resource must be an object")
            if not resource:
                raise ValueError(
                    f"Bundle.entry[{index}].resource is empty; a bundled "
                    "resource must carry at least 'resourceType'"
                )
            # Per-entry FHIR validation with index attribution, mirroring
            # the load_ndjson per-line contract.
            try:
                _validate_resource_identity(resource)
                _serialize_resource(resource)
            except (TypeError, ValueError) as e:
                raise ValueError(
                    f"Invalid FHIR resource at Bundle.entry[{index}]: {e}"
                ) from e
            resources.append(resource)

        if resources:
            return self.load_resources(resources)
        return 0

    def load_file(self, path: Union[str, Path]) -> int:
        """
        Load from a JSON file.

        Automatically detects if it's a Bundle or single resource.
        Returns the number of resources loaded.

        Raises:
            ValueError: If the file contains malformed JSON. The error
                message includes the file path so the operator can
                locate the bad file in multi-file ``load_directory``
                runs (mirrors the ``load_ndjson`` per-line attribution).
            TypeError: If the JSON value is not a JSON object.
        """
        path = Path(path) if not isinstance(path, Path) else path
        try:
            # utf-8-sig tolerates a UTF-8 BOM (RFC 8259 §8.1 permits
            # ignoring it) common in Windows-origin exports, and decodes
            # plain UTF-8 identically when no BOM is present.
            data = _fhir_json_loads(path.read_text(encoding="utf-8-sig"))
        except json.JSONDecodeError as e:
            raise ValueError(
                f"Malformed JSON in {path}: {e}"
            ) from e
        except ValueError as e:
            raise ValueError(
                f"Invalid FHIR JSON in {path}: {e}"
            ) from e
        if not isinstance(data, dict):
            raise TypeError(
                f"FHIR JSON file {path} must contain an object resource or Bundle, "
                f"got {type(data).__name__}"
            )
        resource_type = data.get("resourceType")

        if resource_type == "Bundle":
            return self.load_bundle(data)
        else:
            self.load_resource(data)
            return 1

    def load_ndjson(self, path: Union[str, Path], *, strict: bool = True) -> int:
        """
        Load from an NDJSON file (one resource per line).

        Returns the number of resources loaded.

        Args:
            path: Path to the NDJSON file.
            strict: If True (default), raise on malformed JSON or invalid
                FHIR resources to prevent partial loads. Per-line errors
                include the line number so the operator can locate the
                bad row. If False, skip bad lines with a warning and
                continue loading valid resources.

        Raises:
            ValueError: If strict=True and any line contains malformed
                JSON or an invalid FHIR resource (e.g. missing
                ``resourceType``, NaN/Infinity values, malformed
                ``resourceType``/``id``). Error message includes the
                1-based line number.
            TypeError: If strict=True and a line is valid JSON but not a
                JSON object.
        """
        import logging
        _logger = logging.getLogger("fhir4ds.loader")
        path = Path(path) if not isinstance(path, Path) else path
        resources = []
        # utf-8-sig tolerates a UTF-8 BOM (RFC 8259 §8.1 permits ignoring
        # it) on the first line of Windows-origin exports.
        with open(path, encoding="utf-8-sig") as f:
            for line_num, line in enumerate(f, 1):
                line = line.strip()
                if line:
                    try:
                        resource = _fhir_json_loads(line)
                    except json.JSONDecodeError as e:
                        if strict:
                            raise ValueError(
                                f"Malformed JSON at line {line_num} in {path}: {e}"
                            ) from e
                        _logger.warning(
                            "Skipping malformed JSON at line %d in %s: %s",
                            line_num, path, e,
                        )
                        continue
                    except ValueError as e:
                        if strict:
                            raise ValueError(
                                f"Invalid FHIR JSON at line {line_num} in {path}: {e}"
                            ) from e
                        _logger.warning(
                            "Skipping invalid FHIR JSON at line %d in %s: %s",
                            line_num, path, e,
                        )
                        continue
                    # Per-line FHIR validation. Symmetric for both
                    # strict=True (raise with line attribution) and
                    # strict=False (warn + skip). Previously strict=True
                    # only validated JSON syntax per-line and deferred
                    # FHIR validity to ``load_resources``, which raised
                    # with no line attribution on large files.
                    try:
                        if not isinstance(resource, dict):
                            raise TypeError(
                                f"Expected JSON object for FHIR resource, "
                                f"got {type(resource).__name__}"
                            )
                        _validate_resource_identity(resource)
                        _serialize_resource(resource)
                    except (TypeError, ValueError) as e:
                        if strict:
                            raise ValueError(
                                f"Invalid FHIR resource at line {line_num} "
                                f"in {path}: {e}"
                            ) from e
                        _logger.warning(
                            "Skipping invalid FHIR resource at line %d in %s: %s",
                            line_num, path, e,
                        )
                        continue
                    resources.append(resource)

        return self.load_resources(resources)

    def load_directory(
        self,
        path: Union[str, Path],
        recursive: bool = True,
        extensions: List[str] = None
    ) -> int:
        """
        Load all supported files from a directory.

        Non-FHIR files (missing resourceType, malformed JSON) are skipped
        with a warning logged. Returns the total number of resources loaded.

        Raises:
            FileNotFoundError: If the directory does not exist.
            NotADirectoryError: If the path exists but is not a directory.
        """
        import logging
        _logger = logging.getLogger("fhir4ds.loader")
        path = Path(path) if not isinstance(path, Path) else path

        if not path.exists():
            raise FileNotFoundError(
                f"Directory not found: {path}"
            )
        if not path.is_dir():
            raise NotADirectoryError(
                f"Not a directory: {path}"
            )

        if extensions is None:
            extensions = [".json", ".ndjson"]
        extensions_lower = [ext.lower() for ext in extensions]

        total = 0
        pattern = "**/*" if recursive else "*"

        for file_path in path.glob(pattern):
            if file_path.is_file() and file_path.suffix.lower() in extensions_lower:
                try:
                    if file_path.suffix.lower() == ".ndjson":
                        total += self.load_ndjson(file_path, strict=False)
                    else:
                        total += self.load_file(file_path)
                except (json.JSONDecodeError, TypeError, ValueError, KeyError, OSError) as e:
                    _logger.warning("Skipping non-FHIR file %s: %s", file_path, e)

        return total

    def load_from_url(self, url: str, headers: Optional[dict] = None) -> int:
        """
        Load from a FHIR server URL.

        Returns the number of resources loaded.
        """
        import urllib.request

        if not isinstance(url, str) or not url:
            raise ValueError("url must be a non-empty string")
        scheme = urlparse(url).scheme.lower()
        if scheme not in {"http", "https"}:
            raise ValueError(
                f"Unsupported URL scheme {scheme!r}. Only 'http' and 'https' are allowed."
            )
        if headers is not None and not isinstance(headers, dict):
            raise TypeError(f"headers must be a dict if provided, got {type(headers).__name__}")

        req = urllib.request.Request(url, headers=headers or {})
        with urllib.request.urlopen(req) as response:
            # utf-8-sig tolerates a UTF-8 BOM (RFC 8259 §8.1) in server
            # payloads, mirroring load_file/load_ndjson.
            try:
                data = _fhir_json_loads(response.read().decode("utf-8-sig"))
            except json.JSONDecodeError as e:
                raise ValueError(
                    f"Malformed JSON from {url}: {e}"
                ) from e
            except ValueError as e:
                raise ValueError(
                    f"Invalid FHIR JSON from {url}: {e}"
                ) from e

        if not isinstance(data, dict):
            raise TypeError(
                "FHIR server response must contain an object resource or Bundle, "
                f"got {type(data).__name__}"
            )
        if data.get("resourceType") == "Bundle":
            return self.load_bundle(data)
        else:
            self.load_resource(data)
            return 1

    def clear(self) -> None:
        """Clear all resources from the table."""
        self.con.execute(f"DELETE FROM {self._quoted_table_name}")

    def count(self, resource_type: Optional[str] = None) -> int:
        """Count resources in the table, optionally filtered by type."""
        if resource_type:
            result = self.con.execute(
                f"SELECT COUNT(*) FROM {self._quoted_table_name} WHERE resourceType = ?",
                [resource_type]
            ).fetchone()
        else:
            result = self.con.execute(
                f"SELECT COUNT(*) FROM {self._quoted_table_name}"
            ).fetchone()
        return result[0] if result else 0

    def load_valuesets(
        self,
        valuesets: List[Any],
        table_name: str = "valueset_codes"
    ) -> int:
        if not isinstance(table_name, str) or not table_name.isidentifier():
            raise ValueError(
                f"table_name must be a valid SQL identifier, got {table_name!r}"
            )
        quoted_table_name = quote_identifier(table_name)
        """
        Load ValueSet codes into a table for fhirpath_in_valueset UDF.

        Creates a table with columns:
        - valueset_url VARCHAR
        - system VARCHAR
        - code VARCHAR
        - display VARCHAR

        This table is queried by the fhirpath_in_valueset UDF to check
        if a code is in a valueset without making API calls.

        Args:
            valuesets: List of ResolvedValueSet objects from DependencyResolver,
                      or list of dicts with 'url' and 'codes' keys.
                      Each code should have 'system', 'code', and optionally 'display'.
            table_name: Name of the table to create/populate

        Returns:
            Total number of codes loaded
        """
        if valuesets is None:
            raise TypeError("valuesets must be a list, got None")
        if not isinstance(valuesets, list):
            raise TypeError(f"valuesets must be a list, got {type(valuesets).__name__}")

        # Create table if not exists
        self.con.execute(f"""
            CREATE TABLE IF NOT EXISTS {quoted_table_name} (
                valueset_url VARCHAR,
                system VARCHAR,
                code VARCHAR,
                display VARCHAR
            )
        """)

        total_codes = 0
        valueset_urls = []
        systems = []
        code_values = []
        displays = []
        for index, vs in enumerate(valuesets):
            if vs is None:
                raise TypeError(f"valuesets[{index}] must be a ValueSet object or dict, got None")
            # Handle both object with .url/.codes attributes and dict with 'url'/'codes' keys
            if hasattr(vs, 'url'):
                vs_url = vs.url
                codes = getattr(vs, 'codes', None)
                if codes is None:
                    raise TypeError(
                        f"valuesets[{index}] object exposes .url but not .codes; "
                        "expected a ResolvedValueSet-like object"
                    )
            elif isinstance(vs, dict):
                vs_url = vs.get("url")
                codes = vs.get("codes")
                if codes is None and vs.get("resourceType") == "ValueSet":
                    codes = _extract_codes_from_valueset_resource(vs)
                if codes is None:
                    codes = []
            else:
                raise TypeError(
                    f"valuesets[{index}] must be a ValueSet object or dict, "
                    f"got {type(vs).__name__}"
                )
            if not isinstance(vs_url, str) or not vs_url:
                raise ValueError(f"valuesets[{index}] must include a non-empty string 'url'")
            if not isinstance(codes, list):
                raise TypeError(f"valuesets[{index}].codes must be a list, got {type(codes).__name__}")

            for code_index, code_entry in enumerate(codes):
                if code_entry is None:
                    raise TypeError(
                        f"valuesets[{index}].codes[{code_index}] must be a code object or dict, got None"
                    )
                # Handle both object and dict for code entries
                if hasattr(code_entry, 'system'):
                    system = code_entry.system
                    code = code_entry.code
                    display = getattr(code_entry, 'display', None)
                elif isinstance(code_entry, dict):
                    system = code_entry.get("system")
                    code = code_entry.get("code")
                    display = code_entry.get("display")
                else:
                    raise TypeError(
                        f"valuesets[{index}].codes[{code_index}] must be a code object or dict, "
                        f"got {type(code_entry).__name__}"
                    )
                if not isinstance(system, str) or not isinstance(code, str):
                    raise ValueError(
                        f"valuesets[{index}].codes[{code_index}] must include string "
                        "'system' and 'code' values"
                    )

                valueset_urls.append(vs_url)
                systems.append(system)
                code_values.append(code)
                displays.append(display)
                total_codes += 1

        if valueset_urls:
            try:
                import pyarrow as pa

                arrow_table = pa.table({
                    "valueset_url": pa.array(valueset_urls, type=pa.string()),
                    "system": pa.array(systems, type=pa.string()),
                    "code": pa.array(code_values, type=pa.string()),
                    "display": pa.array(displays, type=pa.string()),
                })
                temp_name = f"_{table_name}_bulk_valuesets"
                quoted_temp_name = quote_identifier(temp_name)
                self.con.register(temp_name, arrow_table)
                try:
                    self.con.execute(
                        f"INSERT INTO {quoted_table_name} "
                        f"SELECT valueset_url, system, code, display "
                        f"FROM {quoted_temp_name}"
                    )
                finally:
                    self.con.unregister(temp_name)
            except ImportError:
                rows = list(zip(valueset_urls, systems, code_values, displays))
                self.con.executemany(
                    f"INSERT INTO {quoted_table_name} VALUES (?, ?, ?, ?)",
                    rows,
                )

        # Create index for fast lookups after bulk insert so fresh loads do
        # not maintain the index one row at a time.
        quoted_index_name = quote_identifier(f"idx_{table_name}_lookup")
        self.con.execute(f"""
            CREATE INDEX IF NOT EXISTS {quoted_index_name}
            ON {quoted_table_name} (valueset_url, system, code)
        """)

        self._refresh_in_valueset_udf(table_name)
        return total_codes

    def count_valueset_codes(
        self,
        valueset_url: Optional[str] = None,
        table_name: str = "valueset_codes"
    ) -> int:
        """
        Count codes in the valueset_codes table, optionally filtered by valueset URL.

        Args:
            valueset_url: Optional URL to filter by
            table_name: Name of the valueset codes table

        Returns:
            Number of codes matching the filter
        """
        if not isinstance(table_name, str) or not table_name.isidentifier():
            raise ValueError(
                f"table_name must be a valid SQL identifier, got {table_name!r}"
            )
        quoted_table_name = quote_identifier(table_name)
        if not self.valueset_table_exists(table_name):
            return 0
        if valueset_url:
            result = self.con.execute(
                f"SELECT COUNT(*) FROM {quoted_table_name} WHERE valueset_url = ?",
                [valueset_url]
            ).fetchone()
        else:
            result = self.con.execute(
                f"SELECT COUNT(*) FROM {quoted_table_name}"
            ).fetchone()
        return result[0] if result else 0

    def clear_valuesets(self, table_name: str = "valueset_codes") -> None:
        """
        Clear all codes from the valueset_codes table.

        Args:
            table_name: Name of the valueset codes table
        """
        if not isinstance(table_name, str) or not table_name.isidentifier():
            raise ValueError(
                f"table_name must be a valid SQL identifier, got {table_name!r}"
            )
        quoted_table_name = quote_identifier(table_name)
        if not self.valueset_table_exists(table_name):
            return
        self.con.execute(f"DELETE FROM {quoted_table_name}")
        self._refresh_in_valueset_udf(table_name)

    def valueset_table_exists(self, table_name: str = "valueset_codes") -> bool:
        """
        Check if the valueset codes table exists.

        Args:
            table_name: Name of the valueset codes table to check

        Returns:
            True if the table exists, False otherwise
        """
        result = self.con.execute(
            "SELECT 1 FROM information_schema.tables WHERE table_name = ?",
            [table_name]
        ).fetchone()
        return result is not None

    def _refresh_in_valueset_udf(self, table_name: str = "valueset_codes") -> None:
        """Refresh the in_valueset Python UDF cache from the populated valueset_codes table.

        When duckdb_cql_py registers ``in_valueset``, it uses an empty in-memory
        cache.  After codes are loaded into the SQL table we must rebuild the cache
        so that subsequent ``in_valueset()`` calls return correct results.

        Uses a soft import of ``duckdb_cql_py`` so that ``cql-py`` does not gain a
        hard dependency on the higher-level package.
        """
        if self._refresh_cpp_in_valueset_cache(table_name):
            return
        quoted_table_name = quote_identifier(table_name)

        try:
            from fhir4ds.cql.duckdb.udf.valueset import createValuesetMembershipUdf
        except ImportError:
            return

        try:
            rows = self.con.execute(
                f"SELECT valueset_url, system, code FROM {quoted_table_name}"
            ).fetchall()
        except (duckdb.CatalogException, duckdb.BinderException) if duckdb else () as e:
            _logger.warning("Failed to query valueset table '%s': %s", table_name, e)
            return
        except Exception as e:
            _logger.error("Unexpected error querying valueset table '%s': %s", table_name, e)
            raise

        # Update the instance-level cache dict IN-PLACE so the already-registered
        # UDF closure sees the new values without requiring re-registration.
        self._valueset_udf_cache.clear()
        for vs_url, system, code in rows:
            # Normalize system identifiers (OID → URL, SNOMED module → base)
            from fhir4ds.cql.duckdb.udf.system_resolver import SystemResolver
            norm_sys = SystemResolver.normalize(system) if system else ""
            self._valueset_udf_cache.setdefault(vs_url, set()).add((norm_sys, code or ""))

        try:
            # Register the Python UDF once per connection. Its closure references
            # the shared cache dict above, so future refreshes only need to update
            # that dict in-place and recreate the macros.
            if self.con not in _VALUESET_UDF_REGISTERED_CONNECTIONS:
                udf_func = createValuesetMembershipUdf(self._valueset_udf_cache)
                self.con.create_function("_in_valueset_python", udf_func, null_handling="special")
                with _CACHE_LOCK:
                    _VALUESET_UDF_REGISTERED_CONNECTIONS.add(self.con)
            self.con.execute(
                "CREATE OR REPLACE MACRO in_valueset(res, path, vs_url) AS "
                "_in_valueset_python(res, path, vs_url)"
            )
            self.con.execute(
                "CREATE OR REPLACE MACRO fhirpath_in_valueset(res, path, vs_url) AS "
                "_in_valueset_python(res, path, vs_url)"
            )
        except (duckdb.CatalogException, duckdb.InvalidInputException) if duckdb else () as e:
            _logger.warning("Failed to refresh valueset UDF macros: %s", e)
        except Exception as e:
            _logger.error("Unexpected error refreshing valueset UDF macros: %s", e)
            raise

    def _refresh_cpp_in_valueset_cache(self, table_name: str = "valueset_codes") -> bool:
        """Populate the native CQL valueset cache when the C++ extension exposes it."""
        import os
        use_native = os.environ.get("FHIR4DS_USE_CPP_VALUESET_CACHE", "").lower()
        if use_native in ("0", "false", "no", "off"):
            return False
        quoted_table_name = quote_identifier(table_name)

        try:
            self.con.execute("SELECT cql_valueset_cache_clear()").fetchone()
        except Exception:
            return False

        try:
            self.con.execute(
                f"SELECT cql_valueset_cache_add(valueset_url, system, code) "
                f"FROM {quoted_table_name}"
            ).fetchall()
            # Remove stale Python macros from prior refreshes so SQL resolves to
            # the native functions. The C++ extension now registers BOTH
            # in_valueset and the translator-facing fhirpath_in_valueset alias
            # (same InValuesetFunc), so no aliasing macro is needed on the
            # native path. On pure-Python connections the fallback branch
            # below recreates the Python-UDF macros.
            for macro_name in ("in_valueset", "fhirpath_in_valueset"):
                try:
                    self.con.execute(f"DROP MACRO IF EXISTS {macro_name}")
                except Exception:
                    pass
            return True
        except Exception as e:
            _logger.warning("Failed to populate C++ valueset cache; using Python UDF: %s", e)
            return False
