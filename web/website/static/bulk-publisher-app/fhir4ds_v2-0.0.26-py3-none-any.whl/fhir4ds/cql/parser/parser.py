"""
CQL Parser.

Recursive descent parser for CQL R1.5 that constructs an Abstract Syntax Tree (AST)
from CQL tokens produced by the lexer.

Reference: https://cql.hl7.org/05-libraries.html

TODO (Task C1): Fix parsing of QICoreCommon.cql
The parser currently fails on QICoreCommon.cql at line 488 due to two issues:
1. `Resource` type is not recognized as a valid base FHIR type
2. `&` character in URL string literals causes lexer issues

Once fixed, Tasks C2-C5 can dynamically extract library knowledge:
- C2: Extract code constants from parsed library ASTs
- C3: Extract status filter logic from function body ASTs
- C4: Inline all fluent function bodies from parsed ASTs (eliminate body_sql)
- C5: Resolve component codes via valueset queries from CQL context
"""

from __future__ import annotations

import logging
from typing import Callable, List, Optional, Union

from ..errors import ParseError

_logger = logging.getLogger(__name__)

# Sentinel distinguishing "not yet seen" from a None (unversioned) reference.
_UNSET = object()


# CQL 2.0 directives (FHIR-41326): comparison precisions supported by
# #DefaultComparisonPrecision. 'week' is deliberately absent — CQL §8
# timing comparisons "involving weeks are not supported".
_COMPARISON_PRECISIONS = (
    "year", "month", "day", "hour", "minute", "second", "millisecond",
)

# Token type names accepted as an unquoted directive value (temporal
# precision keywords, singular and plural).
_DIRECTIVE_PRECISION_TOKENS = {
    "YEAR", "MONTH", "WEEK", "DAY", "HOUR", "MINUTE", "SECOND", "MILLISECOND",
    "YEARS", "MONTHS", "WEEKS", "DAYS", "HOURS", "MINUTES", "SECONDS",
    "MILLISECONDS",
}

# Token type names accepted as a directive NAME (keywordIdentifier-class
# tokens that may legally appear as directive identifiers).
_DIRECTIVE_NAME_TOKENS = {
    "YEAR", "MONTH", "WEEK", "DAY", "HOUR", "MINUTE", "SECOND", "MILLISECOND",
    "DATE", "TIME", "CODE", "CONCEPT", "DEFAULT", "VERSION", "DISPLAY",
}


def _version_display(version: Optional[str]) -> str:
    return f"'{version}'" if version is not None else "(no version)"

from ..parser.ast_nodes import (
    AliasRef,
    AggregateClause,
    AggregateExpression,
    AllExpression,
    AnyExpression,
    BinaryExpression,
    CaseExpression,
    CaseItem,
    CodeDefinition,
    CodeSystemDefinition,
    ConceptDefinition,
    ConditionalExpression,
    ContextDefinition,
    DateComponent,
    DateTimeLiteral,
    Definition,
    DifferenceBetween,
    Directive,
    DistinctExpression,
    DurationBetween,
    ExistsExpression,
    Expression,
    FirstExpression,
    FunctionDefinition,
    FunctionRef,
    Identifier,
    IncludeDefinition,
    IndexerExpression,
    InstanceExpression,
    Interval,
    IntervalTypeSpecifier,
    LastExpression,
    LetClause,
    Library,
    ListExpression,
    ListTypeSpecifier,
    Literal,
    MethodInvocation,
    NamedTypeSpecifier,
    ParameterDef,
    ParameterDefinition,
    Property,
    QualifiedIdentifier,
    Query,
    QuerySource,
    Quantity,
    Retrieve,
    RetrieveFilter,
    TypeDefinition,
    TypeElement,
    ContextInfoDefinition,
    ContextRelationship,
    ConversionDefinition,
    ReturnClause,
    SingletonExpression,
    SkipExpression,
    SortByItem,
    SortClause,
    TakeExpression,
    TimeLiteral,
    TupleElement,
    TupleExpression,
    TupleTypeSpecifier,
    TypeSpecifier,
    UnaryExpression,
    UsingDefinition,
    ValueSetDefinition,
    WhereClause,
    WithClause,
    ChoiceTypeSpecifier,
)
from ..parser.lexer import Lexer, Token, TokenType

# Bare date-time precision keywords that may appear as a `convert .. to`
# unit target (CQL 2.0 grammar: unit : dateTimePrecision |
# pluralDateTimePrecision | STRING).
_PRECISION_UNIT_TOKENS = (
    TokenType.YEAR, TokenType.MONTH, TokenType.WEEK, TokenType.DAY,
    TokenType.HOUR, TokenType.MINUTE, TokenType.SECOND, TokenType.MILLISECOND,
    TokenType.YEARS, TokenType.MONTHS, TokenType.WEEKS, TokenType.DAYS,
    TokenType.HOURS, TokenType.MINUTES, TokenType.SECONDS, TokenType.MILLISECONDS,
)


class CQLParser:
    """
    Recursive descent parser for CQL R1.5.

    This parser uses the tokens produced by the Lexer to construct
    an Abstract Syntax Tree (AST) representing the CQL program structure.

    Operator Precedence (lowest to highest):
        - implies
        - or, xor
        - and
        - membership (in, contains)
        - equality (=, !=, ~, !~)
        - comparison (<, >, <=, >=) and interval/timing operators
        - type operator (is, as)
        - addition (+, -, &, |)
        - multiplication (*, /, div, mod)
        - power (^)
        - unary (not, -, exists, distinct)
        - postfix (., [], ())
        - primary
    """

    def __init__(self, tokens: List[Token]):
        """
        Initialize the parser with a list of tokens.

        Args:
            tokens: List of tokens from the lexer.
        """
        self.tokens = tokens
        self.pos = 0

    # =========================================================================
    # Helper Methods
    # =========================================================================

    def current(self) -> Token:
        """Get the current token, skipping comments."""
        self._skip_comments()
        if self.pos >= len(self.tokens):
            return self.tokens[-1]  # Return EOF
        return self.tokens[self.pos]

    def peek(self, offset: int = 1) -> Token:
        """
        Look ahead at a token without advancing, skipping comments.

        Args:
            offset: Number of tokens to look ahead (default 1).
        """
        peek_pos = self.pos + offset
        while peek_pos < len(self.tokens) and self.tokens[peek_pos].type in (TokenType.LINE_COMMENT, TokenType.BLOCK_COMMENT):
            peek_pos += 1
        if peek_pos >= len(self.tokens):
            return self.tokens[-1]  # Return EOF
        return self.tokens[peek_pos]

    def advance(self) -> Token:
        """Move to the next token and return the previous one."""
        token = self.current()
        self.pos += 1
        return token

    def _skip_comments(self) -> None:
        """Skip over comment tokens (LINE_COMMENT and BLOCK_COMMENT)."""
        while self.pos < len(self.tokens) and self.tokens[self.pos].type in (TokenType.LINE_COMMENT, TokenType.BLOCK_COMMENT):
            self.pos += 1

    def match(self, *types: TokenType) -> bool:
        """
        Check if current token matches any of the given types.

        Args:
            types: Token types to match.
        """
        return self.current().type in types

    def check(self, token_type: TokenType) -> bool:
        """Check if current token is of the given type."""
        return self.current().type == token_type

    def expect(self, token_type: TokenType, message: str) -> Token:
        """
        Expect a specific token type or raise an error.

        Args:
            token_type: Expected token type.
            message: Error message if expectation fails.
        """
        if self.current().type != token_type:
            token = self.current()
            raise ParseError(
                f"{message}. Got {token.type.name} '{token.value}'",
                position=(token.line, token.column),
            )
        return self.advance()

    def match_and_advance(self, *types: TokenType) -> Optional[Token]:
        """
        Match and consume if current token matches any of the given types.

        Args:
            types: Token types to match.
        """
        if self.match(*types):
            return self.advance()
        return None

    # =========================================================================
    # Library Structure Parsing
    # =========================================================================

    def parse_library(self) -> Library:
        """
        Parse a complete CQL library.

        This is the main entry point for parsing CQL source code.
        """
        # CQL 2.0 directives (trial-use, FHIR-41326): zero or more '#'
        # directives may precede the library declaration.
        directives: List[Directive] = []
        while self.check(TokenType.HASH):
            directives.append(self._parse_directive())

        # Parse library declaration
        self.expect(TokenType.LIBRARY, "Expected 'library' declaration")
        identifier = self._parse_identifier_name()
        # PAR-008: the grammar's libraryIdentifier is a qualifiedIdentifier —
        # `library a.b.C` is valid. Join dotted parts.
        while self.match_and_advance(TokenType.DOT):
            identifier += "." + self._parse_identifier_name()
        version = None

        # Optional version
        if self.match_and_advance(TokenType.VERSION):
            version_token = self.expect(TokenType.STRING, "Expected version string")
            version = version_token.value

        library = Library(identifier=identifier, version=version, directives=directives)

        # Parse library body
        while not self.check(TokenType.EOF):
            self._parse_library_element(library)

        self._check_multiple_versions(library)

        return library

    def _check_multiple_versions(self, library: Library) -> None:
        """CQL 2.0 (FHIR-57620) multi-version constraints.

        Developer's Guide (post-reconciliation 2.0 text):

        * "A given library SHALL NOT include multiple versions of the same
          library."
        * "Multiple versions of the same model SHALL NOT be referenced in
          the same library."

        Only explicitly-DIFFERENT version specifiers are "multiple
        versions"; an unversioned reference alongside a versioned one is
        left to the implementation environment (it resolves to whatever
        version the environment supplies). Discrepancies arriving
        transitively through included libraries are also an
        implementation-environment concern and are not checked here.
        """
        model_versions: dict[str, Optional[str]] = {}
        for using in library.using:
            # Compare on the unqualified model name: the same model may be
            # referenced with or without namespace qualifiers.
            unqualified = using.model.rsplit(".", 1)[-1]
            seen = model_versions.get(unqualified, _UNSET)
            if (
                seen is not _UNSET
                and seen is not None
                and using.version is not None
                and seen != using.version
            ):
                token = self.current()
                raise ParseError(
                    "Multiple versions of the same model SHALL NOT be "
                    f"referenced in the same library (model '{unqualified}' "
                    f"referenced with version "
                    f"{_version_display(seen)} and "
                    f"{_version_display(using.version)}) "
                    "[CQL 2.0, FHIR-57620]",
                    position=(token.line, token.column),
                )
            model_versions[unqualified] = (
                using.version
                # AMUX-152 #15: an unversioned reference must NOT
                # overwrite a stored version with None — that masks a
                # later differently-versioned reference as no-conflict.
                # Keep the first non-None version.
                if (using.version is not None or seen is _UNSET)
                else seen
            )

        library_versions: dict[str, Optional[str]] = {}
        for inc in library.includes:
            seen = library_versions.get(inc.path, _UNSET)
            if (
                seen is not _UNSET
                and seen is not None
                and inc.version is not None
                and seen != inc.version
            ):
                token = self.current()
                raise ParseError(
                    "A library SHALL NOT include multiple versions of the "
                    f"same library ('{inc.path}' included with version "
                    f"{_version_display(seen)} and "
                    f"{_version_display(inc.version)}) "
                    "[CQL 2.0, FHIR-57620]",
                    position=(token.line, token.column),
                )
            # AMUX-152 #15: keep the first non-None version — an
            # unversioned include must not mask a later version conflict.
            library_versions[inc.path] = (
                inc.version if (inc.version is not None or seen is _UNSET) else seen
            )

    def _parse_directive(self) -> Directive:
        """Parse a CQL 2.0 ``#`` directive (trial-use, FHIR-41326).

        Grammar (HL7/cql master ``cql.g4``)::

            directive : '#' identifier (':' STRING)? ;

        The Developer's Guide additionally shows unquoted values and, for
        ``#DefaultComparisonPrecision``, an inclusion-behavior clause::

            #DefaultComparisonPrecision: minutes
            #DefaultComparisonPrecision: 'minutes' check included libraries

        Both spellings are accepted: the value may be a quoted STRING or a
        temporal-precision keyword, optionally followed by one of the three
        ``<default|override|check> included libraries`` clauses.
        """
        hash_token = self.expect(TokenType.HASH, "Expected '#' directive")
        name_token = self.current()
        if name_token.type not in (TokenType.IDENTIFIER, TokenType.QUOTED_IDENTIFIER) and not (
            name_token.type.name in _DIRECTIVE_NAME_TOKENS
        ):
            raise ParseError(
                f"Expected directive identifier after '#' at line "
                f"{name_token.line}, column {name_token.column}",
                position=(name_token.line, name_token.column),
            )
        name = name_token.value
        self.advance()

        value: Optional[str] = None
        inclusion_behavior: Optional[str] = None

        if self.match_and_advance(TokenType.COLON):
            value_token = self.current()
            if value_token.type == TokenType.STRING:
                value = value_token.value
                # Normalize plural precision spellings to the singular
                # comparison precision ('minutes' -> 'minute'), exactly
                # like the unquoted token branch — the directive grammar
                # accepts quoted precision strings and the quoted form is
                # equivalent to the unquoted one (AMUX-152 #5).
                lowered = value.lower()
                if lowered.endswith("s") and lowered[:-1] in _COMPARISON_PRECISIONS:
                    value = lowered[:-1]
                self.advance()
            elif value_token.type.name in _DIRECTIVE_PRECISION_TOKENS:
                value = value_token.value.lower()
                # Normalize plural precision spellings to the singular
                # comparison precision ('minutes' -> 'minute').
                if value.endswith("s") and value[:-1] in _COMPARISON_PRECISIONS:
                    value = value[:-1]
                self.advance()
            else:
                raise ParseError(
                    f"Expected a quoted string or precision value after "
                    f"'#:{name}:' at line {value_token.line}, column "
                    f"{value_token.column}",
                    position=(value_token.line, value_token.column),
                )

            # Optional inclusion-behavior clause (only meaningful for
            # DefaultComparisonPrecision; rejected elsewhere below).
            behavior = self._try_parse_inclusion_behavior()
            if behavior is not None:
                inclusion_behavior = behavior
                if name != "DefaultComparisonPrecision":
                    raise ParseError(
                        f"Inclusion behavior '{inclusion_behavior}' is only "
                        f"valid on the #DefaultComparisonPrecision directive "
                        f"(found on #{name}) [CQL 2.0, FHIR-41326]",
                        position=(hash_token.line, hash_token.column),
                    )

        return Directive(name=name, value=value, inclusion_behavior=inclusion_behavior)

    def _try_parse_inclusion_behavior(self) -> Optional[str]:
        """Parse an optional ``<default|override|check> included libraries`` clause.

        Returns the clause string (e.g. ``default included libraries``) or
        None when the next tokens do not form one.
        """
        first = self.current()
        if first.type == TokenType.DEFAULT:
            mode = "default"
        elif first.type == TokenType.IDENTIFIER and first.value in ("override", "check"):
            mode = first.value
        else:
            return None
        self.advance()

        included_token = self.current()
        if included_token.type != TokenType.INCLUDED_IN or included_token.value != "included":
            raise ParseError(
                f"Expected 'included libraries' after '{mode}' in directive "
                f"inclusion behavior at line {included_token.line}, column "
                f"{included_token.column} [CQL 2.0, FHIR-41326]",
                position=(included_token.line, included_token.column),
            )
        self.advance()

        libraries_token = self.current()
        if libraries_token.type != TokenType.IDENTIFIER or libraries_token.value != "libraries":
            raise ParseError(
                f"Expected 'libraries' after '{mode} included' in directive "
                f"inclusion behavior at line {libraries_token.line}, column "
                f"{libraries_token.column} [CQL 2.0, FHIR-41326]",
                position=(libraries_token.line, libraries_token.column),
            )
        self.advance()

        return f"{mode} included libraries"

    def _parse_library_element(self, library: Library) -> None:
        """Parse a library element (using, include, define, etc.)."""
        if self.match(TokenType.USING):
            library.using.append(self.parse_using_definition())
        elif self.match(TokenType.INCLUDE):
            library.includes.append(self.parse_include_definition())
        elif self.match(TokenType.CODESYSTEM):
            library.codesystems.append(self.parse_codesystem_definition())
        elif self.match(TokenType.VALUESYSTEM):
            library.valuesets.append(self.parse_valueset_definition())
        elif self.match(TokenType.CODE):
            library.codes.append(self.parse_code_definition())
        elif self.match(TokenType.CONCEPT):
            library.concepts.append(self.parse_concept_definition())
        elif self.match(TokenType.PARAMETER):
            library.parameters.append(self.parse_parameter_definition())
        elif self.match(TokenType.CONTEXT):
            library.context = self.parse_context_definition()
        elif self.match(TokenType.DEFINE):
            statement = self._parse_define_statement()
            if isinstance(statement, FunctionDefinition):
                library.statements.append(statement)
            else:
                library.statements.append(statement)
        else:
            token = self.current()
            raise ParseError(
                f"Unexpected token in library: {token.type.name} '{token.value}'",
                position=(token.line, token.column),
            )

    def parse_using_definition(self) -> UsingDefinition:
        """Parse a using definition (e.g., 'using FHIR version \"4.0.1\"')."""
        self.expect(TokenType.USING, "Expected 'using'")
        model = self._parse_identifier_name()
        # FHIR-31019 (CQL 2.0): qualified model names — hl7.fhir.us.core.USCore
        while self.match(TokenType.DOT):
            self.advance()  # consume DOT
            model = f"{model}.{self._parse_identifier_name()}"

        version = None
        alias = None

        if self.match_and_advance(TokenType.VERSION):
            version_token = self.expect(TokenType.STRING, "Expected version string")
            version = version_token.value

        # FHIR-48762 (CQL 2.0): model aliases — `using X version 'y' called Z`.
        # When absent, the unqualified model name is the local identifier.
        if self.match_and_advance(TokenType.CALLED):
            alias = self._parse_identifier_name()

        return UsingDefinition(model=model, version=version, alias=alias)

    def parse_include_definition(self) -> IncludeDefinition:
        """Parse an include definition."""
        self.expect(TokenType.INCLUDE, "Expected 'include'")
        path = self._parse_identifier_name()
        # Consume additional .segment parts for namespaced paths
        # e.g. hl7.fhir.uv.cql.FHIRHelpers
        while self.match(TokenType.DOT):
            self.advance()  # consume DOT
            segment = self._parse_identifier_name()
            path = f"{path}.{segment}"

        version = None
        alias = None
        bindings = None

        if self.match_and_advance(TokenType.VERSION):
            version_token = self.expect(TokenType.STRING, "Expected version string")
            version = version_token.value

        if self.match_and_advance(TokenType.CALLED):
            alias = self._parse_identifier_name()

        # CQL 2.0 (FHIR-33126, trial-use): 'bind' tupleSelector supplying
        # values for parameters in the included library:
        #   include X called C bind { AsOf: end of "Measurement Period" }
        if (
            self.match(TokenType.IDENTIFIER)
            and self.current().value == "bind"
            and self.peek(1).type == TokenType.LBRACE
        ):
            self.advance()  # consume 'bind'
            bindings = self._parse_bind_tuple_selector()

        return IncludeDefinition(path=path, version=version, alias=alias, bindings=bindings)

    def _parse_bind_tuple_selector(self):
        """Parse the ``{ Param: expr, ... }`` tuple of an include ``bind`` clause."""
        self.expect(TokenType.LBRACE, "Expected '{' to open bind clause")
        bindings = {}
        if self.match_and_advance(TokenType.RBRACE):
            raise ParseError(
                "Include bind clause must bind at least one parameter "
                "(empty '{}' is not allowed) [CQL 2.0, FHIR-33126]"
            )
        while True:
            name_token = self.current()
            name = self._parse_identifier_name()
            if name in bindings:
                raise ParseError(
                    f"Duplicate parameter binding '{name}' in include bind "
                    f"clause at line {name_token.line}, column "
                    f"{name_token.column} [CQL 2.0, FHIR-33126]",
                    position=(name_token.line, name_token.column),
                )
            self.expect(
                TokenType.COLON,
                f"Expected ':' after parameter name '{name}' in bind clause",
            )
            bindings[name] = self.parse_expression()
            if self.match_and_advance(TokenType.COMMA):
                continue
            self.expect(TokenType.RBRACE, "Expected '}' to close bind clause")
            break
        return bindings

    def parse_parameter_definition(self) -> ParameterDefinition:
        """Parse a parameter definition."""
        self.expect(TokenType.PARAMETER, "Expected 'parameter'")
        name = self._parse_identifier_name()
        param_type = None
        default = None

        # Optional type specifier
        if self.match(TokenType.IDENTIFIER, TokenType.QUOTED_IDENTIFIER,
                      TokenType.BOOLEAN, TokenType.INTEGER_TYPE, TokenType.LONG_TYPE, TokenType.DECIMAL_TYPE,
                      TokenType.STRING_TYPE, TokenType.DATE_TYPE, TokenType.DATETIME_TYPE,
                      TokenType.TIME_TYPE, TokenType.QUANTITY, TokenType.INTERVAL,
                      TokenType.LIST_TYPE, TokenType.TUPLE, TokenType.CHOICE,
                      TokenType.CODE_TYPE, TokenType.CONCEPT_TYPE, TokenType.CODESYSTEM_TYPE,
                      TokenType.VALUESET_TYPE, TokenType.ANY,
                      TokenType.RESOURCE, TokenType.PATIENT, TokenType.PRACTITIONER,
                      TokenType.ORGANIZATION, TokenType.LOCATION, TokenType.BUNDLE,
                      TokenType.DATE_FROM, TokenType.TIME_FROM,
                      TokenType.CODE, TokenType.CONCEPT):
            param_type = self.parse_type_specifier()

        # Optional default value
        if self.match_and_advance(TokenType.DEFAULT):
            default = self.parse_expression()

        return ParameterDefinition(name=name, type=param_type, default=default)

    def parse_context_definition(self) -> ContextDefinition:
        """Parse a context definition."""
        self.expect(TokenType.CONTEXT, "Expected 'context'")
        name = self._parse_identifier_name()
        return ContextDefinition(name=name)

    def _parse_define_statement(self) -> Union[Definition, FunctionDefinition]:
        """Parse a define statement (expression or function)."""
        self.expect(TokenType.DEFINE, "Expected 'define'")

        # PAR-008: accessModifier — `define private X: ...` / `define public
        # X: ...`. 'private'/'public' are not lexer keywords; treat an
        # IDENTIFIER with exactly that spelling as the modifier. Per the
        # grammar the modifier also precedes function definitions
        # (`define private fluent function F(...)`) and comes BEFORE 'fluent'.
        access_level = None
        if (
            self.match(TokenType.IDENTIFIER)
            and self.current().value in ("private", "public")
            and self.peek(1).type in (
                TokenType.IDENTIFIER,
                TokenType.QUOTED_IDENTIFIER,
                TokenType.FUNCTION,
                TokenType.FLUENT,
            )
        ):
            access_level = self.advance().value

        # CQL 2.0 model-definition statements (trial-use): `define type`,
        # `define context <X> of type ...`, and
        # `define implicit|explicit conversion ...`. These keywords lex as
        # plain identifiers, so disambiguate against an expression define
        # (whose name would be followed by ':') by lookahead.
        _tok = self.current()
        _tok_val = getattr(_tok, "value", "")
        if (
            _tok.type == TokenType.IDENTIFIER
            and _tok_val == "type"
            and self.peek(1).type in (TokenType.IDENTIFIER, TokenType.QUOTED_IDENTIFIER)
        ):
            return self._parse_type_definition(access_level)
        if (
            _tok.type == TokenType.CONTEXT
            and self.peek(1).type != TokenType.COLON
            and self.peek(2).type == TokenType.OF
        ):
            return self._parse_context_info_definition(access_level)
        if (
            _tok.type == TokenType.IDENTIFIER
            and _tok_val in ("implicit", "explicit")
            and getattr(self.peek(1), "value", "") == "conversion"
        ):
            return self._parse_conversion_definition(access_level)

        # Check for fluent function definition
        is_fluent = self.match(TokenType.FLUENT)
        if is_fluent:
            self.advance()  # consume FLUENT token

        # Check for function definition
        if self.match_and_advance(TokenType.FUNCTION):
            return self._parse_function_definition(
                fluent=is_fluent, access_level=access_level
            )

        name = self._parse_identifier_name()
        self.expect(TokenType.COLON, "Expected ':' after definition name")

        expression = self.parse_expression()
        return Definition(name=name, expression=expression, access_level=access_level)

    def _parse_type_definition(self, access_level: Optional[str] = None) -> TypeDefinition:
        """Parse a CQL 2.0 `define type` declaration (FHIR-34014, trial-use).

        Grammar: 'define' accessModifier? 'type' qualifiedIdentifier
        baseTypeSpecifier? typeElements? typeInfo contextRelationship*
        """
        self._expect_keyword("type")
        name = self._parse_identifier_name()
        while self.match_and_advance(TokenType.DOT):
            # The grammar admits a qualified identifier; keep the full name
            # (namespace-qualified declarations register under the last
            # segment for local reference).
            name = f"{name}.{self._parse_identifier_name()}"

        base_type = None
        if self._match_keyword("extends"):
            base_type = self._parse_named_type_specifier()

        elements = []
        if self.match_and_advance(TokenType.LBRACE):
            while not self.match(TokenType.RBRACE):
                elem_name = self._parse_identifier_name()
                elem_type = self.parse_type_specifier()
                elements.append(TypeElement(name=elem_name, type_specifier=elem_type))
                if not self.match_and_advance(TokenType.COMMA):
                    break
            self.expect(TokenType.RBRACE, "Expected '}' closing type elements")

        # typeInfo clause: ('label' identifier)? ('identifier' STRING)?
        # 'retrievable'? ('primary' 'code' 'path' simplePath)?
        label = None
        identifier = None
        retrievable = False
        primary_code_path = None
        if self._match_keyword("label"):
            label = self._parse_identifier_name()
        if self._match_keyword("identifier"):
            identifier = self.expect(
                TokenType.STRING, "Expected string after 'identifier'"
            ).value
        if self._match_keyword("retrievable"):
            retrievable = True
        if self._match_keyword("primary"):
            self._expect_lexeme("code")
            self._expect_lexeme("path")
            primary_code_path = self._parse_identifier_name()
            while self.match_and_advance(TokenType.DOT):
                primary_code_path = f"{primary_code_path}.{self._parse_identifier_name()}"

        # contextRelationship*: 'related' 'to' qualifiedIdentifier 'by'
        # '{' qualifiedIdentifierOrFunctionIdentifier (',' ...)* '}'
        relationships = []
        while self._match_keyword("related"):
            self._expect_keyword("to")
            ctx_name = self._parse_identifier_name()
            while self.match_and_advance(TokenType.DOT):
                ctx_name = f"{ctx_name}.{self._parse_identifier_name()}"
            self._expect_keyword("by")
            self.expect(TokenType.LBRACE, "Expected '{' after 'by'")
            keys = [self._parse_identifier_name()]
            while self.match_and_advance(TokenType.COMMA):
                keys.append(self._parse_identifier_name())
            self.expect(TokenType.RBRACE, "Expected '}' after relationship keys")
            relationships.append(ContextRelationship(context=ctx_name, key_elements=keys))

        return TypeDefinition(
            name=name,
            base_type=base_type,
            elements=elements,
            access_level=access_level or "public",
            label=label,
            identifier=identifier,
            retrievable=retrievable,
            primary_code_path=primary_code_path,
            context_relationships=relationships,
        )

    def _parse_context_info_definition(
        self, access_level: Optional[str] = None
    ) -> ContextInfoDefinition:
        """Parse a CQL 2.0 `define context X of type T with key { ... }`
        model declaration (trial-use)."""
        self.expect(TokenType.CONTEXT, "Expected 'context'")
        name = self._parse_identifier_name()
        self.expect(TokenType.OF, "Expected 'of'")
        self._expect_keyword("type")
        context_type = self._parse_named_type_specifier()
        key_elements = []
        if self.match_and_advance(TokenType.WITH):
            self._expect_keyword("key")
            self.expect(TokenType.LBRACE, "Expected '{' after 'key'")
            key_elements = [self._parse_identifier_name()]
            while self.match_and_advance(TokenType.COMMA):
                key_elements.append(self._parse_identifier_name())
            self.expect(TokenType.RBRACE, "Expected '}' after key elements")
        return ContextInfoDefinition(
            name=name, context_type=context_type, key_elements=key_elements
        )

    def _parse_conversion_definition(
        self, access_level: Optional[str] = None
    ) -> ConversionDefinition:
        """Parse a CQL 2.0 `define implicit|explicit conversion from A to B
        using Func` declaration (trial-use)."""
        implicit_ = self.advance().value == "implicit"
        self._expect_keyword("conversion")
        self.expect(TokenType.FROM, "Expected 'from'")
        from_type = self.parse_type_specifier()
        self.expect(TokenType.TO, "Expected 'to'")
        to_type = self.parse_type_specifier()
        self.expect(TokenType.USING, "Expected 'using'")
        func_name = self._parse_identifier_name()
        while self.match_and_advance(TokenType.DOT):
            func_name = f"{func_name}.{self._parse_identifier_name()}"
        return ConversionDefinition(
            from_type=from_type,
            to_type=to_type,
            function_name=func_name,
            implicit_=implicit_,
            access_level=access_level or "public",
        )

    def _match_keyword(self, keyword: str) -> bool:
        """Match a plain-identifier lexeme (non-keyword grammar word)."""
        tok = self.current()
        if tok is not None and tok.type == TokenType.IDENTIFIER and tok.value == keyword:
            self.advance()
            return True
        return False

    def _expect_keyword(self, keyword: str):
        tok = self.current()
        if tok is None or tok.value != keyword:
            got = getattr(tok, "value", "<eof>")
            raise ParseError(message=f"Expected '{keyword}'. Got '{got}'")
        self.advance()

    def _expect_lexeme(self, word: str):
        """Expect a lexeme by VALUE regardless of its token type (grammar
        words that the lexer promotes to keywords, e.g. 'code')."""
        tok = self.current()
        if tok is None or tok.value != word:
            got = getattr(tok, "value", "<eof>")
            raise ParseError(message=f"Expected '{word}'. Got '{got}'")
        self.advance()

    def _parse_function_definition(
        self, fluent: bool = False, access_level: Optional[str] = None
    ) -> FunctionDefinition:
        """Parse a function definition.

        Args:
            fluent: Whether this is a fluent function definition.
            access_level: Optional 'public'/'private' access modifier.
        """
        name = self._parse_identifier_name()
        self.expect(TokenType.LPAREN, "Expected '(' after function name")

        parameters = []
        if not self.check(TokenType.RPAREN):
            parameters.append(self._parse_parameter_def())
            while self.match_and_advance(TokenType.COMMA):
                parameters.append(self._parse_parameter_def())

        self.expect(TokenType.RPAREN, "Expected ')' after parameters")

        return_type = None
        # Check for 'returns' keyword or colon for return type
        if self.match_and_advance(TokenType.RETURNS):
            return_type = self.parse_type_specifier()

        expression = None
        if self.match_and_advance(TokenType.COLON):
            expression = self.parse_expression()

        return FunctionDefinition(
            name=name,
            parameters=parameters,
            return_type=return_type,
            expression=expression,
            access_level=access_level,
            fluent=fluent,
        )

    def _parse_parameter_def(self) -> ParameterDef:
        """Parse a function parameter definition."""
        name = self._parse_identifier_name()
        param_type = None
        default = None

        # Type can be specified with or without colon
        if self.match_and_advance(TokenType.COLON):
            param_type = self.parse_type_specifier()
        elif self.match(TokenType.IDENTIFIER, TokenType.QUOTED_IDENTIFIER,
                        TokenType.BOOLEAN, TokenType.INTEGER_TYPE, TokenType.LONG_TYPE, TokenType.DECIMAL_TYPE,
                        TokenType.STRING_TYPE, TokenType.DATE_TYPE, TokenType.DATETIME_TYPE,
                        TokenType.TIME_TYPE, TokenType.QUANTITY, TokenType.INTERVAL,
                        TokenType.LIST_TYPE, TokenType.TUPLE, TokenType.CHOICE,
                        TokenType.CODE_TYPE, TokenType.CONCEPT_TYPE, TokenType.CODESYSTEM_TYPE,
                        TokenType.VALUESET_TYPE, TokenType.ANY,
                        TokenType.RESOURCE, TokenType.PATIENT, TokenType.PRACTITIONER,
                        TokenType.ORGANIZATION, TokenType.LOCATION, TokenType.BUNDLE,
                        TokenType.DATE_FROM, TokenType.TIME_FROM,
                        TokenType.CODE, TokenType.CONCEPT):
            param_type = self.parse_type_specifier()

        if self.match_and_advance(TokenType.EQUALS):
            default = self.parse_expression()

        return ParameterDef(name=name, type=param_type, default=default)

    def parse_codesystem_definition(self) -> CodeSystemDefinition:
        """Parse a codesystem definition."""
        self.expect(TokenType.CODESYSTEM, "Expected 'codesystem'")
        name = self._parse_identifier_name()
        self.expect(TokenType.COLON, "Expected ':' after codesystem name")

        id_token = self.expect(TokenType.STRING, "Expected codesystem identifier")
        codesystem_id = id_token.value
        version = None

        if self.match_and_advance(TokenType.VERSION):
            version_token = self.expect(TokenType.STRING, "Expected version string")
            version = version_token.value

        return CodeSystemDefinition(name=name, id=codesystem_id, version=version)

    def parse_valueset_definition(self) -> ValueSetDefinition:
        """Parse a valueset definition."""
        self.expect(TokenType.VALUESYSTEM, "Expected 'valueset'")
        name = self._parse_identifier_name()
        self.expect(TokenType.COLON, "Expected ':' after valueset name")

        id_token = self.expect(TokenType.STRING, "Expected valueset identifier")
        valueset_id = id_token.value
        version = None
        codesystem = None
        codesystems = []

        if self.match_and_advance(TokenType.VERSION):
            version_token = self.expect(TokenType.STRING, "Expected version string")
            version = version_token.value

        if self.match(TokenType.IDENTIFIER) and self.current().value == "codesystems":
            self.advance()
            self.expect(TokenType.LBRACE, "Expected '{' after valueset codesystems")
            if self.check(TokenType.RBRACE):
                token = self.current()
                raise ParseError(
                    "Expected codesystem identifier in valueset codesystems",
                    position=(token.line, token.column),
                )
            while True:
                code_system_name = self._parse_identifier_name()
                while self.match_and_advance(TokenType.DOT):
                    code_system_name = code_system_name + "." + self._parse_identifier_name()
                codesystems.append(code_system_name)
                if not self.match_and_advance(TokenType.COMMA):
                    break
                if self.check(TokenType.RBRACE):
                    token = self.current()
                    raise ParseError(
                        "Expected codesystem identifier after ',' in valueset codesystems",
                        position=(token.line, token.column),
                    )
            self.expect(TokenType.RBRACE, "Expected '}' after valueset codesystems")
            if codesystems:
                codesystem = codesystems[0]

        return ValueSetDefinition(
            name=name,
            id=valueset_id,
            version=version,
            codesystem=codesystem,
            codesystems=codesystems,
        )

    def parse_code_definition(self) -> CodeDefinition:
        """Parse a code definition."""
        self.expect(TokenType.CODE, "Expected 'code'")
        name = self._parse_identifier_name()
        self.expect(TokenType.COLON, "Expected ':' after code name")

        code_token = self.expect(TokenType.STRING, "Expected code value")
        code_value = code_token.value

        self.expect(TokenType.FROM, "Expected 'from' before codesystem reference")
        codesystem = self._parse_identifier_name()
        # Support qualified codesystem references like QICoreCommon."SNOMEDCT"
        while self.match_and_advance(TokenType.DOT):
            codesystem = codesystem + "." + self._parse_identifier_name()

        display = None
        if self.match_and_advance(TokenType.DISPLAY):
            display_token = self.expect(TokenType.STRING, "Expected display string")
            display = display_token.value

        return CodeDefinition(name=name, codesystem=codesystem, code=code_value, display=display)

    def parse_concept_definition(self) -> ConceptDefinition:
        """Parse a concept definition."""
        self.expect(TokenType.CONCEPT, "Expected 'concept'")
        name = self._parse_identifier_name()
        self.expect(TokenType.COLON, "Expected ':' after concept name")

        codes = []

        if self.match_and_advance(TokenType.LBRACE):
            # Parse code list
            while not self.check(TokenType.RBRACE):
                if self.match(TokenType.CODE):
                    codes.append(self.parse_code_definition())
                elif self.match(TokenType.IDENTIFIER, TokenType.QUOTED_IDENTIFIER):
                    codes.append(self._parse_identifier_name())

                if not self.match_and_advance(TokenType.COMMA):
                    break

            self.expect(TokenType.RBRACE, "Expected '}' after concept codes")

        display = None
        if self.match_and_advance(TokenType.DISPLAY):
            display_token = self.expect(TokenType.STRING, "Expected display string")
            display = display_token.value

        return ConceptDefinition(name=name, codes=codes, display=display)

    # =========================================================================
    # Expression Parsing with Precedence
    # =========================================================================

    def parse_expression(self) -> Expression:
        """Entry point for expression parsing."""
        return self.parse_implies_expression()

    def parse_implies_expression(self) -> Expression:
        """Parse IMPLIES expression."""
        left = self.parse_or_expression()

        while self.match_and_advance(TokenType.IMPLIES):
            right = self.parse_or_expression()
            left = BinaryExpression(operator="implies", left=left, right=right)

        return left

    def parse_or_expression(self) -> Expression:
        """Parse OR/XOR disjunction expressions."""
        left = self.parse_and_expression()

        while self.match(TokenType.OR, TokenType.XOR):
            operator = "or" if self.current().type == TokenType.OR else "xor"
            self.advance()
            right = self.parse_and_expression()
            left = BinaryExpression(operator=operator, left=left, right=right)

        return left

    def parse_not_expression(self) -> Expression:
        """Parse the operand tier for and/or/xor/implies.

        Unary ``not`` binds TIGHTER than and/or/xor/implies, so a NOT
        primary is consumed by the equality/comparison operand tiers below
        (:meth:`parse_equality_operand` / :meth:`parse_comparison_operand`)
        and this tier is simply the equality level. See the grammar
        analysis on :meth:`parse_equality_operand`.
        """
        return self.parse_equality_expression()

    def parse_not_operand(self) -> Expression:
        """Operand tier for unary ``not`` (typeExpression level).

        Per the official CQL grammar (HL7/cql v1.5 ``cql.g4``, verified
        empirically with an ANTLR 4.13.1-generated parser), earlier
        ``expression`` alternatives bind TIGHTER. ``#notExpression`` is
        listed AFTER ``is [not] null/true/false`` and ``is``/``as`` but
        BEFORE between/set/inequality/equality/membership/and/or/implies,
        so the operand of ``not`` is parsed at the typeExpression level:
        ``not X is null`` is ``not (X is null)``, while ``not A = B`` is
        ``(not A) = B`` and ``not X in Y`` is ``(not X) in Y`` (both static
        type errors unless the operand is Boolean).
        """
        if self.match_and_advance(TokenType.NOT):
            operand = self.parse_not_operand()
            return UnaryExpression(operator="not", operand=operand)
        return self.parse_type_expression()

    def parse_and_expression(self) -> Expression:
        """Parse AND expression."""
        left = self.parse_not_expression()

        while self.match_and_advance(TokenType.AND):
            right = self.parse_not_expression()
            left = BinaryExpression(operator="and", left=left, right=right)

        return left

    def parse_equality_expression(self) -> Expression:
        """Parse equality expression (=, !=, ~, !~)."""
        left = self.parse_equality_operand()

        while True:
            if self.match_and_advance(TokenType.EQUALS):
                right = self.parse_equality_operand()
                left = BinaryExpression(operator="=", left=left, right=right)
            elif self.match_and_advance(TokenType.NOT_EQUALS):
                right = self.parse_equality_operand()
                left = BinaryExpression(operator="!=", left=left, right=right)
            elif self.match(TokenType.TILDE) and self.peek(1).type in (TokenType.IN, TokenType.CONTAINS):
                # CQL 2.0 equivalence membership: '~in' / '~contains' (the
                # equality-tier TILDE must not consume the tilde here).
                self.advance()  # consume TILDE
                membership_op = "in" if self.match_and_advance(TokenType.IN) else (
                    "contains" if self.match_and_advance(TokenType.CONTAINS) else None
                )
                right = self.parse_type_expression()
                left = BinaryExpression(operator=f"~{membership_op}", left=left, right=right)
            elif self.match_and_advance(TokenType.TILDE):
                right = self.parse_equality_operand()
                left = BinaryExpression(operator="~", left=left, right=right)
            elif self.match_and_advance(TokenType.NOT_EQUIVALENT):
                right = self.parse_equality_operand()
                left = BinaryExpression(operator="!~", left=left, right=right)
            else:
                break

        return left

    def parse_equality_operand(self) -> Expression:
        """Operand tier for ``=``/``!=``/``~``/``!~``.

        Unary ``not`` binds tighter than equality per the official grammar,
        so a NOT primary may be the (left or right) operand of an equality
        comparison: ``not true = false`` parses as ``(not true) = false``.
        The NOT's own operand is parsed at the typeExpression level
        (:meth:`parse_not_operand`), and any comparison/membership operators
        following the NOT primary attach to it (``not 3 < 2`` is
        ``(not 3) < 2``).
        """
        if self.match_and_advance(TokenType.NOT):
            operand = self.parse_not_operand()
            return self.parse_comparison_expression(
                left=UnaryExpression(operator="not", operand=operand)
            )
        return self.parse_comparison_expression()

    def parse_comparison_expression(self, left: Expression | None = None) -> Expression:
        """Parse comparison expression (<, >, <=, >=) and list/interval membership operators.

        ``left`` may be supplied by :meth:`parse_equality_operand` when a
        NOT primary starts the expression (e.g. ``(not 5) in {1, 2}``).
        """
        if left is None:
            left = self.parse_type_expression()

        while True:
            if self.match_and_advance(TokenType.LESS_THAN):
                right = self.parse_type_expression()
                left = BinaryExpression(operator="<", left=left, right=right)
            elif self.match_and_advance(TokenType.GREATER_THAN):
                right = self.parse_type_expression()
                left = BinaryExpression(operator=">", left=left, right=right)
            elif self.match_and_advance(TokenType.LESS_EQUAL):
                right = self.parse_type_expression()
                left = BinaryExpression(operator="<=", left=left, right=right)
            elif self.match_and_advance(TokenType.GREATER_EQUAL):
                right = self.parse_type_expression()
                left = BinaryExpression(operator=">=", left=left, right=right)
            # List membership operators
            elif self.match_and_advance(TokenType.IN):
                right = self.parse_type_expression()
                left = BinaryExpression(operator="in", left=left, right=right)
            elif self.match_and_advance(TokenType.CONTAINS):
                right = self.parse_type_expression()
                left = BinaryExpression(operator="contains", left=left, right=right)
            elif self.match_and_advance(TokenType.PROPER_CONTAINS):
                right = self.parse_type_expression()
                left = BinaryExpression(operator="properly contains", left=left, right=right)
            elif self.match_and_advance(TokenType.PROPER_IN):
                right = self.parse_type_expression()
                left = BinaryExpression(operator="properly included in", left=left, right=right)
            # Interval/List inclusion operators
            elif self.match_and_advance(TokenType.INCLUDES):
                right = self.parse_type_expression()
                left = BinaryExpression(operator="includes", left=left, right=right)
            elif self.match_and_advance(TokenType.INCLUDED_IN):
                right = self.parse_type_expression()
                left = BinaryExpression(operator="included in", left=left, right=right)
            # Temporal/Interval operators
            elif self.match_and_advance(TokenType.AFTER):
                # Handle "after or on" = "on or after"
                if self.match(TokenType.OR) and self.peek().type == TokenType.IDENTIFIER and self.peek().value.lower() == "on":
                    self.advance()  # consume 'or'
                    self.advance()  # consume 'on'
                    precision = self._try_parse_precision_of()
                    right = self.parse_type_expression()
                    op = f"on or after {precision} of" if precision else "on or after"
                    left = BinaryExpression(operator=op, left=left, right=right)
                else:
                    # Check for precision specifier: after year of, after month of, etc.
                    precision = self._try_parse_precision_of()
                    if precision:
                        right = self.parse_type_expression()
                        left = BinaryExpression(operator=f"after {precision} of", left=left, right=right)
                    else:
                        right = self._parse_boundary_qualified_operand()
                        left = BinaryExpression(operator="after", left=left, right=right)
            elif self.match_and_advance(TokenType.BEFORE):
                # Handle "before or on" = "on or before"
                if self.match(TokenType.OR) and self.peek().type == TokenType.IDENTIFIER and self.peek().value.lower() == "on":
                    self.advance()  # consume 'or'
                    self.advance()  # consume 'on'
                    precision = self._try_parse_precision_of()
                    right = self.parse_type_expression()
                    op = f"on or before {precision} of" if precision else "on or before"
                    left = BinaryExpression(operator=op, left=left, right=right)
                else:
                    # Check for precision specifier: before year of, before month of, etc.
                    precision = self._try_parse_precision_of()
                    if precision:
                        right = self.parse_type_expression()
                        left = BinaryExpression(operator=f"before {precision} of", left=left, right=right)
                    else:
                        right = self._parse_boundary_qualified_operand()
                        left = BinaryExpression(operator="before", left=left, right=right)
            elif self.match_and_advance(TokenType.DURING):
                right = self.parse_type_expression()
                left = BinaryExpression(operator="during", left=left, right=right)
            elif self.match_and_advance(TokenType.OVERLAPS):
                right = self.parse_type_expression()
                left = BinaryExpression(operator="overlaps", left=left, right=right)
            elif self.match_and_advance(TokenType.OVERLAPS_BEFORE):
                right = self.parse_type_expression()
                left = BinaryExpression(operator="overlaps before", left=left, right=right)
            elif self.match_and_advance(TokenType.OVERLAPS_AFTER):
                right = self.parse_type_expression()
                left = BinaryExpression(operator="overlaps after", left=left, right=right)
            elif self.match_and_advance(TokenType.MEETS):
                right = self.parse_type_expression()
                left = BinaryExpression(operator="meets", left=left, right=right)
            elif self.match_and_advance(TokenType.MEETS_BEFORE):
                right = self.parse_type_expression()
                left = BinaryExpression(operator="meets before", left=left, right=right)
            elif self.match_and_advance(TokenType.MEETS_AFTER):
                right = self.parse_type_expression()
                left = BinaryExpression(operator="meets after", left=left, right=right)
            elif self.match_and_advance(TokenType.STARTS):
                # Handle "starts same [precision] (as|or after|or before) EXPR"
                # temporal operator (CQL 1.5 grammar: 'same' dateTimePrecision?
                # (relativeQualifier | 'as')).
                if self.match(TokenType.IDENTIFIER) and self.current().value.lower() == "same" \
                        and (self.peek().type in (TokenType.AS, TokenType.OR_AFTER, TokenType.OR_BEFORE)
                             or self.peek().type in (
                                 TokenType.YEAR, TokenType.MONTH, TokenType.DAY, TokenType.HOUR,
                                 TokenType.MINUTE, TokenType.SECOND, TokenType.MILLISECOND, TokenType.WEEK)):
                    same_pos = self.pos
                    self.advance()  # consume 'same'
                    # Optionally consume precision unit (e.g. "day" in "same day as")
                    precision = ""
                    if self.match(TokenType.YEAR, TokenType.MONTH, TokenType.DAY, TokenType.HOUR,
                                  TokenType.MINUTE, TokenType.SECOND, TokenType.MILLISECOND, TokenType.WEEK):
                        precision = " " + self.advance().value
                    qualifier = ""
                    if self.match_and_advance(TokenType.AS):
                        qualifier = " as"
                    elif self.match_and_advance(TokenType.OR_AFTER):
                        qualifier = " or after"
                    elif self.match_and_advance(TokenType.OR_BEFORE):
                        qualifier = " or before"
                    if not qualifier:
                        # Grammar (concurrentWithIntervalOperatorPhrase) requires
                        # a qualifier or 'as' after the optional precision. Consume
                        # nothing and surface the leftover tokens instead of
                        # embedding them in the operator string.
                        self.pos = same_pos
                    else:
                        right = self.parse_type_expression()
                        left = BinaryExpression(
                            operator=f"starts same{precision}{qualifier}", left=left, right=right)
                # Handle "starts before or on EXPR" = "starts on or before EXPR"
                elif self.match(TokenType.BEFORE) and self.peek().type == TokenType.OR and \
                        self.peek(2).type == TokenType.IDENTIFIER and self.peek(2).value.lower() == "on":
                    self.advance(); self.advance(); self.advance()
                    precision = self._try_parse_precision_of()
                    right = self.parse_type_expression()
                    op = f"on or before {precision} of" if precision else "on or before"
                    left = BinaryExpression(operator=f"starts {op}", left=left, right=right)
                # Handle "starts after or on EXPR" = "starts on or after EXPR"
                elif self.match(TokenType.AFTER) and self.peek().type == TokenType.OR and \
                        self.peek(2).type == TokenType.IDENTIFIER and self.peek(2).value.lower() == "on":
                    self.advance(); self.advance(); self.advance()
                    precision = self._try_parse_precision_of()
                    right = self.parse_type_expression()
                    op = f"on or after {precision} of" if precision else "on or after"
                    left = BinaryExpression(operator=f"starts {op}", left=left, right=right)
                # Handle "starts within N unit of EXPR" timing operator
                elif self.match(TokenType.IDENTIFIER) and self.current().value.lower() == "within":
                    # Grammar (withinIntervalOperatorPhrase) requires
                    # `within <quantity> <unit> of`; anything less must
                    # surface the leftover tokens, not silently consume them.
                    saved_pos = self.pos
                    self.advance()  # consume 'within'
                    if self.match(TokenType.INTEGER, TokenType.DECIMAL) and self._within_unit_follows():
                        quantity_value = self.advance().value
                        unit = self.advance().value
                        self.expect(TokenType.OF, "Expected 'of' after unit in 'starts within N unit of'")
                        right = self.parse_type_expression()
                        left = BinaryExpression(
                            operator=f"starts within {quantity_value} {unit} of",
                            left=left,
                            right=right,
                        )
                    else:
                        self.pos = saved_pos
                        right = self._try_parse_complex_interval_comparison("starts")
                        if right is None:
                            right = self.parse_type_expression()
                        left = BinaryExpression(operator="starts", left=left, right=right)
                else:
                    # Check for complex temporal comparison pattern:
                    # starts <quantity> or less/or more on or after/on or before <precision> of start of/end of <expr>
                    right = self._try_parse_complex_interval_comparison("starts")
                    if right is None:
                        right = self.parse_type_expression()
                    left = BinaryExpression(operator="starts", left=left, right=right)
            elif self.match_and_advance(TokenType.ENDS):
                # Handle "ends same [precision] (as|or after|or before) EXPR"
                # temporal operator (CQL 1.5 grammar: 'same' dateTimePrecision?
                # (relativeQualifier | 'as')).
                if self.match(TokenType.IDENTIFIER) and self.current().value.lower() == "same" \
                        and (self.peek().type in (TokenType.AS, TokenType.OR_AFTER, TokenType.OR_BEFORE)
                             or self.peek().type in (
                                 TokenType.YEAR, TokenType.MONTH, TokenType.DAY, TokenType.HOUR,
                                 TokenType.MINUTE, TokenType.SECOND, TokenType.MILLISECOND, TokenType.WEEK)):
                    same_pos = self.pos
                    self.advance()  # consume 'same'
                    # Optionally consume precision unit (e.g. "day" in "same day as")
                    precision = ""
                    if self.match(TokenType.YEAR, TokenType.MONTH, TokenType.DAY, TokenType.HOUR,
                                  TokenType.MINUTE, TokenType.SECOND, TokenType.MILLISECOND, TokenType.WEEK):
                        precision = " " + self.advance().value
                    qualifier = ""
                    if self.match_and_advance(TokenType.AS):
                        qualifier = " as"
                    elif self.match_and_advance(TokenType.OR_AFTER):
                        qualifier = " or after"
                    elif self.match_and_advance(TokenType.OR_BEFORE):
                        qualifier = " or before"
                    if not qualifier:
                        # Grammar (concurrentWithIntervalOperatorPhrase) requires
                        # a qualifier or 'as' after the optional precision. Consume
                        # nothing and surface the leftover tokens instead of
                        # embedding them in the operator string.
                        self.pos = same_pos
                    else:
                        right = self.parse_type_expression()
                        left = BinaryExpression(
                            operator=f"ends same{precision}{qualifier}", left=left, right=right)
                # Handle "ends before or on EXPR" = "ends on or before EXPR"
                elif self.match(TokenType.BEFORE) and self.peek().type == TokenType.OR and \
                        self.peek(2).type == TokenType.IDENTIFIER and self.peek(2).value.lower() == "on":
                    self.advance(); self.advance(); self.advance()
                    precision = self._try_parse_precision_of()
                    right = self.parse_type_expression()
                    op = f"on or before {precision} of" if precision else "on or before"
                    left = BinaryExpression(operator=f"ends {op}", left=left, right=right)
                # Handle "ends after or on EXPR" = "ends on or after EXPR"
                elif self.match(TokenType.AFTER) and self.peek().type == TokenType.OR and \
                        self.peek(2).type == TokenType.IDENTIFIER and self.peek(2).value.lower() == "on":
                    self.advance(); self.advance(); self.advance()
                    precision = self._try_parse_precision_of()
                    right = self.parse_type_expression()
                    op = f"on or after {precision} of" if precision else "on or after"
                    left = BinaryExpression(operator=f"ends {op}", left=left, right=right)
                # Handle "ends within N unit of EXPR" timing operator
                elif self.match(TokenType.IDENTIFIER) and self.current().value.lower() == "within":
                    saved_pos = self.pos
                    self.advance()  # consume 'within'
                    if self.match(TokenType.INTEGER, TokenType.DECIMAL) and self._within_unit_follows():
                        quantity_value = self.advance().value
                        unit = self.advance().value
                        self.expect(TokenType.OF, "Expected 'of' after unit in 'ends within N unit of'")
                        right = self.parse_type_expression()
                        left = BinaryExpression(
                            operator=f"ends within {quantity_value} {unit} of",
                            left=left,
                            right=right,
                        )
                    else:
                        self.pos = saved_pos
                        right = self._try_parse_complex_interval_comparison("ends")
                        if right is None:
                            right = self.parse_type_expression()
                        left = BinaryExpression(operator="ends", left=left, right=right)
                else:
                    # Same pattern for ends
                    right = self._try_parse_complex_interval_comparison("ends")
                    if right is None:
                        right = self.parse_type_expression()
                    left = BinaryExpression(operator="ends", left=left, right=right)
            # On or before/after operators
            elif self.match_and_advance(TokenType.ON_OR_AFTER):
                right = self.parse_type_expression()
                left = BinaryExpression(operator="on or after", left=left, right=right)
            elif self.match_and_advance(TokenType.ON_OR_BEFORE):
                right = self.parse_type_expression()
                left = BinaryExpression(operator="on or before", left=left, right=right)
            # Properly modifier for various operators (pre-tokenized multi-word keywords)
            elif self.match_and_advance(TokenType.PROPER_INCLUDES):
                right = self.parse_type_expression()
                left = BinaryExpression(operator="properly includes", left=left, right=right)
            elif self.match_and_advance(TokenType.PROPER_CONTAINS):
                right = self.parse_type_expression()
                left = BinaryExpression(operator="properly contains", left=left, right=right)
            elif self.match_and_advance(TokenType.PROPER_IN):
                right = self.parse_type_expression()
                left = BinaryExpression(operator="properly included in", left=left, right=right)
            # Properly modifier for various operators (when properly is separate token)
            elif self.match(TokenType.PROPERLY):
                # `properly` is only valid inside an intervalOperatorPhrase
                # (CQL 1.5 grammar). If nothing recognizable follows, restore
                # pos so the token surfaces as an unexpected/trailing token
                # instead of being silently discarded (parse_expression("true
                # properly") used to return Literal(True)).
                saved_pos = self.pos
                self.advance()
                if self.match_and_advance(TokenType.INCLUDES):
                    right = self.parse_type_expression()
                    left = BinaryExpression(operator="properly includes", left=left, right=right)
                elif self.match_and_advance(TokenType.CONTAINS):
                    right = self.parse_type_expression()
                    left = BinaryExpression(operator="properly contains", left=left, right=right)
                elif self.match_and_advance(TokenType.INCLUDED_IN):
                    right = self.parse_type_expression()
                    left = BinaryExpression(operator="properly included in", left=left, right=right)
                elif self.match_and_advance(TokenType.IN):
                    right = self.parse_type_expression()
                    left = BinaryExpression(operator="properly in", left=left, right=right)
                elif self.match_and_advance(TokenType.DURING):
                    # CQL §9.17: "properly during" is a synonym for "properly included in"
                    right = self.parse_type_expression()
                    left = BinaryExpression(operator="properly included in", left=left, right=right)
                else:
                    # Unknown properly combination
                    self.pos = saved_pos
                    break
            # Between operator (ternary): X between Y and Z
            elif self.match_and_advance(TokenType.BETWEEN):
                low = self.parse_type_expression()
                self.expect(TokenType.AND, "Expected 'and' in between expression")
                high = self.parse_type_expression()
                # Represent as a special BinaryExpression with low and high bounds
                left = BinaryExpression(operator="between", left=left, right=BinaryExpression(operator="and", left=low, right=high))
            # "occurs" is a transparent optional CQL temporal prefix — consume and re-loop
            elif self.match(TokenType.IDENTIFIER) and self.current().value.lower() == "occurs":
                self.advance()
            # "within N days/weeks/... of EXPR" timing operator
            elif self.match(TokenType.IDENTIFIER) and self.current().value.lower() == "within":
                saved_pos = self.pos
                self.advance()  # consume 'within'
                if not (self.match(TokenType.INTEGER, TokenType.DECIMAL) and self._within_unit_follows()):
                    # Incomplete `within` phrase: restore so the token
                    # surfaces (trailing-token ParseError) instead of being
                    # silently dropped with the loop's break.
                    self.pos = saved_pos
                    break
                quantity_value = self.advance().value
                unit = self.advance().value
                self.expect(TokenType.OF, "Expected 'of' after unit in 'within N unit of'")
                right = self.parse_type_expression()
                left = BinaryExpression(
                    operator=f"within {quantity_value} {unit} of",
                    left=left,
                    right=right,
                )
            # Integer-led timing quantifier: N unit or more/less before/after [precision of] EXPR
            elif self.match(TokenType.INTEGER, TokenType.DECIMAL):
                saved_pos = self.pos
                quantity_value = self.advance().value
                if self.match(TokenType.YEAR, TokenType.MONTH, TokenType.DAY,
                              TokenType.HOUR, TokenType.MINUTE, TokenType.SECOND,
                              TokenType.MILLISECOND, TokenType.WEEK, TokenType.YEARS,
                              TokenType.MONTHS, TokenType.DAYS, TokenType.HOURS,
                              TokenType.MINUTES, TokenType.SECONDS, TokenType.MILLISECONDS,
                              TokenType.WEEKS):
                    unit = self.advance().value
                    if self.match(TokenType.OR_MORE, TokenType.OR_LESS):
                        modifier = self.advance().value
                        # Handle "before or on" = "on or before" and "after or on" = "on or after"
                        if self.match(TokenType.BEFORE) and self.peek().type == TokenType.OR and \
                                self.peek(2).type == TokenType.IDENTIFIER and self.peek(2).value.lower() == "on":
                            self.advance(); self.advance(); self.advance()
                            direction = "on or before"
                        elif self.match(TokenType.AFTER) and self.peek().type == TokenType.OR and \
                                self.peek(2).type == TokenType.IDENTIFIER and self.peek(2).value.lower() == "on":
                            self.advance(); self.advance(); self.advance()
                            direction = "on or after"
                        elif self.match(TokenType.BEFORE, TokenType.AFTER,
                                        TokenType.ON_OR_BEFORE, TokenType.ON_OR_AFTER):
                            direction = self.advance().value
                        else:
                            self.pos = saved_pos
                            break
                        precision = self._try_parse_precision_of()
                        right = self.parse_type_expression()
                        op = f"{quantity_value} {unit} {modifier} {direction}"
                        if precision:
                            op += f" {precision} of"
                        left = BinaryExpression(operator=op, left=left, right=right)
                    else:
                        self.pos = saved_pos
                        break
                else:
                    self.pos = saved_pos
                    break
            # Same as: same year as, same month as, etc.
            elif self.match(TokenType.IDENTIFIER) and self.current().value.lower() == "same":
                # Check for "same or after" or "same or before" patterns
                if self.peek().type == TokenType.OR_AFTER:
                    self.advance()  # consume 'same'
                    self.advance()  # consume 'or after'
                    precision = self._try_parse_precision_of()
                    if precision:
                        right = self.parse_type_expression()
                        left = BinaryExpression(operator=f"same or after {precision} of", left=left, right=right)
                    else:
                        right = self.parse_type_expression()
                        left = BinaryExpression(operator="same or after", left=left, right=right)
                elif self.peek().type == TokenType.OR_BEFORE:
                    self.advance()  # consume 'same'
                    self.advance()  # consume 'or before'
                    precision = self._try_parse_precision_of()
                    if precision:
                        right = self.parse_type_expression()
                        left = BinaryExpression(operator=f"same or before {precision} of", left=left, right=right)
                    else:
                        right = self.parse_type_expression()
                        left = BinaryExpression(operator="same or before", left=left, right=right)
                elif self.peek().type in (TokenType.YEAR, TokenType.MONTH, TokenType.DAY,
                                          TokenType.HOUR, TokenType.MINUTE, TokenType.SECOND,
                                          TokenType.MILLISECOND, TokenType.WEEK):
                    # Pattern: same <precision> as OR same <precision> or after/before
                    self.advance()  # consume 'same'
                    precision_token = self.advance()  # consume precision
                    precision = precision_token.value.lower()
                    # Check for "or after" or "or before" after precision
                    if self.match_and_advance(TokenType.OR_AFTER):
                        right = self.parse_type_expression()
                        left = BinaryExpression(operator=f"same {precision} or after", left=left, right=right)
                    elif self.match_and_advance(TokenType.OR_BEFORE):
                        right = self.parse_type_expression()
                        left = BinaryExpression(operator=f"same {precision} or before", left=left, right=right)
                    else:
                        self.expect(TokenType.AS, "Expected 'as'")
                        right = self.parse_type_expression()
                        left = BinaryExpression(operator=f"same {precision} as", left=left, right=right)
                elif self.peek().type == TokenType.AS:
                    # Bare "same as" (no precision): CQL 1.5 §8.12/§9.24 and
                    # Cql.g4 concurrentWithIntervalOperatorPhrase allow
                    # 'same' dateTimePrecision? (relativeQualifier | 'as').
                    self.advance()  # consume 'same'
                    self.advance()  # consume 'as'
                    right = self.parse_type_expression()
                    left = BinaryExpression(operator="same as", left=left, right=right)
                else:
                    # Just "same" as identifier
                    break
            else:
                break

        return left

    def parse_type_expression(self) -> Expression:
        """Parse type expression (is, as)."""
        left = self.parse_addition_expression()

        while True:
            # Handle IS_NULL, IS_NOT_NULL, etc. as single tokens
            if self.match_and_advance(TokenType.IS_NULL):
                left = UnaryExpression(operator="is null", operand=left)
            elif self.match_and_advance(TokenType.IS_NOT_NULL):
                left = UnaryExpression(operator="is not null", operand=left)
            elif self.match_and_advance(TokenType.IS_TRUE):
                left = UnaryExpression(operator="is true", operand=left)
            elif self.match_and_advance(TokenType.IS_FALSE):
                left = UnaryExpression(operator="is false", operand=left)
            elif self.match_and_advance(TokenType.IS):
                # Check for is null, is not null, is true, is false
                if self.match_and_advance(TokenType.NULL):
                    left = UnaryExpression(operator="is null", operand=left)
                elif self.match_and_advance(TokenType.IS_NULL):
                    left = UnaryExpression(operator="is null", operand=left)
                elif self.match_and_advance(TokenType.IS_NOT_NULL):
                    left = UnaryExpression(operator="is not null", operand=left)
                elif self.match_and_advance(TokenType.TRUE):
                    left = UnaryExpression(operator="is true", operand=left)
                elif self.match_and_advance(TokenType.IS_TRUE):
                    left = UnaryExpression(operator="is true", operand=left)
                elif self.match_and_advance(TokenType.FALSE):
                    left = UnaryExpression(operator="is false", operand=left)
                elif self.match_and_advance(TokenType.IS_FALSE):
                    left = UnaryExpression(operator="is false", operand=left)
                elif self.match_and_advance(TokenType.NOT):
                    # Handle "is not null", "is not true", "is not false" when lexed as separate tokens
                    if self.match_and_advance(TokenType.NULL):
                        left = UnaryExpression(operator="is not null", operand=left)
                    elif self.match_and_advance(TokenType.TRUE):
                        left = UnaryExpression(operator="is not true", operand=left)
                    elif self.match_and_advance(TokenType.FALSE):
                        left = UnaryExpression(operator="is not false", operand=left)
                    else:
                        token = self.current()
                        raise ParseError(
                            f"Expected 'null', 'true', or 'false' after 'is not', got {token.type.name} '{token.value}'",
                            position=(token.line, token.column),
                        )
                else:
                    # Type check
                    type_spec = self.parse_type_specifier()
                    left = BinaryExpression(operator="is", left=left, right=type_spec)
            elif self.match_and_advance(TokenType.AS):
                type_spec = self.parse_type_specifier()
                left = BinaryExpression(operator="as", left=left, right=type_spec)
            else:
                break

        return left

    def parse_addition_expression(self) -> Expression:
        """Parse addition expression (+, -, |, &) and list set operators (union, intersect, except)."""
        left = self.parse_multiplication_expression()

        while True:
            if self.match_and_advance(TokenType.PLUS):
                right = self.parse_multiplication_expression()
                left = BinaryExpression(operator="+", left=left, right=right)
            elif self.match_and_advance(TokenType.MINUS):
                right = self.parse_multiplication_expression()
                left = BinaryExpression(operator="-", left=left, right=right)
            elif self.match_and_advance(TokenType.PIPE):
                right = self.parse_multiplication_expression()
                left = BinaryExpression(operator="|", left=left, right=right)
            elif self.match_and_advance(TokenType.CONCATENATE):
                right = self.parse_multiplication_expression()
                left = BinaryExpression(operator="&", left=left, right=right)
            # List set operators
            elif self.match_and_advance(TokenType.UNION):
                right = self.parse_multiplication_expression()
                left = BinaryExpression(operator="union", left=left, right=right)
            elif self.match_and_advance(TokenType.INTERSECT):
                right = self.parse_multiplication_expression()
                left = BinaryExpression(operator="intersect", left=left, right=right)
            elif self.match_and_advance(TokenType.EXCEPT):
                right = self.parse_multiplication_expression()
                left = BinaryExpression(operator="except", left=left, right=right)
            else:
                break

        return left

    def parse_multiplication_expression(self) -> Expression:
        """Parse multiplication expression (*, /, div, mod)."""
        left = self.parse_power_expression()

        while True:
            if self.match_and_advance(TokenType.MULTIPLY):
                right = self.parse_power_expression()
                left = BinaryExpression(operator="*", left=left, right=right)
            elif self.match_and_advance(TokenType.DIVIDE):
                right = self.parse_power_expression()
                left = BinaryExpression(operator="/", left=left, right=right)
            elif self.match_and_advance(TokenType.DIV):
                right = self.parse_power_expression()
                left = BinaryExpression(operator="div", left=left, right=right)
            elif self.match_and_advance(TokenType.MOD):
                right = self.parse_power_expression()
                left = BinaryExpression(operator="mod", left=left, right=right)
            else:
                break

        return left

    def parse_power_expression(self) -> Expression:
        """Parse power expression (^). Right-associative."""
        left = self.parse_unary_expression()

        if self.match_and_advance(TokenType.CARET):
            right = self.parse_power_expression()  # Right-associative: recurse
            left = BinaryExpression(operator="^", left=left, right=right)

        return left

    def parse_unary_expression(self) -> Expression:
        """Parse unary expression (-, exists, distinct, start of, end of, point from).

        NOTE: unary ``not`` is intentionally NOT parsed here. It lives at
        ``parse_not_expression`` between the AND and equality levels to match
        the CQL 1.5 grammar precedence (see that method's docstring).
        """

        if self.match_and_advance(TokenType.MINUS):
            # CQL §Types/Ratio + §ToString RatioOverload example uses a
            # negative-numerator Ratio literal: `-0.1 'mg':0.1 'mg'`. The
            # naive parse path consumes the leading MINUS here, then parses
            # `0.1 'mg':0.1 'mg'` as a positive Ratio, and wraps the whole
            # Ratio in UnaryExpression('-', ...). Ratio has no negation
            # operator, so this fails at execution. Detect the ratio-
            # literal pattern (numeric [unit] COLON ...) and propagate the
            # sign through the numerator by recording it on a parser
            # thread-local that `_maybe_parse_ratio_literal` reads.
            operand = self.parse_unary_expression()
            if isinstance(operand, FunctionRef) and operand.name == "ToRatio":
                # The sign was dropped from the numerator; re-apply it.
                if (len(operand.arguments) == 1
                        and isinstance(operand.arguments[0], Literal)
                        and isinstance(operand.arguments[0].value, str)
                        and operand.arguments[0].value):
                    literal_val = operand.arguments[0].value
                    # Ratio literal text format: "<num> '<unit>':<den> '<unit>'"
                    # Only negate if not already negative.
                    if not literal_val.startswith("-"):
                        negated = "-" + literal_val
                        operand.arguments[0] = Literal(
                            value=negated,
                            type=operand.arguments[0].type,
                        )
                        return operand
            return UnaryExpression(operator="-", operand=operand)

        # Unary plus - just return the operand (no-op)
        if self.match_and_advance(TokenType.PLUS):
            return self.parse_unary_expression()

        # Cast expression: cast X as Type
        if self.match_and_advance(TokenType.CAST):
            operand = self.parse_unary_expression()
            self.expect(TokenType.AS, "Expected 'as' after cast expression")
            target_type = self.parse_type_specifier()
            return BinaryExpression(operator="as", left=operand, right=target_type, strict=True)

        # Convert expression: convert X to Type
        if self.match_and_advance(TokenType.CONVERT):
            operand = self.parse_unary_expression()
            # Expect 'to' keyword
            self.expect(TokenType.TO, "Expected 'to' after convert expression")
            if self.match(TokenType.STRING):
                # Convert-to-Quantity-unit: `convert X to 'm2'` (quoted UCUM
                # unit target; used by the us-cql-ig shared libraries).
                # Lowered to quantityConvert by the translator.
                unit = self.advance().value
                return BinaryExpression(
                    operator="convert",
                    left=operand,
                    right=Literal(value=unit, type="String"),
                )
            if self.match(*_PRECISION_UNIT_TOKENS):
                # CQL 2.0 grammar (FHIR-52783 surface):
                #   'convert' expression 'to' (typeSpecifier | unit)
                # where `unit` also admits bare date-time precision keywords
                # (year..millisecond, singular and plural). The reference
                # implementation lowers unit targets to ConvertQuantity, so
                # parse them exactly like the quoted-unit form.
                unit = self.advance().value
                return BinaryExpression(
                    operator="convert",
                    left=operand,
                    right=Literal(value=unit, type="String"),
                )
            target_type = self.parse_type_specifier()
            return BinaryExpression(operator="convert", left=operand, right=target_type)

        if self.match_and_advance(TokenType.EXISTS):
            operand = self.parse_unary_expression()
            return ExistsExpression(source=operand)

        if self.match_and_advance(TokenType.DISTINCT) or self.match_and_advance(TokenType.DISTINCT_FN):
            operand = self.parse_unary_expression()
            return DistinctExpression(source=operand)

        # PAR-007: bare `flatten X` (grammar: `('distinct'|'flatten') expression`
        # aggregateExpressionTerm). Without this branch the FLATTEN token
        # degraded to a plain Identifier and `flatten X` misparsed as a Query
        # with source=Identifier('flatten') and alias=X.
        if self.match_and_advance(TokenType.FLATTEN):
            operand = self.parse_unary_expression()
            return FunctionRef(name="flatten", arguments=[operand])

        # Interval operators: start of, end of, point from
        if self.match(TokenType.START):
            if self.peek().type == TokenType.OF:
                self.advance()  # consume START
                self.advance()  # consume OF
                operand = self.parse_unary_expression()
                return UnaryExpression(operator="start of", operand=operand)

        if self.match(TokenType.END):
            # Check if this is "end of" (interval operator) or just "end" (case expression keyword)
            # Look ahead to see if "of" follows
            if self.peek().type == TokenType.OF:
                self.advance()  # consume END
                self.advance()  # consume OF
                operand = self.parse_unary_expression()
                return UnaryExpression(operator="end of", operand=operand)

        if self.match_and_advance(TokenType.POINT):
            self.expect(TokenType.FROM, "Expected 'from' after 'point'")
            operand = self.parse_unary_expression()
            return UnaryExpression(operator="point from", operand=operand)

        # Width of operator
        if self.match_and_advance(TokenType.WIDTH):
            self.expect(TokenType.OF, "Expected 'of' after 'width'")
            operand = self.parse_unary_expression()
            return UnaryExpression(operator="width of", operand=operand)

        # Singleton from operator
        if self.match_and_advance(TokenType.SINGLETON_FROM):
            operand = self.parse_unary_expression()
            return UnaryExpression(operator="singleton from", operand=operand)

        # Predecessor of operator
        if self.match_and_advance(TokenType.PREDECESSOR):
            self.expect(TokenType.OF, "Expected 'of' after 'predecessor'")
            operand = self.parse_unary_expression()
            return UnaryExpression(operator="predecessor of", operand=operand)

        # Successor of operator
        if self.match_and_advance(TokenType.SUCCESSOR):
            self.expect(TokenType.OF, "Expected 'of' after 'successor'")
            operand = self.parse_unary_expression()
            return UnaryExpression(operator="successor of", operand=operand)

        # Minimum and Maximum value selectors (e.g., minimum Integer, maximum Decimal)
        if self.match_and_advance(TokenType.MINIMUM):
            type_name = self._parse_identifier_name()
            return FunctionRef(name="minimum", arguments=[Identifier(name=type_name)])

        if self.match_and_advance(TokenType.MAXIMUM):
            type_name = self._parse_identifier_name()
            return FunctionRef(name="maximum", arguments=[Identifier(name=type_name)])

        return self.parse_postfix_expression()

    def parse_postfix_expression(self) -> Expression:
        """Parse postfix expression (., [], (), and query clauses)."""
        expr = self.parse_primary_expression()

        while True:
            if self.match_and_advance(TokenType.DOT):
                if self.match(TokenType.WHERE):
                    # FHIRPath-style dot-where filter: X.where(criteria).
                    # 'where' is a cql.g4 keywordIdentifier, so the reference
                    # translator accepts this qualified-invocation form (used
                    # by the us-cql-ig shared libraries). It lowers to a
                    # single-source query whose where-clause sees the source
                    # as the implicit focus (FHIRPath $this semantics): bare
                    # property references inside the criteria resolve against
                    # the single query source, like any CQL where clause.
                    self.advance()
                    self.expect(TokenType.LPAREN, "Expected '(' after '.where'")
                    criteria = self.parse_expression()
                    self.expect(TokenType.RPAREN, "Expected ')' after .where criteria")
                    expr = Query(
                        source=QuerySource(alias="$this", expression=expr),
                        where=WhereClause(expression=criteria),
                    )
                    continue
                name = self._parse_identifier_name()

                # Check if this is a method call (followed by parentheses)
                if self.match_and_advance(TokenType.LPAREN):
                    # Method invocation
                    args = []
                    if not self.check(TokenType.RPAREN):
                        args.append(self.parse_expression())
                        while self.match_and_advance(TokenType.COMMA):
                            args.append(self.parse_expression())
                    self.expect(TokenType.RPAREN, "Expected ')' after method arguments")
                    expr = MethodInvocation(source=expr, method=name, arguments=args)
                else:
                    # Property access
                    expr = Property(source=expr, path=name)
                # Check if this is followed by { for type constructor (e.g., System.ValueSet{...})
                if self.match(TokenType.LBRACE):
                    self.advance()  # consume {
                    elements = []
                    while not self.match(TokenType.RBRACE):
                        name = self._parse_identifier_name()
                        self.expect(TokenType.COLON, "Expected ':'")
                        value = self.parse_expression()
                        elements.append(TupleElement(name=name, type=value))
                        if not self.match_and_advance(TokenType.COMMA):
                            break
                    self.expect(TokenType.RBRACE, "Expected '}'")
                    # Build the type name from the property chain
                    type_name = self._build_qualified_name_from_property(expr)
                    expr = InstanceExpression(type=type_name, elements=elements)
            elif self.match_and_advance(TokenType.LBRACKET):
                # Indexer
                index = self.parse_expression()
                self.expect(TokenType.RBRACKET, "Expected ']' after index")
                expr = IndexerExpression(source=expr, index=index)
            elif self.match(TokenType.LPAREN) and isinstance(expr, (Identifier, QualifiedIdentifier, Property)):
                # Function call (including method calls on properties)
                expr = self._parse_function_call(expr)
            elif self.match(TokenType.IDENTIFIER, TokenType.QUOTED_IDENTIFIER,
                           TokenType.LOCATION, TokenType.PATIENT, TokenType.PRACTITIONER,
                           TokenType.ORGANIZATION, TokenType.RESOURCE, TokenType.BUNDLE):
                # Check if this is a query with alias (e.g., [Encounter] E where ...)
                # or ({1,2,3}) X sort asc
                # or (Query1) Alias1 union (Query2) ...
                # Also allow FHIR resource type keywords as aliases (e.g., "location Location where")
                # Look ahead to see if there's a query keyword after the identifier
                next_token = self.peek()
                if next_token.type in (TokenType.WHERE, TokenType.RETURN, TokenType.SORT,
                                       TokenType.WITH, TokenType.WITHOUT, TokenType.LET,
                                       TokenType.EOF, TokenType.DEFINE, TokenType.RPAREN,
                                       TokenType.AGGREGATE, TokenType.COMMA, TokenType.RBRACKET, TokenType.RBRACE,
                                       TokenType.UNION, TokenType.INTERSECT, TokenType.EXCEPT):
                    if isinstance(expr, Literal) and not getattr(
                        expr, "_parenthesized", False
                    ):
                        # PAR-007: `1 foo` is INVALID grammar — a query source
                        # is a retrieve, a (qualified) identifier, or a
                        # parenthesized expression; a bare literal followed by
                        # an identifier is a trailing-token error, not a Query
                        # with a literal source and an alias.
                        _tok = self.current()
                        raise ParseError(
                            "Invalid query source: a bare literal cannot be "
                            "aliased (expected a retrieve, identifier, or "
                            "parenthesized expression)",
                            position=(_tok.line, _tok.column),
                        )
                    # This is a query with an alias
                    alias = self._parse_identifier_name()
                    source = QuerySource(alias=alias, expression=expr)
                    query = Query(source=source)

                    # Parse query clauses
                    while True:
                        if self.match(TokenType.WHERE) and query.where is None:
                            query.where = self.parse_where_clause()
                        elif self.match(TokenType.RETURN) and query.return_clause is None:
                            query.return_clause = self.parse_return_clause()
                        elif self.match(TokenType.SORT) and query.sort is None:
                            query.sort = self.parse_sort_clause()
                        elif self.match(TokenType.WITH, TokenType.WITHOUT):
                            query.with_clauses.append(self.parse_with_clause())
                        elif self.match(TokenType.LET):
                            query.let_clauses.extend(self.parse_let_clause())
                        elif self.match(TokenType.AGGREGATE) and query.aggregate is None:
                            query.aggregate = self.parse_aggregate_clause()
                        else:
                            break

                    expr = query
                else:
                    break
            # Check for query operators (skip, take, first, last, any, all, singleton from, distinct)
            elif self.match(TokenType.SKIP):
                expr = self._parse_skip_expression(expr)
            elif self.match(TokenType.TAKE):
                expr = self._parse_take_expression(expr)
            elif self.match(TokenType.FIRST):
                expr = self._parse_first_expression(expr)
            elif self.match(TokenType.LAST):
                expr = self._parse_last_expression(expr)
            elif self.match(TokenType.ANY):
                expr = self._parse_any_expression(expr)
            elif self.match(TokenType.ALL):
                expr = self._parse_all_expression(expr)
            elif self.match(TokenType.SINGLETON_FROM):
                expr = self._parse_singleton_expression(expr)
            elif self.match(TokenType.DISTINCT, TokenType.DISTINCT_FN):
                expr = self._parse_distinct_expression(expr)
            else:
                break

        return expr

    # =========================================================================
    # Primary Expression Parsing
    # =========================================================================

    def parse_primary_expression(self) -> Expression:
        """Parse primary expression (literals, identifiers, groupings)."""
        token = self.current()

        # Component extraction: year from X (check before duration between)
        # Only singular forms can be component extraction
        if self.match(TokenType.YEAR, TokenType.MONTH, TokenType.DAY,
                      TokenType.HOUR, TokenType.MINUTE, TokenType.SECOND, TokenType.MILLISECOND):
            # Check if followed by 'from'
            if self.peek().type == TokenType.FROM:
                return self._parse_component_extraction()

        # timezoneoffset from X — CQL §18.12 component extraction
        if self.match(TokenType.TIMEZONE_FROM):
            if self.peek().type == TokenType.FROM:
                return self._parse_component_extraction()

        # Duration between: years between X and Y (singular or plural + BETWEEN)
        # But NOT "month of" or "year of" which are precision specifiers for temporal operators
        if self.match(TokenType.YEAR, TokenType.YEARS, TokenType.MONTH, TokenType.MONTHS,
                      TokenType.WEEK, TokenType.WEEKS, TokenType.DAY, TokenType.DAYS,
                      TokenType.HOUR, TokenType.HOURS, TokenType.MINUTE, TokenType.MINUTES,
                      TokenType.SECOND, TokenType.SECONDS, TokenType.MILLISECOND, TokenType.MILLISECONDS):
            # Check if followed by 'between' (duration between) - only then parse as duration
            next_token = self.peek()
            if next_token.type == TokenType.BETWEEN:
                return self._parse_duration_between()
            # Check if followed by 'of' (precision specifier for temporal comparisons)
            if next_token.type == TokenType.OF:
                return self._parse_precision_of()
            # Otherwise fall through - it might be a quantity

        # Difference between: difference in years between X and Y
        if self.match(TokenType.IDENTIFIER) and token.value.lower() == "difference":
            return self._parse_difference_between()

        # Duration between (keyword form): duration in years between X and Y.
        # Guard on peek(3) == BETWEEN so the duration-extraction form
        # `duration in days of X` keeps its existing parse (Identifier +
        # `in` + precision-of), which the translator special-cases.
        if (
            self.match(TokenType.IDENTIFIER)
            and token.value.lower() == "duration"
            and self.peek().type == TokenType.IN
            and self.peek(2).type in (
                TokenType.YEAR, TokenType.YEARS, TokenType.MONTH, TokenType.MONTHS,
                TokenType.WEEK, TokenType.WEEKS, TokenType.DAY, TokenType.DAYS,
                TokenType.HOUR, TokenType.HOURS, TokenType.MINUTE, TokenType.MINUTES,
                TokenType.SECOND, TokenType.SECONDS, TokenType.MILLISECOND, TokenType.MILLISECONDS,
            )
            and self.peek(3).type == TokenType.BETWEEN
        ):
            return self._parse_duration_in_between()

        # Literals
        if self.match(TokenType.INTEGER, TokenType.LONG, TokenType.DECIMAL):
            return self.parse_literal()

        if self.match(TokenType.STRING):
            return self.parse_literal()

        if self.match(TokenType.TRUE, TokenType.FALSE, TokenType.NULL):
            return self.parse_literal()

        if self.match(TokenType.DATE, TokenType.DATETIME):
            return self.parse_datetime_literal()

        if self.match(TokenType.TIME):
            return self.parse_time_literal()

        # Code selector: Code '73211009' from "SNOMED-CT" [display 'text']
        if self.match(TokenType.CODE_TYPE):
            next_type = self.peek().type
            if next_type == TokenType.STRING:
                return self.parse_code_selector()

        # Concept selector: Concept { Code 'x' from "CS", ... } or
        # Concept { "NamedCode", ... }   (grammar conceptSelector)
        if self.match(TokenType.CONCEPT_TYPE) and self.peek().type == TokenType.LBRACE:
            return self._parse_concept_selector()

        # Typed list selector: List<T>{ ... } or List{ ... }
        # (grammar: `('List' ('<' typeSpecifier '>')?)? '{' ... '}'`)
        if self.match(TokenType.LIST_TYPE) and self.peek().type in (
            TokenType.LESS_THAN,
            TokenType.LBRACE,
        ):
            return self._parse_typed_list_selector()

        # Interval literal: only if followed by a bracket/paren delimiter
        if self.match(TokenType.INTERVAL):
            next_type = self.peek().type
            if next_type in (TokenType.LBRACKET, TokenType.LPAREN,
                             TokenType.OPEN, TokenType.CLOSED,
                             TokenType.OPEN_CLOSED, TokenType.CLOSED_OPEN):
                return self.parse_interval()

        # List literal
        if self.match(TokenType.LBRACE):
            return self._parse_brace_expression()

        # Retrieve expression
        if self.match(TokenType.LBRACKET):
            return self.parse_retrieve()

        # Query with 'from' keyword
        if self.match(TokenType.FROM):
            return self.parse_from_query()

        # Tuple/Instance expression
        if self.match(TokenType.TUPLE):
            return self.parse_tuple_expression()

        # Case expression
        if self.match(TokenType.CASE):
            return self.parse_case_expression()

        # Conditional expression (if)
        if self.match(TokenType.IFF):
            return self.parse_conditional_expression()

        # Parenthesized expression or tuple type
        if self.match(TokenType.LPAREN):
            return self._parse_parenthesized_or_tuple()

        # Type constructor
        if self._is_type_constructor():
            return self._parse_type_constructor()

        # Identifier (variable, function, or qualified identifier)
        # Also accept keywords that can be used as identifiers
        if self.match(TokenType.IDENTIFIER, TokenType.QUOTED_IDENTIFIER,
                      TokenType.PATIENT, TokenType.PRACTITIONER, TokenType.ORGANIZATION,
                      TokenType.LOCATION, TokenType.RESOURCE, TokenType.BUNDLE,
                      TokenType.COUNT, TokenType.SUM, TokenType.MIN, TokenType.MAX,
                      TokenType.AVG, TokenType.MEDIAN, TokenType.MODE, TokenType.LENGTH,
                      TokenType.UPPER, TokenType.LOWER, TokenType.CONCATENATE,
                      TokenType.COMBINE, TokenType.SPLIT, TokenType.POSITION_OF,
                      TokenType.SUBSTRING, TokenType.STARTS_WITH, TokenType.ENDS_WITH,
                      TokenType.MATCHES, TokenType.REPLACE_MATCHES, TokenType.REPLACE,
                      TokenType.COALESCE, TokenType.IFF, TokenType.CASE, TokenType.WHEN,
                      TokenType.THEN, TokenType.ELSE, TokenType.END, TokenType.TO_BOOLEAN,
                      TokenType.TO_CONCEPT, TokenType.TO_DATE, TokenType.TO_DATETIME,
                      TokenType.TO_DECIMAL, TokenType.TO_INTEGER, TokenType.TO_QUANTITY,
                      TokenType.TO_STRING, TokenType.TO_TIME, TokenType.TO_CODE,
                      TokenType.TO_CHARS, TokenType.FROM_CHARS, TokenType.FIRST,
                      TokenType.LAST, TokenType.INDEXER, TokenType.FLATTEN,
                      TokenType.DISTINCT_FN, TokenType.CURRENT, TokenType.CHILDREN,
                      TokenType.DESCENDENTS, TokenType.ENCODE, TokenType.ESCAPE,
                      TokenType.PREVIOUS, TokenType.PREDECESSOR, TokenType.SUCCESSOR, TokenType.SINGLE,
                      TokenType.SELECT, TokenType.FOR, TokenType.OF, TokenType.REPEAT,
                      TokenType.INTERSECT, TokenType.EXCEPT, TokenType.UNION,
                      TokenType.EXPAND, TokenType.ROUND, TokenType.ABS, TokenType.CEILING,
                      TokenType.FLOOR, TokenType.LN, TokenType.LOG, TokenType.POWER,
                      TokenType.TRUNCATE, TokenType.EXP, TokenType.SQRT, TokenType.DIV,
                      TokenType.MOD, TokenType.REMAINDER, TokenType.WIDTH, TokenType.SIZE,
                      TokenType.POINT_FROM, TokenType.LOWBOUNDARY, TokenType.HIGHBOUNDARY,
                      TokenType.PRECISION, TokenType.MINIMUM, TokenType.MAXIMUM,
                      TokenType.BOOLEAN, TokenType.INTEGER_TYPE, TokenType.LONG_TYPE,
                      TokenType.DECIMAL_TYPE, TokenType.STRING_TYPE, TokenType.DATE_TYPE,
                      TokenType.DATETIME_TYPE, TokenType.TIME_TYPE, TokenType.QUANTITY,
                      TokenType.RATIO, TokenType.INTERVAL, TokenType.LIST_TYPE,
                      TokenType.TUPLE, TokenType.CHOICE, TokenType.ANY, TokenType.CODE_TYPE,
                      TokenType.CONCEPT_TYPE, TokenType.CODESYSTEM_TYPE, TokenType.VALUESET_TYPE,
                      TokenType.ALL_TRUE, TokenType.ANY_TRUE, TokenType.VARIANCE, TokenType.STDDEV,
                      TokenType.SKIP, TokenType.TAKE,
                      TokenType.VERSION, TokenType.DISPLAY, TokenType.CALLED,
                      TokenType.CODE, TokenType.CONCEPT, TokenType.VALUESYSTEM,
                      TokenType.START, TokenType.STARTING):
            return self._parse_identifier_or_function()

        # Quantified expression keywords
        if self.match(TokenType.COUNT, TokenType.SUM, TokenType.MIN, TokenType.MAX,
                      TokenType.AVG, TokenType.MEDIAN, TokenType.MODE):
            return self._parse_aggregate_expression()

        # Temporal operators
        if self.match(TokenType.AFTER, TokenType.BEFORE, TokenType.DURING,
                      TokenType.INCLUDES, TokenType.INCLUDED_IN, TokenType.OVERLAPS,
                      TokenType.MEETS, TokenType.STARTS, TokenType.ENDS,
                      TokenType.MEETS_BEFORE, TokenType.MEETS_AFTER,
                      TokenType.OVERLAPS_BEFORE, TokenType.OVERLAPS_AFTER,
                      TokenType.ON_OR_BEFORE, TokenType.ON_OR_AFTER):
            return self._parse_temporal_expression()

        # Date/Time component extraction: date from X, time from X
        if self.match(TokenType.DATE_FROM, TokenType.TIME_FROM):
            return self._parse_date_component_extraction()

        # $this - special CQL keyword for current item in iteration context
        if self.match(TokenType.DOLLAR):
            self.advance()  # consume $
            nxt = self.current()
            if nxt.type == TokenType.IDENTIFIER and nxt.value.lower() == 'this':
                self.advance()  # consume 'this'
                return Identifier(name='$this')
            raise ParseError(
                f"Expected 'this' after '$', got {nxt.type.name} '{nxt.value}'",
                position=(nxt.line, nxt.column),
            )

        # Error
        raise ParseError(
            f"Unexpected token in expression: {token.type.name} '{token.value}'",
            position=(token.line, token.column),
        )

    def _parse_date_component_extraction(self) -> FunctionRef:
        """Parse date/time component extraction: date from X, time from X.

        Also handles date()/time() function calls when 'from' is not present.
        """
        token = self.advance()  # consume DATE_FROM or TIME_FROM

        # Determine the component name
        if token.type == TokenType.DATE_FROM:
            component_name = "date"
        else:  # TIME_FROM
            component_name = "time"

        # Check if this is 'date from X' or just 'date()' function call
        if self.match_and_advance(TokenType.FROM):
            # It's component extraction: date from X
            # Per CQL grammar, 'date from' takes an expressionTerm (not a full
            # expression), so parse at the type-expression level to avoid
            # absorbing comparison and boolean operators.
            source = self.parse_type_expression()
            return FunctionRef(
                name=component_name,
                arguments=[source],
            )
        else:
            # It's a function call: date() or date(arg)
            # Parse as a regular function call
            return self._parse_function_call(Identifier(name=component_name))

    def parse_literal(self) -> Union[Literal, Quantity]:
        """Parse a literal value, potentially with a temporal unit or UCUM unit."""
        token = self.advance()

        if token.type == TokenType.INTEGER:
            value = int(token.value)
            # Check for temporal unit (e.g., 5 years, 10 days)
            if self.match(TokenType.YEAR, TokenType.YEARS, TokenType.MONTH, TokenType.MONTHS,
                          TokenType.WEEK, TokenType.WEEKS, TokenType.DAY, TokenType.DAYS,
                          TokenType.HOUR, TokenType.HOURS, TokenType.MINUTE, TokenType.MINUTES,
                          TokenType.SECOND, TokenType.SECONDS, TokenType.MILLISECOND, TokenType.MILLISECONDS):
                unit_token = self.advance()
                # Normalize to singular form
                unit = unit_token.value.lower().rstrip('s')
                return self._maybe_parse_ratio_literal(Quantity(value=value, raw_text=token.value, unit=unit))
            # Check for UCUM unit string (e.g., 1 'ml', 10 'cm', 19.99 '[lb_av]')
            if self.match(TokenType.STRING):
                unit_token = self.advance()
                unit = unit_token.value
                return self._maybe_parse_ratio_literal(Quantity(value=value, raw_text=token.value, unit=unit))
            # CQL §Types/Ratio: bare numeric ratio literal (e.g. `1:8`).
            # A bare numeric with no unit is treated as a Quantity with the
            # default UCUM unit '1' (CQL §Types/Quantity) so that the ratio
            # literal form `<quantity>:<quantity>` is accepted.
            #
            # If `_maybe_parse_ratio_literal` does not commit to a Ratio
            # (e.g. because the token after COLON cannot start a Quantity,
            # such as the `Result` identifier in an aggregate-clause
            # `starting 1: <body>`), fall back to the plain Integer Literal
            # so the caller's context-specific parser handles the COLON.
            if self.match(TokenType.COLON):
                ratio = self._maybe_parse_ratio_literal(Quantity(value=value, raw_text=token.value, unit="1"))
                if isinstance(ratio, FunctionRef):
                    return ratio
                return Literal(value=value, type="Integer")
            return Literal(value=value, type="Integer")
        elif token.type == TokenType.LONG:
            value = int(token.value)
            # CQL §Types/Ratio: bare numeric ratio literal.
            if self.match(TokenType.COLON):
                ratio = self._maybe_parse_ratio_literal(Quantity(value=value, raw_text=token.value, unit="1"))
                if isinstance(ratio, FunctionRef):
                    return ratio
                return Literal(value=value, type="Long")
            return Literal(value=value, type="Long")
        elif token.type == TokenType.DECIMAL:
            value = float(token.value)
            raw_str_override = None
            # Check for temporal unit (e.g., 3.5 hours)
            if self.match(TokenType.YEAR, TokenType.YEARS, TokenType.MONTH, TokenType.MONTHS,
                          TokenType.WEEK, TokenType.WEEKS, TokenType.DAY, TokenType.DAYS,
                          TokenType.HOUR, TokenType.HOURS, TokenType.MINUTE, TokenType.MINUTES,
                          TokenType.SECOND, TokenType.SECONDS, TokenType.MILLISECOND, TokenType.MILLISECONDS):
                unit_token = self.advance()
                unit = unit_token.value.lower().rstrip('s')
                return self._maybe_parse_ratio_literal(Quantity(value=value, raw_text=token.value, unit=unit))
            # Check for UCUM unit string (e.g., 1.5 'ml', 19.99 '[lb_av]')
            if self.match(TokenType.STRING):
                unit_token = self.advance()
                unit = unit_token.value
                return self._maybe_parse_ratio_literal(Quantity(value=value, raw_text=token.value, unit=unit))
            # CQL §2.3: standalone Decimal has max 28 integer digits and 8 fractional digits.
            # Validation only applies to Decimal literals, not Quantity values.
            raw_decimal = token.value.lstrip('+').lstrip('-')
            if '.' in raw_decimal:
                int_part, frac_part = raw_decimal.split('.', 1)
                # CQL 1.5 grammar decimalLiteral allows any number of
                # fractional digits; the resulting value is limited to the
                # implementation's maximum precision and scale (>= 28 digits
                # precision, 8 scale per the spec ToDecimal note). Limit by
                # rounding half-up to 8 fractional digits instead of
                # rejecting the literal.
                int_digits = int_part.lstrip('0') or '0'
                if len(int_digits) > 28:
                    raise ValueError(
                        f"Decimal literal '{token.value}' exceeds maximum 28 integer digits "
                        f"(CQL §2.3)"
                    )
                if len(frac_part) > 8:
                    from decimal import Decimal, ROUND_HALF_UP
                    limited = Decimal(token.value).quantize(
                        Decimal('1.00000000'), rounding=ROUND_HALF_UP
                    )
                    value = float(limited)
                    token = type(token)(type=token.type, value=format(limited, 'f'),
                                        line=token.line, column=token.column)
                    raw_str_override = format(limited, 'f')
            # CQL §Types/Ratio: bare numeric ratio literal.
            if self.match(TokenType.COLON):
                ratio = self._maybe_parse_ratio_literal(Quantity(value=value, raw_text=token.value, unit="1"))
                if isinstance(ratio, FunctionRef):
                    return ratio
                return Literal(value=value, type="Decimal", raw_str=raw_str_override or token.value)
            return Literal(value=value, type="Decimal", raw_str=raw_str_override or token.value)
        elif token.type == TokenType.STRING:
            return Literal(value=token.value, type="String")
        elif token.type == TokenType.TRUE:
            return Literal(value=True, type="Boolean")
        elif token.type == TokenType.FALSE:
            return Literal(value=False, type="Boolean")
        elif token.type == TokenType.NULL:
            return Literal(value=None, type=None)
        else:
            raise ParseError(f"Unexpected literal type: {token.type}")

    def _maybe_parse_ratio_literal(self, numerator: Quantity) -> Union[Quantity, FunctionRef]:
        """Parse CQL ratio literal syntax: ``<quantity>:<quantity>``.

        CQL §Types/Ratio: ``structured type Ratio { numerator Quantity,
        denominator Quantity }``. Both components are Quantity values; a
        bare numeric (Integer/Long/Decimal) denominator is promoted to a
        Quantity with the default UCUM unit '1' (CQL §Types/Quantity).

        To avoid ambiguity with other COLON uses (notably the CQL aggregate
        clause ``starting <expr>: <body>``), only commit to the Ratio
        interpretation when the token immediately after COLON can begin a
        Quantity literal — i.e., a numeric (INTEGER/LONG/DECIMAL) or a
        string-delimited UCUM unit. Otherwise, leave the COLON in the
        token stream and return the numerator unchanged so the caller's
        context-specific parser handles it.
        """
        if not self.match(TokenType.COLON):
            return numerator
        # Peek at the token *after* the COLON. Only commit to Ratio if it
        # can start a Quantity literal. This prevents the aggregate clause
        # `starting 1: <expr>` from being misparsed as `1:<expr>` Ratio.
        next_token = self.peek(1)  # token after the COLON
        if next_token.type not in (
            TokenType.INTEGER, TokenType.LONG, TokenType.DECIMAL,
            TokenType.MINUS, TokenType.PLUS,  # signed numeric
            TokenType.STRING,  # UCUM unit like `'mg'`
        ):
            return numerator
        self.advance()  # consume COLON
        # CQL §Types/Ratio: denominator Quantity may be signed (negative).
        # `parse_literal()` does not accept a leading MINUS/PLUS, so detect
        # the sign here and apply it to the parsed numeric Quantity. This
        # mirrors the numerator sign-propagation in parse_unary_expression
        # (HISTORIAN CQL-03 fix) and covers spec examples such as `1:-8`,
        # `1 'mg':-8 'mg'`, `-1.5 'mg':-2.5 'mg'`.
        sign = 1
        if self.match_and_advance(TokenType.MINUS):
            sign = -1
        elif self.match_and_advance(TokenType.PLUS):
            sign = 1
        denominator = self.parse_literal()
        # A bare numeric Literal denominator is valid as a Ratio component
        # (spec example `1:8`). Promote it to a default-unit Quantity.
        if isinstance(denominator, Literal) and isinstance(denominator.value, (int, float)):
            denominator = Quantity(
                value=denominator.value * sign,
                unit="1",
                raw_text=denominator.raw_str,
            )
        elif sign == -1 and isinstance(denominator, Quantity):
            # Signed Quantity literal denominator (e.g., `-8 'mg'`).
            denominator = Quantity(value=denominator.value * sign, unit=denominator.unit,
                                   raw_text=("-" + denominator.raw_text)
                                   if denominator.raw_text else None)
        if not isinstance(denominator, Quantity):
            raise ParseError("Expected Quantity after ':' in Ratio literal")

        def _quantity_text(quantity: Quantity) -> str:
            # PAR-005: preserve the AUTHORED decimal text. `str(float)` emits
            # scientific notation for small magnitudes (`1e-05`), which
            # corrupts the ToRatio argument and breaks decimal exactness.
            text = quantity.raw_text
            if text is None:
                v = quantity.value
                if isinstance(v, float):
                    from decimal import Decimal

                    text = format(Decimal(str(v)), "f")
                else:
                    text = str(v)
            return f"{text} '{quantity.unit}'"

        return FunctionRef(
            name="ToRatio",
            arguments=[
                Literal(
                    value=f"{_quantity_text(numerator)}:{_quantity_text(denominator)}",
                    type="String",
                )
            ],
        )

    def parse_datetime_literal(self) -> DateTimeLiteral:
        """Parse a date/time literal."""
        token = self.advance()
        return DateTimeLiteral(value=token.value)

    def parse_time_literal(self) -> TimeLiteral:
        """Parse a time literal."""
        token = self.advance()
        return TimeLiteral(value=token.value)

    def parse_code_selector(self) -> "CodeSelector":
        """Parse a Code selector expression.

        Grammar: 'Code' STRING 'from' (identifier) ('display' STRING)?

        Examples:
            Code '73211009' from "SNOMED-CT"
            Code '73211009' from "SNOMED-CT" display 'Diabetes'
        """
        from .ast_nodes import CodeSelector

        self.expect(TokenType.CODE_TYPE, "Expected 'Code'")

        code_token = self.expect(TokenType.STRING, "Expected code value string after 'Code'")
        code_value = code_token.value

        self.expect(TokenType.FROM, "Expected 'from' after code value")
        # PAR-008: codesystemIdentifier allows a library-qualified reference
        # (`Code 'x' from Lib.CS`). Join dotted parts into the system name.
        system_name = self._parse_identifier_name()
        while self.match_and_advance(TokenType.DOT):
            system_name += "." + self._parse_identifier_name()

        display = None
        if self.match_and_advance(TokenType.DISPLAY):
            display_token = self.expect(TokenType.STRING, "Expected display string after 'display'")
            display = display_token.value

        return CodeSelector(code=code_value, system=system_name, display=display)

    def _parse_concept_selector(self) -> "InstanceExpression":
        """Parse a Concept selector: ``Concept { <code>, ... }``.

        Grammar (CQL 1.5 conceptSelector): members are either inline Code
        selectors (``Code 'x' from "CS"``) or references to named codes
        declared in the library header. Lowered to an InstanceExpression of
        Concept with a ``codes`` list, the same shape the generic instance
        path produces for ``Concept { codes: { ... } }`` (which the
        translator folds via _fold_static_concept_instance).
        """
        self.expect(TokenType.CONCEPT_TYPE, "Expected 'Concept'")
        self.expect(TokenType.LBRACE, "Expected '{' after 'Concept'")

        # Named-field instance form (`Concept { codes: { ... }, display: ... }`)
        # is NOT a concept selector — delegate to the generic type-constructor
        # parser by rewinding to before the 'Concept' token.
        if self.match(
            TokenType.IDENTIFIER, TokenType.QUOTED_IDENTIFIER
        ) and self.peek().type == TokenType.COLON:
            self.pos -= 2  # back before LBRACE and 'Concept'
            return self._parse_type_constructor()

        codes = []
        while not self.match(TokenType.RBRACE):
            if self.match(TokenType.CODE_TYPE):
                code_token = self.peek(1)
                if code_token.type != TokenType.STRING:
                    _tok = self.current()
                    raise ParseError(
                        "Expected a code string in Concept selector",
                        position=(_tok.line, _tok.column),
                    )
                codes.append(self.parse_code_selector())
            else:
                # Reference to a named code declared in the library header.
                # Emit a quoted Identifier — the same element shape the
                # named-field form `Concept { codes: { "N" } }` produces,
                # which the translator's concept folding resolves against
                # the library code table.
                codes.append(
                    Identifier(name=self._parse_identifier_name(), quoted=True)
                )
            if not self.match_and_advance(TokenType.COMMA):
                break

        self.expect(TokenType.RBRACE, "Expected '}' to close Concept selector")

        # Grammar conceptSelector carries an optional whole-selector display
        # clause after the closing brace.
        display = None
        if self.match_and_advance(TokenType.DISPLAY):
            display_token = self.expect(
                TokenType.STRING, "Expected display string after 'display'"
            )
            display = display_token.value

        from .ast_nodes import InstanceExpression, TupleElement, ListExpression

        codes_list = ListExpression(elements=codes)
        elements = [TupleElement(name="codes", type=codes_list)]
        if display is not None:
            elements.append(
                TupleElement(name="display", type=Literal(value=display, type="String"))
            )
        return InstanceExpression(type="Concept", elements=elements)

    def _parse_typed_list_selector(self) -> "BinaryExpression":
        """Parse a typed list selector: ``List<T>{ ... }`` or ``List{ ... }``.

        Grammar: ``('List' ('<' typeSpecifier '>')?)? '{' (query|expression)? '}'``.
        Lowered to ``<list literal> as List<T>`` — the established typed-list
        mechanism (typed empty arrays, Case 6a union eligibility, etc.), so
        ``List<Integer>{}`` behaves like ``{} as List<Integer>``.
        """
        self.expect(TokenType.LIST_TYPE, "Expected 'List'")
        element_type = None
        if self.match_and_advance(TokenType.LESS_THAN):
            element_type = self.parse_type_specifier()
            self.expect(TokenType.GREATER_THAN, "Expected '>' to close List type")

        if not self.match(TokenType.LBRACE):
            _tok = self.current()
            raise ParseError(
                "Expected '{' after List type specifier",
                position=(_tok.line, _tok.column),
            )
        list_expr = self._parse_brace_expression()

        if element_type is None:
            return list_expr

        from .ast_nodes import ListTypeSpecifier

        return BinaryExpression(
            operator="as",
            left=list_expr,
            right=ListTypeSpecifier(element_type=element_type),
        )

    def parse_interval(self) -> Interval:
        """Parse an interval expression."""
        self.expect(TokenType.INTERVAL, "Expected 'Interval'")

        # Determine open/closed bounds
        low_closed = True
        high_closed = True

        if self.match(TokenType.OPEN):
            self.advance()
            low_closed = False
        elif self.match(TokenType.CLOSED):
            self.advance()
            low_closed = True
        elif self.match(TokenType.OPEN_CLOSED):
            self.advance()
            low_closed = False
            high_closed = True
        elif self.match(TokenType.CLOSED_OPEN):
            self.advance()
            low_closed = True
            high_closed = False

        # Parse the bounds
        if self.match(TokenType.LBRACKET):
            self.advance()
        elif self.match(TokenType.LPAREN):
            self.advance()
            low_closed = False
        else:
            self.expect(TokenType.LBRACKET, "Expected '[' or '(' for interval")

        low = self.parse_expression()
        self.expect(TokenType.COMMA, "Expected ',' in interval")
        high = self.parse_expression()

        if self.match(TokenType.RBRACKET):
            self.advance()
            high_closed = True
        elif self.match(TokenType.RPAREN):
            self.advance()
            high_closed = False
        else:
            self.expect(TokenType.RBRACKET, "Expected ']' or ')' for interval")

        return Interval(low=low, high=high, low_closed=low_closed, high_closed=high_closed)

    def _parse_brace_expression(self) -> Expression:
        """Parse a brace expression: either a list literal or anonymous tuple selector.

        Distinguishes between:
        - List literal: { expr, expr, ... }
        - Tuple selector: { identifier: expr, identifier: expr, ... }
        """
        # Save position to peek inside
        save_pos = self.pos
        # Consume the LBRACE
        self.advance()

        # Check if this is empty braces (empty list)
        if self.match(TokenType.RBRACE):
            self.pos = save_pos
            return self.parse_list_literal()

        # Check if first element is identifier-like followed by colon (tuple selector)
        is_tuple = False
        inner_save = self.pos
        try:
            self._parse_identifier_name()
            if self.match(TokenType.COLON):
                is_tuple = True
        except Exception as e:
            _logger.debug("Lookahead for tuple selector failed: %s", e)
        self.pos = inner_save

        # Restore to before LBRACE
        self.pos = save_pos

        if is_tuple:
            return self._parse_anonymous_tuple()
        else:
            return self.parse_list_literal()

    def _parse_anonymous_tuple(self) -> TupleExpression:
        """Parse an anonymous tuple selector: { name: expr, ... }."""
        self.expect(TokenType.LBRACE, "Expected '{'")
        elements = []

        while not self.match(TokenType.RBRACE):
            name = self._parse_identifier_name()
            self.expect(TokenType.COLON, "Expected ':'")
            value = self.parse_expression()
            elements.append(TupleElement(name=name, type=value))

            if not self.match_and_advance(TokenType.COMMA):
                break

        self.expect(TokenType.RBRACE, "Expected '}'")
        return TupleExpression(elements=elements)

    def parse_list_literal(self) -> ListExpression:
        """Parse a list literal expression."""
        self.expect(TokenType.LBRACE, "Expected '{'")
        elements = []

        if not self.match(TokenType.RBRACE):
            elements.append(self.parse_expression())
            while self.match_and_advance(TokenType.COMMA):
                if self.match(TokenType.RBRACE):
                    break
                elements.append(self.parse_expression())

        self.expect(TokenType.RBRACE, "Expected '}'")
        return ListExpression(elements=elements)

    def parse_retrieve(self) -> Retrieve:
        """Parse a retrieve expression ([Type], [Type: "code"], [Type -> prop])."""
        self.expect(TokenType.LBRACKET, "Expected '['")

        # Parse the resource type
        resource_type = self._parse_identifier_name()
        # Handle model-qualified retrieve type: QICore.Procedure, FHIR.Claim, etc.
        # Discard the model qualifier for the local type name but PRESERVE it on
        # the AST node so profiled-model retrieves can resolve through the
        # named-profile registry (translator-side).
        model_qualifier = None
        if self.match(TokenType.DOT):
            model_qualifier = resource_type
            self.advance()  # consume DOT
            resource_type = self._parse_identifier_name()
        # Quoted model-qualified retrieves keep the prefix embedded in one
        # identifier (["USCore.BMIProfile"]) — strip it the same way.
        if "." in resource_type:
            model_qualifier = model_qualifier or resource_type.split(".", 1)[0]
            resource_type = resource_type.split(".", 1)[1]

        terminology = None
        terminology_property = None
        navigation_path = None
        additional_filters: list = []

        # Check for navigation (->) for related context retrieve
        if self.match_and_advance(TokenType.ARROW):
            navigation_path = self._parse_identifier_name()
        # Check for terminology filter
        elif self.match_and_advance(TokenType.COLON):
            # Optional property specification
            if self.match(TokenType.IDENTIFIER, TokenType.QUOTED_IDENTIFIER):
                # Check if this is a property name or the start of terminology
                if self.peek().type == TokenType.COLON:
                    terminology_property = self._parse_identifier_name()
                    self.expect(TokenType.COLON, "Expected ':' after property name")

            terminology = self.parse_expression()

            # CQL 2.0 multi-filter retrieve (FHIR-31397): comma-separated
            # additional filters, each `<path> <comparator> <terminology>`
            # (Logical Spec CodeFilterElement shape — explicit property and
            # comparator; all filters ANDed).
            while self.match_and_advance(TokenType.COMMA):
                prop = self._parse_identifier_name()
                while self.match_and_advance(TokenType.DOT):
                    prop = f"{prop}.{self._parse_identifier_name()}"
                comparator = self._parse_retrieve_filter_comparator()
                operand = self.parse_expression()
                additional_filters.append(
                    RetrieveFilter(
                        property=prop, comparator=comparator, terminology=operand
                    )
                )

        self.expect(TokenType.RBRACKET, "Expected ']'")
        return Retrieve(
            type=resource_type,
            terminology=terminology,
            terminology_property=terminology_property,
            navigation_path=navigation_path,
            model=model_qualifier,
            additional_filters=additional_filters,
        )

    def _parse_retrieve_filter_comparator(self) -> str:
        """Parse a multi-filter retrieve comparator: in / ~in / = / ~ /
        contains / ~contains (the retrieve codeComparator set)."""
        if self.match(TokenType.TILDE) and self.peek(1).type in (
            TokenType.IN, TokenType.CONTAINS,
        ):
            self.advance()  # consume TILDE
            if self.match_and_advance(TokenType.IN):
                return "~in"
            self.advance()  # CONTAINS
            return "~contains"
        if self.match_and_advance(TokenType.TILDE):
            return "~"
        if self.match_and_advance(TokenType.IN):
            return "in"
        if self.match_and_advance(TokenType.CONTAINS):
            return "contains"
        if self.match_and_advance(TokenType.EQUALS):
            return "="
        got = self.peek().value if self.peek() else "<eof>"
        raise ParseError(
            message=(
                "Expected a retrieve filter comparator (in, ~in, =, ~, "
                f"contains, ~contains) after the filter property; got '{got}'."
            )
        )

    def parse_tuple_expression(self) -> TupleExpression:
        """Parse a tuple literal expression."""
        self.expect(TokenType.TUPLE, "Expected 'Tuple'")
        self.expect(TokenType.LBRACE, "Expected '{'")

        elements = []
        while not self.match(TokenType.RBRACE):
            name = self._parse_identifier_name()
            self.expect(TokenType.COLON, "Expected ':'")
            value = self.parse_expression()
            elements.append(TupleElement(name=name, type=value))  # Using type field to store value temporarily

            if not self.match_and_advance(TokenType.COMMA):
                break

        self.expect(TokenType.RBRACE, "Expected '}'")
        return TupleExpression(elements=elements)

    def parse_case_expression(self) -> CaseExpression:
        """Parse a case expression."""
        self.expect(TokenType.CASE, "Expected 'case'")

        comparand = None
        case_items = []
        else_expr = None

        # Check for simple case (case X when ...)
        if not self.match(TokenType.WHEN):
            comparand = self.parse_expression()

        # Parse when clauses
        while self.match_and_advance(TokenType.WHEN):
            when_expr = self.parse_expression()
            self.expect(TokenType.THEN, "Expected 'then'")
            then_expr = self.parse_expression()
            case_items.append(CaseItem(when=when_expr, then=then_expr))

        # Parse else clause
        if self.match_and_advance(TokenType.ELSE):
            else_expr = self.parse_expression()

        self.expect(TokenType.END, "Expected 'end'")

        return CaseExpression(case_items=case_items, else_expr=else_expr, comparand=comparand)

    def parse_conditional_expression(self) -> ConditionalExpression:
        """Parse a conditional (if-then-else) expression."""
        self.expect(TokenType.IFF, "Expected 'if'")
        condition = self.parse_expression()
        self.expect(TokenType.THEN, "Expected 'then'")
        then_expr = self.parse_expression()
        self.expect(TokenType.ELSE, "Expected 'else'")
        else_expr = self.parse_expression()

        return ConditionalExpression(
            condition=condition,
            then_expr=then_expr,
            else_expr=else_expr,
        )

    def _parse_parenthesized_or_tuple(self) -> Expression:
        """Parse a parenthesized expression or tuple."""
        self.expect(TokenType.LPAREN, "Expected '('")
        try:
            expr = self.parse_expression()
        except RecursionError:
            raise ParseError(
                message="Expression exceeds maximum nesting depth. "
                "Simplify the expression or reduce parenthesization."
            ) from None

        if self.match_and_advance(TokenType.COMMA):
            # This is a tuple
            elements = [expr]
            while True:
                elements.append(self.parse_expression())
                if not self.match_and_advance(TokenType.COMMA):
                    break
            self.expect(TokenType.RPAREN, "Expected ')'")
            # Convert to tuple - this is a simplification
            return ListExpression(elements=elements)

        self.expect(TokenType.RPAREN, "Expected ')'")
        # Grammar querySource admits '(' expression ')' — a parenthesized
        # bare literal IS a valid query source, so mark it to exempt it from
        # the bare-literal alias rejection in parse_postfix_expression.
        if isinstance(expr, Literal):
            try:
                setattr(expr, "_parenthesized", True)
            except Exception:  # pragma: no cover - frozen/slots variants
                pass
        return expr

    def _parse_duration_between(self) -> DurationBetween:
        """Parse a duration between expression: years between X and Y."""
        precision_token = self.advance()
        precision = precision_token.value.lower().rstrip('s')

        return self._finish_duration_between(precision)

    def _parse_duration_in_between(self) -> DurationBetween:
        """Parse `duration in <precision> between X and Y` (grammar's
        durationBetweenExpression keyword form)."""
        self.expect(TokenType.IDENTIFIER, "Expected 'duration'")
        self.expect(TokenType.IN, "Expected 'in'")

        precision_token = self.advance()
        precision = precision_token.value.lower().rstrip('s')

        return self._finish_duration_between(precision)

    def _finish_duration_between(self, precision: str) -> DurationBetween:
        """Parse `between X and Y` operands at the addition tier.

        CQL 1.5 grammar: durationBetweenExpression operands are
        expressionTerm, which includes addition/subtraction but NOT the
        expression-level operators (inequality, equality, membership `in`,
        and/or/xor/implies). Those must bind OUTSIDE the duration-between so
        `years between A and B >= 18` parses as
        `(years between A and B) >= 18`, not `years between A and (B >= 18)`.

        Two deliberate deviations, both matching HEAD behavior:
        - union/intersect/except bind INSIDE the operand (the addition tier
          consumes set operators); the strict grammar would bind them
          outside, but no eCQM content relies on either reading.
        - unparenthesized `X as DateTime` operands are rejected (strict
          grammar: typeExpression is above expressionTerm) — use
          `(X as DateTime)`.
        """
        self.expect(TokenType.BETWEEN, "Expected 'between'")
        left = self.parse_addition_expression()
        self.expect(TokenType.AND, "Expected 'and'")
        right = self.parse_addition_expression()

        return DurationBetween(precision=precision, operand_left=left, operand_right=right)

    def _parse_difference_between(self) -> DifferenceBetween:
        """Parse a difference between expression: difference in years between X and Y."""
        self.expect(TokenType.IDENTIFIER, "Expected 'difference'")
        self.expect(TokenType.IN, "Expected 'in'")

        precision_token = self.advance()
        precision = precision_token.value.lower().rstrip('s')

        self.expect(TokenType.BETWEEN, "Expected 'between'")
        left = self.parse_addition_expression()
        self.expect(TokenType.AND, "Expected 'and'")
        right = self.parse_addition_expression()

        return DifferenceBetween(precision=precision, operand_left=left, operand_right=right)

    def _parse_component_extraction(self) -> DateComponent:
        """Parse a date component extraction: year from X."""
        component_token = self.advance()
        component = component_token.value.lower()

        # Skip 'from'
        self.expect(TokenType.FROM, "Expected 'from'")
        # Parse operand without type operators (is/as) so they apply to the whole expression
        operand = self.parse_addition_expression()

        return DateComponent(component=component, operand=operand)

    _WITHIN_UNIT_TYPES = (
        TokenType.YEAR, TokenType.MONTH, TokenType.DAY,
        TokenType.HOUR, TokenType.MINUTE, TokenType.SECOND,
        TokenType.MILLISECOND, TokenType.WEEK, TokenType.YEARS,
        TokenType.MONTHS, TokenType.DAYS, TokenType.HOURS,
        TokenType.MINUTES, TokenType.SECONDS, TokenType.MILLISECONDS,
        TokenType.WEEKS,
    )

    def _within_unit_follows(self) -> bool:
        """True when the token after a `within <number>` is a temporal unit."""
        return self.peek().type in self._WITHIN_UNIT_TYPES

    def _try_parse_precision_of(self) -> Optional[str]:
        """
        Try to parse a precision specifier like 'year of', 'month of', etc.
        Returns the precision string if found, None otherwise.
        Does not consume any tokens if the pattern doesn't match.
        """
        # Check if current token is a precision unit followed by 'of'
        if self.match(TokenType.YEAR, TokenType.MONTH, TokenType.DAY,
                      TokenType.HOUR, TokenType.MINUTE, TokenType.SECOND, TokenType.MILLISECOND,
                      TokenType.WEEK):
            # Look ahead for 'of'
            if self.peek().type == TokenType.OF:
                precision_token = self.advance()  # consume precision
                self.advance()  # consume 'of'
                return precision_token.value.lower()
        return None

    def _try_parse_complex_interval_comparison(self, operator_name: str) -> Optional[Expression]:
        """
        Try to parse complex temporal comparison patterns for starts/ends operators.

        Patterns:
        - <quantity> or less/or more on or after/on or before <precision> of start of/end of <expr>
        - more than/less than <quantity> before/after [precision of] [start of/end of] <expr>

        Example: starts 1 day or less on or after day of start of Interval[...]
        Example: starts more than 1 hour before start of X

        Returns the parsed expression if the pattern matches, None otherwise.
        """
        saved_pos = self.pos

        # Handle "more than N unit" / "less than N unit" prefix (e.g. "starts more than 1 hour before")
        more_less_prefix = None
        if self.match(TokenType.IDENTIFIER) and self.current().value.lower() in ("more", "less"):
            if self.peek().type == TokenType.IDENTIFIER and self.peek().value.lower() == "than":
                more_less_prefix = self.current().value.lower()  # "more" or "less"
                self.advance()  # consume 'more'/'less'
                self.advance()  # consume 'than'

        # Check if we have a quantity (number followed by time unit)
        if not self.match(TokenType.INTEGER, TokenType.DECIMAL):
            self.pos = saved_pos
            return None

        # Peek ahead to see if this is the complex pattern
        # We need: <number> <unit> or less/or more on or after/on or before
        # Parse quantity
        quantity_value = self.current().value
        self.advance()

        # Check for time unit
        if not self.match(TokenType.YEAR, TokenType.MONTH, TokenType.DAY,
                          TokenType.HOUR, TokenType.MINUTE, TokenType.SECOND, TokenType.MILLISECOND,
                          TokenType.WEEK, TokenType.YEARS, TokenType.MONTHS, TokenType.DAYS,
                          TokenType.HOURS, TokenType.MINUTES, TokenType.SECONDS, TokenType.MILLISECONDS,
                          TokenType.WEEKS):
            # Not a quantity, restore position
            self.pos = saved_pos
            return None

        unit = self.current().value
        self.advance()

        # Determine modifier: either from the "more/less than" prefix or from "or more/or less" token
        if more_less_prefix is not None:
            modifier = "or more" if more_less_prefix == "more" else "or less"
        else:
            # Check for 'or less' or 'or more'
            if not self.match(TokenType.OR_LESS, TokenType.OR_MORE):
                # Not the complex pattern, restore position
                self.pos = saved_pos
                return None
            modifier = self.current().value  # "or less" or "or more"
            self.advance()

        # Check for 'on or after', 'on or before', bare 'before'/'after',
        # or compound 'before or on' / 'after or on' (equivalent to 'on or before' / 'on or after')
        if self.match(TokenType.BEFORE) and self.peek().type == TokenType.OR and \
                self.peek(2).type == TokenType.IDENTIFIER and self.peek(2).value.lower() == "on":
            self.advance()  # consume 'before'
            self.advance()  # consume 'or'
            self.advance()  # consume 'on'
            direction = "on or before"
        elif self.match(TokenType.AFTER) and self.peek().type == TokenType.OR and \
                self.peek(2).type == TokenType.IDENTIFIER and self.peek(2).value.lower() == "on":
            self.advance()  # consume 'after'
            self.advance()  # consume 'or'
            self.advance()  # consume 'on'
            direction = "on or after"
        elif self.match(TokenType.ON_OR_AFTER, TokenType.ON_OR_BEFORE,
                        TokenType.BEFORE, TokenType.AFTER):
            direction = self.current().value
            self.advance()
        else:
            # Not the complex pattern, restore position
            self.pos = saved_pos
            return None

        # Check for precision specifier (e.g., "day of", "month of")
        precision = self._try_parse_precision_of()

        # Check for 'start of' or 'end of'
        inner_operator = None
        if self.match(TokenType.START):
            self.advance()
            if self.match(TokenType.OF):
                self.advance()
                inner_operator = "start of"
        elif self.match(TokenType.END):
            self.advance()
            if self.match(TokenType.OF):
                self.advance()
                inner_operator = "end of"

        # Parse the operand (the interval or expression)
        operand = self.parse_type_expression()

        # Wrap in inner operator if present (start of / end of)
        if inner_operator:
            operand = UnaryExpression(operator=inner_operator, operand=operand)

        # Build the complex expression
        # The operator encodes all the components: "starts 1 day or less on or after day of"
        operator_parts = [operator_name, f"{quantity_value} {unit}", modifier, direction]
        if precision:
            operator_parts.append(f"{precision} of")

        full_operator = " ".join(operator_parts)

        # Return a special BinaryExpression with metadata about the comparison
        # Store quantity info in a wrapper
        return BinaryExpression(
            operator=full_operator,
            left=Quantity(value=float(quantity_value), unit=unit),
            right=operand
        )

    def _parse_precision_of(self) -> Expression:
        """
        Parse a precision specifier expression: month of X, year of X, etc.
        Used in temporal comparisons like 'on or after month of @2012-11-15'.
        Returns a BinaryExpression with operator 'precision_of'.
        """
        precision_token = self.advance()  # consume precision unit
        precision = precision_token.value.lower()

        self.expect(TokenType.OF, "Expected 'of'")
        operand = self.parse_type_expression()

        # Return as a BinaryExpression with the precision as metadata
        return BinaryExpression(operator="precision of", left=Literal(value=precision, type="String"), right=operand)

    def _is_type_constructor(self) -> bool:
        """Check if current position is a type constructor."""
        # Type constructors like Quantity { value: 5, unit: 'mg' }
        # Also Code { code: 'xxx' }, ValueSet { id: 'xxx' }, Concept { ... }
        # And qualified names like System.ValueSet { ... }
        # NOTE: We must lookahead for '{' even for type-keyword tokens like QUANTITY,
        # because these tokens also serve as identifiers (e.g., parameter name 'quantity').
        
        saved_pos = self.pos
        if self.match(TokenType.QUANTITY, TokenType.RATIO, TokenType.CODE_TYPE,
                      TokenType.VALUESET_TYPE, TokenType.CONCEPT_TYPE,
                      TokenType.STRING_TYPE, TokenType.BOOLEAN, TokenType.INTEGER_TYPE,
                      TokenType.DECIMAL_TYPE, TokenType.DATE_TYPE, TokenType.DATETIME_TYPE,
                      TokenType.TIME_TYPE):
            self.advance()  # consume the type keyword
            # Check for qualified form (e.g., System.Quantity { ... })
            while self.match_and_advance(TokenType.DOT):
                if not self.match(TokenType.IDENTIFIER, TokenType.QUOTED_IDENTIFIER,
                                  TokenType.CODE_TYPE, TokenType.VALUESET_TYPE,
                                  TokenType.CONCEPT_TYPE, TokenType.QUANTITY,
                                  TokenType.STRING_TYPE, TokenType.BOOLEAN,
                                  TokenType.INTEGER_TYPE, TokenType.DECIMAL_TYPE):
                    break
                self.advance()
            is_constructor = self.match(TokenType.LBRACE)
            self.pos = saved_pos  # restore position
            return is_constructor
            
        self.pos = saved_pos # Ensure position is reset before second check
        # Check for identifier followed by { (e.g., Code, ValueSet, or System.ValueSet)
        if self.match(TokenType.IDENTIFIER, TokenType.QUOTED_IDENTIFIER):
            # Skip known function names that use { } for list arguments
            current_value = self.current().value.lower() if self.current().value else ""
            if current_value in ("collapse", "expand", "union", "intersect", "except"):
                return False
            # Look ahead to see if this is followed by . and more identifiers then {
            self.advance()  # consume the identifier
            # Check for qualified identifier (e.g., System.ValueSet)
            while self.match_and_advance(TokenType.DOT):
                if not self.match(TokenType.IDENTIFIER, TokenType.QUOTED_IDENTIFIER,
                                  TokenType.CODE_TYPE, TokenType.VALUESET_TYPE,
                                  TokenType.CONCEPT_TYPE, TokenType.QUANTITY):
                    break
                self.advance()
            is_constructor = self.match(TokenType.LBRACE)
            self.pos = saved_pos  # restore position
            return is_constructor
            
        self.pos = saved_pos
        return False

    def _parse_type_constructor(self) -> InstanceExpression:
        """Parse a type constructor expression."""
        # Parse the type name (possibly qualified like System.ValueSet)
        type_parts = []
        type_parts.append(self._parse_identifier_name())

        # Check for qualified identifier (e.g., System.ValueSet)
        while self.match_and_advance(TokenType.DOT):
            type_parts.append(self._parse_identifier_name())

        type_name = ".".join(type_parts)
        self.expect(TokenType.LBRACE, "Expected '{'")

        elements = []
        while not self.match(TokenType.RBRACE):
            name = self._parse_identifier_name()
            self.expect(TokenType.COLON, "Expected ':'")
            value = self.parse_expression()
            elements.append(TupleElement(name=name, type=value))

            if not self.match_and_advance(TokenType.COMMA):
                break

        self.expect(TokenType.RBRACE, "Expected '}'")
        return InstanceExpression(type=type_name, elements=elements)

    def _parse_identifier_or_function(self) -> Expression:
        """Parse an identifier that may be a function call."""
        # `quoted` must describe the token being consumed NOW. peek() looks at
        # pos+1, so the old `self.peek()` read the token AFTER the identifier
        # and inverted the flag: '"My Def"' parsed as quoted=False while
        # `Source "P"` parsed Source as quoted=True.
        current_token = self.current()
        is_quoted = current_token.type == TokenType.QUOTED_IDENTIFIER
        name = self._parse_identifier_name()

        # Check for function call with parentheses
        if self.match(TokenType.LPAREN):
            return self._parse_function_call(Identifier(name=name, quoted=is_quoted))

        # Check for function call with curly braces (e.g., collapse { ... }, expand { ... })
        # This is valid CQL syntax for aggregate functions that take a list
        if self.match_and_advance(TokenType.LBRACE):
            return self._parse_function_call_with_braces(name)

        # Special handling for 'expand'/'collapse' without braces: expand/collapse X per ...
        if name.lower() in ("expand", "collapse"):
            # Parse the list/interval argument (could be Interval[...] or identifier).
            # parse_postfix_expression (not parse_primary_expression) so a
            # property-path operand (`expand E1.period per day`) consumes its
            # full DOT/invocation chain here; parse_primary_expression stops
            # after the primary and leaves `.period` dangling, which the outer
            # parse_expression then rejects as trailing tokens at PER.
            interval_arg = self.parse_postfix_expression()
            # Check for 'per' keyword
            if self.match_and_advance(TokenType.PER):
                per_value = self._parse_per_value()
                return FunctionRef(name=name, arguments=[interval_arg, per_value])
            return FunctionRef(name=name, arguments=[interval_arg])

        return Identifier(name=name, quoted=is_quoted)

    def _parse_function_call_with_braces(self, name: str) -> FunctionRef:
        """Parse a function call with curly brace syntax (e.g., collapse { ... })."""
        # The { has already been matched, so parse the list content
        elements = []
        if not self.match(TokenType.RBRACE):
            elements.append(self.parse_expression())
            while self.match_and_advance(TokenType.COMMA):
                if self.match(TokenType.RBRACE):
                    break
                elements.append(self.parse_expression())

        self.expect(TokenType.RBRACE, "Expected '}'")

        # Check for 'per' keyword after expand/collapse (e.g., expand { ... } per day)
        if name.lower() in ("expand", "collapse") and self.match_and_advance(TokenType.PER):
            per_value = self._parse_per_value()
            return FunctionRef(name=name, arguments=[ListExpression(elements=elements), per_value])

        return FunctionRef(name=name, arguments=[ListExpression(elements=elements)])

    def _parse_per_value(self) -> Expression:
        """Parse the value after 'per' keyword in expand expression.

        Examples:
            per day
            per 2
            per 2 days
            per hour
            per 0.1
        """
        # Check for a number first (e.g., per 2, per 0.1)
        if self.match(TokenType.INTEGER, TokenType.DECIMAL):
            value_token = self.advance()
            value = float(value_token.value) if value_token.type == TokenType.DECIMAL else int(value_token.value)

            # Check for optional temporal unit (e.g., per 2 days)
            if self.match(TokenType.YEAR, TokenType.YEARS, TokenType.MONTH, TokenType.MONTHS,
                          TokenType.WEEK, TokenType.WEEKS, TokenType.DAY, TokenType.DAYS,
                          TokenType.HOUR, TokenType.HOURS, TokenType.MINUTE, TokenType.MINUTES,
                          TokenType.SECOND, TokenType.SECONDS, TokenType.MILLISECOND, TokenType.MILLISECONDS):
                unit_token = self.advance()
                unit = unit_token.value.lower().rstrip('s')
                return Quantity(value=float(value), unit=unit)
            if self.match(TokenType.STRING):
                unit_token = self.advance()
                return Quantity(value=float(value), unit=unit_token.value)

            # Just a number without unit
            return Quantity(value=float(value), unit="")

        # Check for temporal unit only (e.g., per day, per hour)
        if self.match(TokenType.YEAR, TokenType.YEARS, TokenType.MONTH, TokenType.MONTHS,
                      TokenType.WEEK, TokenType.WEEKS, TokenType.DAY, TokenType.DAYS,
                      TokenType.HOUR, TokenType.HOURS, TokenType.MINUTE, TokenType.MINUTES,
                      TokenType.SECOND, TokenType.SECONDS, TokenType.MILLISECOND, TokenType.MILLISECONDS):
            unit_token = self.advance()
            unit = unit_token.value.lower().rstrip('s')
            return Quantity(value=1.0, unit=unit)

        # Fallback: parse as general expression
        return self.parse_primary_expression()

    def _parse_function_call(self, func: Union[Identifier, QualifiedIdentifier, Property]) -> FunctionRef:
        """Parse a function call."""
        if isinstance(func, Identifier):
            name = func.name
        elif isinstance(func, QualifiedIdentifier):
            name = ".".join(func.parts)
        elif isinstance(func, Property):
            # For property access like FHIRHelpers.ToQuantity, build the full path
            parts = []
            current = func
            while isinstance(current, Property):
                parts.insert(0, current.path)
                current = current.source
            if isinstance(current, Identifier):
                parts.insert(0, current.name)
            name = ".".join(parts)
        else:
            name = str(func)

        self.expect(TokenType.LPAREN, "Expected '('")

        arguments = []
        if not self.match(TokenType.RPAREN):
            arguments.append(self.parse_expression())
            while self.match_and_advance(TokenType.COMMA):
                arguments.append(self.parse_expression())

        self.expect(TokenType.RPAREN, "Expected ')'")
        return FunctionRef(name=name, arguments=arguments)

    def _parse_aggregate_expression(self) -> AggregateExpression:
        """Parse an aggregate expression."""
        operator = self.advance().value.lower()
        self.expect(TokenType.LPAREN, "Expected '('")

        source = self.parse_expression()
        initializer = None

        if self.match_and_advance(TokenType.COMMA):
            initializer = self.parse_expression()

        self.expect(TokenType.RPAREN, "Expected ')'")
        return AggregateExpression(source=source, operator=operator, initializer=initializer)

    def _parse_boundary_qualified_operand(self) -> Expression:
        """Parse a before/after right operand with an optional start/end
        boundary qualifier: ``A before end B`` ≡ ``A before end of B``
        (CQL 1.5 intervalOperatorPhrase allows the bare qualifier without
        the ``of``)."""
        if self.match(TokenType.START, TokenType.END):
            qualifier = self.advance().value.lower()
            if self.match_and_advance(TokenType.OF):
                operand = self.parse_type_expression()
            else:
                operand = self.parse_type_expression()
            return UnaryExpression(operator=f"{qualifier} of", operand=operand)
        return self.parse_type_expression()

    def _parse_temporal_expression(self) -> Expression:
        """Parse a temporal expression."""
        token = self.advance()
        operator = token.value.lower()

        # These are typically binary operators
        right = self.parse_unary_expression()
        # Temporal operators need a left operand - this is handled in comparison
        # For now, return as unary (this should be refactored)
        return UnaryExpression(operator=operator, operand=right)

    # =========================================================================
    # Query Parsing
    # =========================================================================

    def parse_from_query(self) -> Query:
        """Parse a CQL query expression starting with 'from' keyword.

        Example: from ({2, 3}) A, ({5, 6}) B where A > B return A
        """
        self.expect(TokenType.FROM, "Expected 'from'")

        # Parse source clause
        source = self.parse_query_source()
        sources = [source]

        # Parse additional sources (with commas)
        while self.match_and_advance(TokenType.COMMA):
            sources.append(self.parse_query_source())

        if len(sources) == 1:
            query_source = sources[0]
        else:
            query_source = sources

        query = Query(source=query_source)

        # When there are multiple sources, parse_postfix_expression may have
        # parsed each source as an inner Query that greedily absorbed an alias
        # and possibly where/return/sort/let clauses meant for this outer from-query.
        # Detect this and unwrap all inner Query sources back to plain QuerySources.
        if len(sources) > 1:
            for i, src in enumerate(sources):
                inner_expr = src.expression
                if isinstance(inner_expr, Query) and isinstance(inner_expr.source, QuerySource):
                    has_clauses = (
                        inner_expr.where is not None
                        or inner_expr.return_clause is not None
                        or inner_expr.sort is not None
                        or inner_expr.with_clauses
                        or inner_expr.let_clauses
                        or inner_expr.aggregate is not None
                    )
                    if has_clauses:
                        # Lift clauses from the inner query to the outer from-query
                        query.where = inner_expr.where
                        query.return_clause = inner_expr.return_clause
                        query.sort = inner_expr.sort
                        query.with_clauses = inner_expr.with_clauses
                        query.let_clauses = inner_expr.let_clauses
                        query.aggregate = inner_expr.aggregate
                    # Unwrap the inner Query to a plain QuerySource
                    sources[i] = inner_expr.source

        # Parse query clauses
        while True:
            if self.match(TokenType.WHERE) and query.where is None:
                query.where = self.parse_where_clause()
            elif self.match(TokenType.RETURN) and query.return_clause is None:
                query.return_clause = self.parse_return_clause()
            elif self.match(TokenType.SORT) and query.sort is None:
                query.sort = self.parse_sort_clause()
            elif self.match(TokenType.WITH, TokenType.WITHOUT):
                query.with_clauses.append(self.parse_with_clause())
            elif self.match(TokenType.LET):
                query.let_clauses.extend(self.parse_let_clause())
            elif self.match(TokenType.AGGREGATE) and query.aggregate is None:
                query.aggregate = self.parse_aggregate_clause()
            else:
                break

        return query

    def parse_query(self) -> Query:
        """Parse a CQL query expression."""
        # Parse source clause
        source = self.parse_query_source()
        sources = [source]

        # Parse additional sources (with commas)
        while self.match_and_advance(TokenType.COMMA):
            sources.append(self.parse_query_source())

        if len(sources) == 1:
            query_source = sources[0]
        else:
            query_source = sources

        query = Query(source=query_source)

        # Parse query clauses
        while True:
            if self.match(TokenType.WHERE) and query.where is None:
                query.where = self.parse_where_clause()
            elif self.match(TokenType.RETURN) and query.return_clause is None:
                query.return_clause = self.parse_return_clause()
            elif self.match(TokenType.SORT) and query.sort is None:
                query.sort = self.parse_sort_clause()
            elif self.match(TokenType.WITH, TokenType.WITHOUT):
                query.with_clauses.append(self.parse_with_clause())
            elif self.match(TokenType.LET):
                query.let_clauses.extend(self.parse_let_clause())
            else:
                break

        return query

    def parse_query_source(self) -> QuerySource:
        """Parse a query source clause."""
        expression = self.parse_expression()

        # Check for alias (accept identifiers and FHIR resource type keywords)
        alias = None
        if self.match(TokenType.IDENTIFIER, TokenType.QUOTED_IDENTIFIER,
                      TokenType.LOCATION, TokenType.PATIENT, TokenType.PRACTITIONER,
                      TokenType.ORGANIZATION, TokenType.RESOURCE, TokenType.BUNDLE):
            # Peek ahead to see if this is an alias
            next_token = self.peek()
            if next_token.type in (TokenType.WHERE, TokenType.RETURN, TokenType.SORT,
                                   TokenType.WITH, TokenType.WITHOUT, TokenType.LET,
                                   TokenType.COMMA, TokenType.EOF, TokenType.RPAREN,
                                   TokenType.AGGREGATE, TokenType.COMMA, TokenType.RBRACKET, TokenType.RBRACE):
                alias = self._parse_identifier_name()

        return QuerySource(alias=alias or "", expression=expression)

    def parse_where_clause(self) -> WhereClause:
        """Parse a where clause."""
        self.expect(TokenType.WHERE, "Expected 'where'")
        expression = self.parse_expression()
        return WhereClause(expression=expression)

    def parse_return_clause(self) -> ReturnClause:
        """Parse a return clause.

        Supports:
            return <expr>
            return all <expr>
            return distinct <expr>
        """
        self.expect(TokenType.RETURN, "Expected 'return'")
        # CQL 1.5 §Query: `return` eliminates duplicate results; `return all`
        # keeps them (`return distinct` is the redundant explicit form).
        # The translator honours the flag ONLY at a definition root, where the
        # query materialises into a CTE; applying it to nested/inlined query
        # selects leaks DISTINCT into scalar property extractions
        # (`intervalStart((SELECT DISTINCT …))`) and breaks CMS56's
        # `with … such that` correlation.
        distinct = True
        explicit_distinct = False
        if self.match_and_advance(TokenType.DISTINCT, TokenType.DISTINCT_FN):
            explicit_distinct = True
            distinct = True
        elif self.match_and_advance(TokenType.ALL):
            distinct = False  # explicit 'all' means no distinct
        expression = self.parse_expression()
        return ReturnClause(
            expression=expression,
            distinct=distinct,
            explicit_distinct=explicit_distinct,
        )

    def parse_sort_clause(self) -> SortClause:
        """Parse a sort clause.

        Supports two forms:
        - sort asc/desc (simple sort on whole item)
        - sort by [asc/desc] expression (sort by expression)
        """
        self.expect(TokenType.SORT, "Expected 'sort'")

        # Check for simple sort: sort asc or sort desc (without 'by')
        if self.match(TokenType.ASC):
            direction = "asc"
            self.advance()
            return SortClause(by=[SortByItem(direction=direction, expression=None)])
        elif self.match(TokenType.DESC):
            direction = "desc"
            self.advance()
            return SortClause(by=[SortByItem(direction=direction, expression=None)])

        # Full sort by expression: sort by [asc/desc] expr
        self.expect(TokenType.BY, "Expected 'by'")

        by_items = []
        while True:
            direction = "asc"
            # Direction can appear before or after the expression
            direction_before = False
            if self.match_and_advance(TokenType.ASC):
                direction = "asc"
                direction_before = True
            elif self.match_and_advance(TokenType.DESC):
                direction = "desc"
                direction_before = True

            expression = self.parse_expression()

            # Also check for trailing asc/desc after the expression
            if not direction_before:
                if self.match_and_advance(TokenType.ASC):
                    direction = "asc"
                elif self.match_and_advance(TokenType.DESC):
                    direction = "desc"

            by_items.append(SortByItem(direction=direction, expression=expression))

            if not self.match_and_advance(TokenType.COMMA):
                break

        return SortClause(by=by_items)

    def parse_with_clause(self) -> WithClause:
        """Parse a with/without clause."""
        is_without = self.match_and_advance(TokenType.WITHOUT) is not None
        if not is_without:
            self.expect(TokenType.WITH, "Expected 'with' or 'without'")

        expression = self.parse_expression()
        alias = None

        if self.match(TokenType.IDENTIFIER, TokenType.QUOTED_IDENTIFIER,
                      TokenType.LOCATION, TokenType.PATIENT, TokenType.PRACTITIONER,
                      TokenType.ORGANIZATION, TokenType.RESOURCE, TokenType.BUNDLE):
            alias = self._parse_identifier_name()

        self.expect(TokenType.SUCH, "Expected 'such that'")
        self.expect(TokenType.THAT, "Expected 'such that'")
        such_that = self.parse_expression()

        return WithClause(alias=alias or "", expression=expression, such_that=such_that, is_without=is_without)

    def parse_let_clause(self) -> List[LetClause]:
        """Parse a let clause with potentially multiple comma-separated bindings.

        Examples:
            let S: expression
            let S: expression1, E: expression2
        """
        self.expect(TokenType.LET, "Expected 'let'")

        clauses = []
        while True:
            alias = self._parse_identifier_name()
            self.expect(TokenType.COLON, "Expected ':'")
            expression = self.parse_expression()
            clauses.append(LetClause(alias=alias, expression=expression))

            # Check for comma-separated additional bindings
            pos_before_comma = self.pos
            if self.match_and_advance(TokenType.COMMA):
                # Check if next token is an identifier (or keyword-as-identifier)
                # followed by colon (another binding).
                # Use lookahead: try consuming identifier, check for ':'
                pos_after_comma = self.pos
                try:
                    self._parse_identifier_name()
                    if self.match(TokenType.COLON):
                        self.pos = pos_after_comma  # loop re-parses the binding
                        continue  # Parse another binding
                except Exception as e:
                    _logger.warning("Lookahead for let binding failed: %s", e)
                # Not another binding: restore to BEFORE the comma so an
                # invalid trailing comma surfaces as an unexpected token
                # (previously the comma was consumed and silently dropped).
                self.pos = pos_before_comma
            break

        return clauses

    def parse_aggregate_clause(self) -> AggregateClause:
        """Parse an aggregate clause.

        Examples:
            aggregate Result starting 1: Result + X
            aggregate distinct Result: Coalesce(Result, 0) + X
            aggregate all Result: Result + X
            aggregate Result: Result + X  (no starting value)
        """
        self.expect(TokenType.AGGREGATE, "Expected 'aggregate'")

        # Check for 'distinct' or 'all' modifiers
        # Note: 'distinct' can be tokenized as DISTINCT or DISTINCT_FN
        distinct = False
        all_ = False
        if self.match_and_advance(TokenType.DISTINCT, TokenType.DISTINCT_FN):
            distinct = True
        elif self.match_and_advance(TokenType.ALL):
            all_ = True

        # Parse the accumulator identifier
        identifier = self._parse_identifier_name()

        # Check for 'starting' clause
        starting = None
        if self.match_and_advance(TokenType.STARTING):
            starting = self.parse_expression()

        # Expect colon and parse the aggregation expression
        self.expect(TokenType.COLON, "Expected ':' after aggregate clause")
        expression = self.parse_expression()

        return AggregateClause(
            identifier=identifier,
            expression=expression,
            starting=starting,
            distinct=distinct,
            all_=all_
        )

    # =========================================================================
    # Type Specifier Parsing
    # =========================================================================

    def parse_type_specifier(self) -> TypeSpecifier:
        """Parse a type specifier."""
        # Check for interval type
        if self.match(TokenType.INTERVAL):
            return self._parse_interval_type_specifier()

        # Check for list type
        if self.match(TokenType.LIST_TYPE):
            return self._parse_list_type_specifier()

        # Check for tuple type
        if self.match(TokenType.TUPLE):
            return self._parse_tuple_type_specifier()

        # Check for choice type
        if self.match(TokenType.CHOICE):
            return self._parse_choice_type_specifier()

        # Default to named type
        return self._parse_named_type_specifier()

    def _parse_named_type_specifier(self) -> NamedTypeSpecifier:
        """Parse a named type specifier, including qualified names like System.Any."""
        name = self._parse_identifier_name()
        # Handle qualified names like System.Any, FHIR.Patient, etc.
        while self.match_and_advance(TokenType.DOT):
            name += "." + self._parse_identifier_name()
        return NamedTypeSpecifier(name=name)

    def _parse_interval_type_specifier(self) -> IntervalTypeSpecifier:
        """Parse an interval type specifier."""
        self.expect(TokenType.INTERVAL, "Expected 'Interval'")
        self.expect(TokenType.LESS_THAN, "Expected '<'")
        point_type = self.parse_type_specifier()
        self.expect(TokenType.GREATER_THAN, "Expected '>'")
        return IntervalTypeSpecifier(point_type=point_type)

    def _parse_list_type_specifier(self) -> ListTypeSpecifier:
        """Parse a list type specifier."""
        self.expect(TokenType.LIST_TYPE, "Expected 'List'")
        self.expect(TokenType.LESS_THAN, "Expected '<'")
        element_type = self.parse_type_specifier()
        self.expect(TokenType.GREATER_THAN, "Expected '>'")
        return ListTypeSpecifier(element_type=element_type)

    def _parse_tuple_type_specifier(self) -> TupleTypeSpecifier:
        """Parse a tuple type specifier."""
        self.expect(TokenType.TUPLE, "Expected 'Tuple'")
        self.expect(TokenType.LBRACE, "Expected '{'")

        elements = []
        while not self.match(TokenType.RBRACE):
            name = self._parse_identifier_name()
            self.expect(TokenType.COLON, "Expected ':'")
            element_type = self.parse_type_specifier()
            elements.append(TupleElement(name=name, type=element_type))

            if not self.match_and_advance(TokenType.COMMA):
                break

        self.expect(TokenType.RBRACE, "Expected '}'")
        return TupleTypeSpecifier(elements=elements)

    def _parse_choice_type_specifier(self) -> ChoiceTypeSpecifier:
        """Parse a choice type specifier."""
        self.expect(TokenType.CHOICE, "Expected 'Choice'")
        self.expect(TokenType.LESS_THAN, "Expected '<'")

        choices = [self.parse_type_specifier()]
        while self.match_and_advance(TokenType.COMMA):
            choices.append(self.parse_type_specifier())

        self.expect(TokenType.GREATER_THAN, "Expected '>'")
        return ChoiceTypeSpecifier(choices=choices)

    # =========================================================================
    # Query Operator Parsing Methods
    # =========================================================================

    def _parse_skip_expression(self, source: Expression) -> SkipExpression:
        """Parse: skip SOURCE COUNT"""
        self.expect(TokenType.SKIP, "Expected 'skip'")
        count = self.parse_expression()
        return SkipExpression(source=source, count=count)

    def _parse_take_expression(self, source: Expression) -> TakeExpression:
        """Parse: take SOURCE COUNT"""
        self.expect(TokenType.TAKE, "Expected 'take'")
        count = self.parse_expression()
        return TakeExpression(source=source, count=count)

    def _parse_first_expression(self, source: Expression) -> FirstExpression:
        """Parse: first SOURCE"""
        self.expect(TokenType.FIRST, "Expected 'first'")
        return FirstExpression(source=source)

    def _parse_last_expression(self, source: Expression) -> LastExpression:
        """Parse: last SOURCE"""
        self.expect(TokenType.LAST, "Expected 'last'")
        return LastExpression(source=source)

    def _parse_any_expression(self, source: Expression) -> AnyExpression:
        """Parse: any SOURCE ALIAS where CONDITION"""
        self.expect(TokenType.ANY, "Expected 'any'")
        alias = self._parse_identifier_name()
        self.expect(TokenType.WHERE, "Expected 'where'")
        condition = self.parse_expression()
        return AnyExpression(source=source, alias=alias, condition=condition)

    def _parse_all_expression(self, source: Expression) -> AllExpression:
        """Parse: all SOURCE ALIAS where CONDITION"""
        self.expect(TokenType.ALL, "Expected 'all'")
        alias = self._parse_identifier_name()
        self.expect(TokenType.WHERE, "Expected 'where'")
        condition = self.parse_expression()
        return AllExpression(source=source, alias=alias, condition=condition)

    def _parse_singleton_expression(self, source: Expression) -> SingletonExpression:
        """Parse: singleton from SOURCE"""
        self.expect(TokenType.SINGLETON_FROM, "Expected 'singleton from'")
        return SingletonExpression(source=source)

    def _parse_distinct_expression(self, source: Expression) -> DistinctExpression:
        """Parse: distinct SOURCE"""
        # Accept both DISTINCT and DISTINCT_FN tokens
        if self.match(TokenType.DISTINCT):
            self.expect(TokenType.DISTINCT, "Expected 'distinct'")
        else:
            self.expect(TokenType.DISTINCT_FN, "Expected 'distinct'")
        return DistinctExpression(source=source)

    # =========================================================================
    # Helper Methods for Identifiers
    # =========================================================================

    def _build_qualified_name_from_property(self, expr: Expression) -> str:
        """Build a qualified type name from a Property chain (e.g., System.ValueSet)."""
        parts = []
        current = expr
        while isinstance(current, Property):
            parts.insert(0, current.path)
            current = current.source
        if isinstance(current, Identifier):
            parts.insert(0, current.name)
        return ".".join(parts)

    def _parse_identifier_name(self) -> str:
        """Parse an identifier name (regular or quoted)."""
        if self.match(TokenType.IDENTIFIER):
            return self.advance().value
        elif self.match(TokenType.QUOTED_IDENTIFIER):
            return self.advance().value
        elif self.match(TokenType.TIMEZONE_FROM):
            # 'timezoneoffset' is a CQL dateTimeComponent and a reserved
            # keyword usable as a property name (cql.g4 keywordIdentifier):
            # `(@2024-01-01T12:00:00+02:00).timezoneOffset`.
            return self.advance().value
        elif self.match(TokenType.PATIENT, TokenType.PRACTITIONER, TokenType.ORGANIZATION,
                        TokenType.LOCATION, TokenType.RESOURCE, TokenType.BUNDLE,
                        # 'context' is a cql.g4 keywordIdentifier (usable as a
                        # property name: MedAdministrations.context).
                        TokenType.CONTEXT):
            return self.advance().value
        elif self.match(TokenType.BOOLEAN, TokenType.INTEGER_TYPE, TokenType.LONG_TYPE, TokenType.DECIMAL_TYPE,
                        TokenType.STRING_TYPE, TokenType.DATE_TYPE, TokenType.DATETIME_TYPE,
                        TokenType.TIME_TYPE, TokenType.QUANTITY, TokenType.RATIO,
                        TokenType.INTERVAL, TokenType.LIST_TYPE, TokenType.TUPLE,
                        TokenType.CHOICE, TokenType.ANY, TokenType.CODE_TYPE,
                        TokenType.CONCEPT_TYPE, TokenType.CODESYSTEM_TYPE, TokenType.VALUESET_TYPE):
            return self.advance().value
        # Also accept function keywords as identifiers (they may be used as names)
        elif self.match(TokenType.COUNT, TokenType.SUM, TokenType.MIN, TokenType.MAX,
                        TokenType.AVG, TokenType.MEDIAN, TokenType.MODE, TokenType.LENGTH,
                        TokenType.CODE, TokenType.CONCEPT, TokenType.VALUESYSTEM,
                        TokenType.UPPER, TokenType.LOWER, TokenType.CONCATENATE,
                        TokenType.COMBINE, TokenType.SPLIT, TokenType.POSITION_OF,
                        TokenType.SUBSTRING, TokenType.STARTS_WITH, TokenType.ENDS_WITH,
                        TokenType.MATCHES, TokenType.REPLACE_MATCHES, TokenType.REPLACE,
                        TokenType.COALESCE, TokenType.IFF, TokenType.CASE, TokenType.WHEN,
                        TokenType.THEN, TokenType.ELSE, TokenType.END, TokenType.TO_BOOLEAN,
                        TokenType.TO_CONCEPT, TokenType.TO_DATE, TokenType.TO_DATETIME,
                        TokenType.TO_DECIMAL, TokenType.TO_INTEGER, TokenType.TO_QUANTITY,
                        TokenType.TO_STRING, TokenType.TO_TIME, TokenType.TO_CODE,
                        TokenType.TO_CHARS, TokenType.FROM_CHARS, TokenType.FIRST,
                        TokenType.LAST, TokenType.INDEXER, TokenType.FLATTEN,
                        TokenType.DISTINCT_FN, TokenType.CURRENT, TokenType.CHILDREN,
                        TokenType.DESCENDENTS, TokenType.ENCODE, TokenType.ESCAPE,
                        TokenType.PREVIOUS, TokenType.PREDECESSOR, TokenType.SUCCESSOR, TokenType.SINGLE,
                        TokenType.SELECT, TokenType.FOR, TokenType.OF, TokenType.REPEAT,
                        TokenType.INTERSECT, TokenType.EXCEPT, TokenType.UNION,
                        TokenType.EXPAND, TokenType.ROUND, TokenType.ABS, TokenType.CEILING,
                        TokenType.FLOOR, TokenType.LN, TokenType.LOG, TokenType.POWER,
                        TokenType.TRUNCATE, TokenType.EXP, TokenType.SQRT, TokenType.DIV,
                        TokenType.MOD, TokenType.REMAINDER, TokenType.WIDTH, TokenType.SIZE,
                        TokenType.POINT_FROM, TokenType.LOWBOUNDARY, TokenType.HIGHBOUNDARY,
                        TokenType.PRECISION, TokenType.MINIMUM, TokenType.MAXIMUM,
                        TokenType.ALL_TRUE, TokenType.ANY_TRUE,
                        TokenType.VARIANCE, TokenType.STDDEV,
                        TokenType.SKIP, TokenType.TAKE,
                        TokenType.DISPLAY, TokenType.CALLED,
                        TokenType.ASC, TokenType.DESC,
                        TokenType.SORT, TokenType.BY,
                        TokenType.VERSION,
                        TokenType.DATE_FROM, TokenType.TIME_FROM,
                        TokenType.YEAR, TokenType.YEARS, TokenType.MONTH, TokenType.MONTHS,
                        TokenType.WEEK, TokenType.WEEKS, TokenType.DAY, TokenType.DAYS,
                        TokenType.HOUR, TokenType.HOURS, TokenType.MINUTE, TokenType.MINUTES,
                        TokenType.SECOND, TokenType.SECONDS,
                        TokenType.MILLISECOND, TokenType.MILLISECONDS,
                        TokenType.IS, TokenType.AS,
                        TokenType.START, TokenType.STARTING,
                        TokenType.EXISTS, TokenType.CONTAINS,
                        TokenType.OVERLAPS, TokenType.BEFORE, TokenType.AFTER,
                        TokenType.MEETS, TokenType.STARTS, TokenType.ENDS,
                        TokenType.DURING, TokenType.INCLUDES, TokenType.PROPERLY):
            return self.advance().value
        else:
            token = self.current()
            raise ParseError(
                f"Expected identifier, got {token.type.name} '{token.value}'",
                position=(token.line, token.column),
            )


# Convenience function
def parse_cql(source: str) -> Library:
    """
    Parse CQL source code and return the AST.

    Args:
        source: CQL source code.

    Returns:
        Library AST node.
    """
    lexer = Lexer(source)
    tokens = lexer.tokenize()
    parser = CQLParser(tokens)
    library = parser.parse_library()

    # CQL 2.0 parameter constraints (FHIR-48682, trial-use): the @constraint
    # / @message / @constraintScope tags live in block comments the lexer
    # skips, so they are extracted from the raw source and attached to the
    # Library node here (single choke point).
    from .annotations import extract_parameter_constraints, parse_library_tags

    try:
        library.parameter_constraints = extract_parameter_constraints(
            parse_library_tags(source)
        )
    except ValueError as exc:
        line = 1
        column = 1
        raise ParseError(
            f"Invalid parameter constraint annotation: {exc}",
            position=(line, column),
        ) from exc

    return library


def parse_expression(source: str) -> Expression:
    """
    Parse a CQL expression and return the AST.

    Args:
        source: CQL expression source code.

    Returns:
        Expression AST node.
    """
    lexer = Lexer(source)
    tokens = lexer.tokenize()
    parser = CQLParser(tokens)
    expression = parser.parse_expression()
    # A well-formed expression must consume the entire input. Without this
    # check, malformed sources such as `successor of T05:30` (bare Time
    # literals require the @ prefix) silently parse a prefix and drop the
    # remainder (CQL-11 EXPLORER QA-004).
    if not parser.check(TokenType.EOF):
        token = parser.current()
        raise ParseError(
            f"Unexpected trailing tokens after expression at line "
            f"{token.line}, column {token.column}: {token.type.name} "
            f"'{token.value}'"
        )
    return expression


__all__ = [
    "CQLParser",
    "Parser",  # Alias for backward compatibility
    "parse_cql",
    "parse_expression",
]

# Alias for backward compatibility
Parser = CQLParser
