"""Step 5 — NotesPipeline multiprocessing pool (slow / opt-in).

These tests exercise the parallel path. They are gated by
``pytest.mark.slow`` and additionally skip when ``medterm4ds`` is not
importable. The pool is exercised via a mocked ``medterm4ds`` module so
the tests are hermetic.
"""

from __future__ import annotations

import pickle
import sys
import types
from dataclasses import dataclass

import pytest

from fhir4ds.cql.loader.notes_pipeline import (
    NotesPipeline,
    NotesPipelineConfig,
    _init_worker,
    _worker_extract_fragments,
    _WORKER_EXTRACT_FN,
    _WORKER_EXTRACT_KWARGS,
)


pytestmark = [pytest.mark.slow]


@dataclass
class _MockConcept:
    code: str
    source: str
    display: str
    matched_text: str
    status: str = "affirmed"
    confidence: float = 0.95
    match_grade: str = "certain"
    span_start: int = 0
    span_end: int = 0


# ── Picklability regression (audit S1) ────────────────────────────────


def test_worker_function_has_no_self_closure():
    """The worker function MUST be module-level — no closure over self.

    If a future refactor moves it inside NotesPipeline, ``self`` (and
    the parent's DuckDB connection) would be pickled into workers,
    breaking fork-safety.
    """
    # ``_worker_extract_fragments`` must be a module-level function.
    # Methods are detected by checking for ``__self__``.
    assert not hasattr(_worker_extract_fragments, "__self__"), (
        "Worker function must not be bound to a class instance"
    )
    # It must be picklable.
    try:
        pickle.dumps(_worker_extract_fragments)
    except Exception as exc:
        pytest.fail(f"Worker function not picklable: {exc}")


def test_init_worker_has_no_self_closure():
    assert not hasattr(_init_worker, "__self__")
    try:
        pickle.dumps(_init_worker)
    except Exception as exc:
        pytest.fail(f"_init_worker not picklable: {exc}")


# ── Worker function contract (with mocked medterm4ds) ────────────────


def test_worker_returns_per_fragment_grouping(monkeypatch):
    """Worker output shape: outer list = fragments, inner = concepts."""
    def _fake_extract(text, **kw):
        return [_MockConcept(
            code="C-1", source="SNOMEDCT_US",
            display=text[:10], matched_text=text,
            span_start=0, span_end=len(text),
        )]

    monkeypatch.setattr(
        "fhir4ds.cql.loader.notes_pipeline._WORKER_EXTRACT_FN", _fake_extract
    )
    monkeypatch.setattr(
        "fhir4ds.cql.loader.notes_pipeline._WORKER_EXTRACT_KWARGS",
        {"format": "codes"},
    )

    @dataclass
    class _Fragment:
        text: str
        source_ref: str
        path: str

    fragments = [_Fragment(text="hello", source_ref="Obs/1", path="note[0].text")]
    out = _worker_extract_fragments(({"resourceType": "Observation"}, fragments))
    assert len(out) == 1  # one fragment
    assert len(out[0]) == 1  # one concept
    assert isinstance(out[0][0], dict)  # dict at process boundary
    assert out[0][0]["code"] == "C-1"


def test_worker_converts_dataclass_to_dict():
    """Worker output is plain dicts, not dataclasses."""
    def _fake_extract(text, **kw):
        return [_MockConcept(
            code="X", source="S", display="D", matched_text="m",
        )]

    import fhir4ds.cql.loader.notes_pipeline as np_mod
    original_fn = np_mod._WORKER_EXTRACT_FN
    original_kwargs = np_mod._WORKER_EXTRACT_KWARGS
    np_mod._WORKER_EXTRACT_FN = _fake_extract
    np_mod._WORKER_EXTRACT_KWARGS = {"format": "codes"}
    try:
        @dataclass
        class _F:
            text: str
            source_ref: str
            path: str
        out = np_mod._worker_extract_fragments(
            ({"resourceType": "Observation"}, [_F(text="t", source_ref="r", path="p")])
        )
        assert isinstance(out[0][0], dict)
        # Pickle round-trip must succeed (process-boundary safety)
        pickle.loads(pickle.dumps(out[0][0]))
    finally:
        np_mod._WORKER_EXTRACT_FN = original_fn
        np_mod._WORKER_EXTRACT_KWARGS = original_kwargs


def test_worker_handles_engine_failure():
    """If medterm4ds.extract raises, worker returns empty fragment list."""
    def _bad_extract(text, **kw):
        raise RuntimeError("boom")

    import fhir4ds.cql.loader.notes_pipeline as np_mod
    original_fn = np_mod._WORKER_EXTRACT_FN
    np_mod._WORKER_EXTRACT_FN = _bad_extract
    np_mod._WORKER_EXTRACT_KWARGS = {"format": "codes"}
    try:
        @dataclass
        class _F:
            text: str
            source_ref: str
            path: str
        out = np_mod._worker_extract_fragments(
            ({"resourceType": "Observation"}, [_F(text="t", source_ref="r", path="p")])
        )
        assert out == [[]]
    finally:
        np_mod._WORKER_EXTRACT_FN = original_fn


# ── extract_kwargs centralization ────────────────────────────────────


def test_extract_kwargs_matches_call_medterm4ds(monkeypatch):
    """_extract_kwargs must produce the same dict as _call_medterm4ds.

    The kwargs surface is constrained by what the published
    ``medterm4ds.extract`` (PyPI 0.0.1) accepts. ``categories`` is NOT
    in that surface — it was an internal medterm4ds API that never
    shipped on PyPI.
    """
    cfg = NotesPipelineConfig(
        mode="hybrid",
        min_grade="certain",
        include_negated=True,
        include_uncertain=False,
        include_historical=True,
        include_family=True,
    )
    pipe = NotesPipeline(cfg)
    expected = {
        "format": "codes",
        "mode": "hybrid",
        "min_grade": "certain",
        "include_negated": True,
        "include_uncertain": False,
        "include_historical": True,
        "include_family": True,
    }
    assert pipe._extract_kwargs() == expected


# ── Parallel dispatch via real Pool (medterm4ds mocked) ──────────────


def test_parallel_dispatch_with_mocked_engine(monkeypatch):
    """End-to-end test of _extract_batch_parallel with a mocked Pool.

    We monkeypatch ``multiprocessing.Pool`` to run in-process so the
    test doesn't fork (which would break the monkeypatched medterm4ds
    module reference).
    """
    def _fake_extract(text, **kw):
        return [_MockConcept(
            code="C-1", source="SNOMEDCT_US",
            display=text[:5], matched_text=text,
            span_start=0, span_end=len(text),
        )]

    fake_module = types.ModuleType("medterm4ds")
    fake_module.extract = _fake_extract
    fake_module.__index_version__ = "v1"
    monkeypatch.setitem(sys.modules, "medterm4ds", fake_module)

    # Replace multiprocessing.Pool with an in-process executor that
    # honors the same initializer contract.
    from multiprocessing import Pool as _RealPool
    from multiprocessing.pool import ThreadPool

    class _InProcessPool:
        def __init__(self, processes=None, *, initializer=None, initargs=()):
            self._initializer = initializer
            self._initargs = initargs
            if initializer:
                initializer(*initargs)

        def map(self, fn, iterable, chunksize=None):
            return [fn(x) for x in iterable]

        def __enter__(self):
            return self

        def __exit__(self, *args):
            return False

    monkeypatch.setattr("multiprocessing.Pool", _InProcessPool)

    cfg = NotesPipelineConfig(
        batch_size=10, workers=2, parallel_threshold=2,
    )
    pipe = NotesPipeline(cfg)

    resources = [
        {"resourceType": "Observation", "id": f"o-{i}",
         "subject": {"reference": "Patient/p1"},
         "note": [{"text": f"diabetes {i}"}]}
        for i in range(5)
    ]
    out = pipe.extract_conditions_batch(resources)
    assert len(out) == 5
    # Each resource has 1 derived Condition
    for conds in out:
        assert len(conds) == 1
        assert conds[0]["resourceType"] == "Condition"


def test_worker_dict_carries_result_type_for_parallel_typing_d12h():
    """QA-D12H-003 (v0.0.26 D12 HISTORIAN): the worker's concept->dict
    conversion must carry ``result_type``.

    The sync path hands the medterm4ds dataclass to
    ``_build_derived_resource``, whose ``resource_type_for`` call maps
    ``result_type='vaccine'`` to Immunization, ``'medication'`` to
    MedicationStatement, etc. The PARALLEL path converts concepts to
    dicts at the process boundary; without ``result_type`` the parent's
    ``_safe_getattr(concept, "result_type")`` sees None and every
    concept files as the DEFAULT ``Condition`` — a vaccine becomes a
    diagnosis, silently, only in parallel mode.
    """
    from types import SimpleNamespace

    def _fake_extract(text, **kw):
        return [SimpleNamespace(
            code="J07BB", source="ATC", system=None, display="flu vaccine",
            matched_text="flu vaccine", status="affirmed", section=None,
            confidence=0.9, match_grade="certain", ner_label=None,
            result_type="vaccine", span_start=0, span_end=11,
        )]

    import fhir4ds.cql.loader.notes_pipeline as np_mod
    original_fn = np_mod._WORKER_EXTRACT_FN
    original_kwargs = np_mod._WORKER_EXTRACT_KWARGS
    np_mod._WORKER_EXTRACT_FN = _fake_extract
    np_mod._WORKER_EXTRACT_KWARGS = {"format": "codes"}
    try:
        @dataclass
        class _F:
            text: str
            source_ref: str
            path: str
        out = np_mod._worker_extract_fragments(
            ({"resourceType": "DocumentReference"},
             [_F(text="flu vaccine given", source_ref="Doc/1", path="p")])
        )
        wdict = out[0][0]
        assert wdict.get("result_type") == "vaccine", (
            "worker dict must carry result_type or the parallel path "
            f"degrades every concept to Condition; keys={sorted(wdict)}"
        )
        # End-to-end: the parent builds the derived resource from the
        # worker dict and must reach the SAME type the sync path would.
        pipeline = np_mod.NotesPipeline(np_mod.NotesPipelineConfig())
        frag = SimpleNamespace(text="t", source_ref="Doc/1", path="p")
        built = pipeline._build_derived_resource(wdict, frag, {})
        assert built is not None
        assert built["resourceType"] == "Immunization", (
            f"parallel-path concept filed as {built['resourceType']} "
            "(sync path files it as Immunization)"
        )
    finally:
        np_mod._WORKER_EXTRACT_FN = original_fn
        np_mod._WORKER_EXTRACT_KWARGS = original_kwargs
