"""
Unit tests for ExpressionTranslator class (translator_v2).

Tests the translation of CQL expressions to SQL using the DuckDB FHIRPath UDFs,
including:
- Literal expressions (null, boolean, string, integer, decimal)
- DateTime and Time literals
- Identifier references (simple, qualified)
- Property access (with fhirpath UDFs)
- Arithmetic operators (+, -, *, /, div, mod, ^)
- Comparison operators (=, <>, <, <=, >, >=)
- Logical operators (and, or, not)
- Interval construction (closed, open, half-open)
- Conditional expressions (if-then-else)
"""

import pytest

from ...parser.ast_nodes import (
    AllExpression,
    AnyExpression,
    BinaryExpression,
    ConditionalExpression,
    DateTimeLiteral,
    DifferenceBetween,
    DurationBetween,
    FirstExpression,
    Identifier,
    Interval,
    LastExpression,
    Literal,
    Property,
    QualifiedIdentifier,
    Retrieve,
    SkipExpression,
    TakeExpression,
    UnaryExpression,
)
from ...translator.context import SQLTranslationContext
from ...translator.expressions import (
    BINARY_OPERATOR_MAP,
    ExpressionTranslator,
    UNARY_OPERATOR_MAP,
)
from ...translator.types import (
    SQLArray,
    SQLBinaryOp,
    SQLCase,
    SQLCast,
    SQLFunctionCall,
    SQLIdentifier,
    SQLInterval,
    SQLLiteral,
    SQLNull,
    SQLParameterRef,
    SQLQualifiedIdentifier,
    SQLRaw,
    SQLUnaryOp,
)


class TestLiterals:
    """Tests for literal expression translation."""

    @pytest.fixture
    def translator(self) -> ExpressionTranslator:
        """Create an ExpressionTranslator instance for testing."""
        context = SQLTranslationContext()
        return ExpressionTranslator(context)

    def test_integer_literal(self, translator: ExpressionTranslator):
        """Test integer literal translation: 5 -> 5."""
        result = translator.translate(Literal(value=5))
        assert isinstance(result, SQLLiteral)
        assert result.value == 5
        assert result.to_sql() == "5"

    def test_integer_zero(self, translator: ExpressionTranslator):
        """Test zero integer literal."""
        result = translator.translate(Literal(value=0))
        assert isinstance(result, SQLLiteral)
        assert result.value == 0
        assert result.to_sql() == "0"

    def test_integer_negative(self, translator: ExpressionTranslator):
        """Test negative integer literal."""
        result = translator.translate(Literal(value=-42))
        assert isinstance(result, SQLLiteral)
        assert result.value == -42
        assert result.to_sql() == "-42"

    def test_decimal_literal(self, translator: ExpressionTranslator):
        """Test decimal literal translation: 3.14 -> 3.14."""
        result = translator.translate(Literal(value=3.14))
        assert isinstance(result, SQLLiteral)
        assert result.value == 3.14
        assert result.to_sql() == "3.14"

    def test_decimal_small(self, translator: ExpressionTranslator):
        """Test small decimal literal."""
        result = translator.translate(Literal(value=0.001))
        assert isinstance(result, SQLLiteral)
        assert result.value == 0.001
        assert result.to_sql() == "0.001"

    def test_string_literal(self, translator: ExpressionTranslator):
        """Test string literal translation: 'hello' -> 'hello'."""
        result = translator.translate(Literal(value="hello"))
        assert isinstance(result, SQLLiteral)
        assert result.value == "hello"
        assert result.to_sql() == "'hello'"

    def test_string_empty(self, translator: ExpressionTranslator):
        """Test empty string literal."""
        result = translator.translate(Literal(value=""))
        assert isinstance(result, SQLLiteral)
        assert result.value == ""
        assert result.to_sql() == "''"

    def test_string_with_quotes(self, translator: ExpressionTranslator):
        """Test string with single quotes is escaped."""
        result = translator.translate(Literal(value="it's a test"))
        assert isinstance(result, SQLLiteral)
        assert result.to_sql() == "'it''s a test'"

    def test_boolean_true(self, translator: ExpressionTranslator):
        """Test boolean true literal translation: true -> TRUE."""
        result = translator.translate(Literal(value=True))
        assert isinstance(result, SQLLiteral)
        assert result.value is True
        assert result.to_sql() == "TRUE"

    def test_boolean_false(self, translator: ExpressionTranslator):
        """Test boolean false literal translation: false -> FALSE."""
        result = translator.translate(Literal(value=False))
        assert isinstance(result, SQLLiteral)
        assert result.value is False
        assert result.to_sql() == "FALSE"

    def test_null_literal(self, translator: ExpressionTranslator):
        """Test null literal translation: null -> NULL."""
        result = translator.translate(Literal(value=None))
        assert isinstance(result, SQLNull)
        assert result.to_sql() == "NULL"


class TestDateTimeLiterals:
    """Tests for DateTime literal translation."""

    @pytest.fixture
    def translator(self) -> ExpressionTranslator:
        """Create an ExpressionTranslator instance for testing."""
        context = SQLTranslationContext()
        return ExpressionTranslator(context)

    def test_date_only(self, translator: ExpressionTranslator):
        """Test date-only literal: @2026-01-15 -> '2026-01-15' (string for UDF compatibility)."""
        result = translator.translate(DateTimeLiteral(value="2026-01-15"))
        assert isinstance(result, SQLLiteral)
        # The value should have the @ prefix removed (if present)
        assert result.value == "2026-01-15"

    def test_datetime_no_timezone(self, translator: ExpressionTranslator):
        """Test datetime without timezone: @2026-01-15T10:30:00."""
        result = translator.translate(DateTimeLiteral(value="2026-01-15T10:30:00"))
        assert isinstance(result, SQLLiteral)
        # ISO 8601 T separator is preserved
        assert result.value == "2026-01-15T10:30:00"

    def test_datetime_with_at_prefix(self, translator: ExpressionTranslator):
        """Test datetime with @ prefix is handled."""
        result = translator.translate(DateTimeLiteral(value="@2026-01-15T10:30:00"))
        assert isinstance(result, SQLLiteral)
        # @ prefix should be removed, T separator preserved
        assert result.value == "2026-01-15T10:30:00"


class TestIdentifiers:
    """Tests for identifier translation."""

    @pytest.fixture
    def translator(self) -> ExpressionTranslator:
        """Create an ExpressionTranslator instance for testing."""
        context = SQLTranslationContext()
        return ExpressionTranslator(context)

    def test_simple_identifier(self, translator: ExpressionTranslator):
        """Test simple identifier lookup."""
        result = translator.translate(Identifier(name="SomeVar"))
        assert isinstance(result, SQLIdentifier)
        assert result.name == "SomeVar"

    def test_patient_identifier(self, translator: ExpressionTranslator):
        """Test Patient identifier references the folded _patients resource."""
        result = translator.translate(Identifier(name="Patient"))
        assert isinstance(result, SQLQualifiedIdentifier)
        assert result.parts == ["_pt", "patient_resource"]

    def test_qualified_identifier(self, translator: ExpressionTranslator):
        """Test qualified identifier: Library.name."""
        result = translator.translate(QualifiedIdentifier(parts=["Library", "name"]))
        assert isinstance(result, SQLQualifiedIdentifier)
        assert result.parts == ["Library", "name"]
        assert result.to_sql() == "Library.name"

    def test_qualified_identifier_three_parts(self, translator: ExpressionTranslator):
        """Test qualified identifier with three parts: FHIR.Patient.name."""
        result = translator.translate(QualifiedIdentifier(parts=["FHIR", "Patient", "name"]))
        assert isinstance(result, SQLQualifiedIdentifier)
        assert result.parts == ["FHIR", "Patient", "name"]
        assert result.to_sql() == "FHIR.Patient.name"


class TestPropertyAccess:
    """Tests for property access translation."""

    @pytest.fixture
    def translator(self) -> ExpressionTranslator:
        """Create an ExpressionTranslator instance for testing."""
        context = SQLTranslationContext()
        return ExpressionTranslator(context)

    def test_property_with_source(self, translator: ExpressionTranslator):
        """Test property access with source: Patient.name."""
        result = translator.translate(
            Property(source=Identifier(name="Patient"), path="name")
        )
        # Should use fhirpath function
        assert isinstance(result, SQLFunctionCall)
        assert result.name in ("fhirpath_text", "fhirpath_bool")
        # First arg should reference the source, second should be the path
        assert result.args[1].value == "name"

    def test_property_without_source(self, translator: ExpressionTranslator):
        """Test property access without explicit source uses context."""
        result = translator.translate(Property(source=None, path="name"))
        # Without a resource context, should return simple identifier
        assert isinstance(result, SQLIdentifier)
        assert result.name == "name"

    def test_property_observation_value(self, translator: ExpressionTranslator):
        """Test Observation.value property access."""
        result = translator.translate(
            Property(source=Identifier(name="Observation"), path="value")
        )
        assert isinstance(result, SQLFunctionCall)
        assert result.name in ("fhirpath_text", "fhirpath_bool", "COALESCE")

    def test_property_nested(self, translator: ExpressionTranslator):
        """Test nested property access."""
        result = translator.translate(
            Property(
                source=Property(source=Identifier(name="Patient"), path="name"),
                path="given",
            )
        )
        assert isinstance(result, SQLFunctionCall)


class TestArithmeticOperators:
    """Tests for arithmetic operator translation."""

    @pytest.fixture
    def translator(self) -> ExpressionTranslator:
        """Create an ExpressionTranslator instance for testing."""
        context = SQLTranslationContext()
        return ExpressionTranslator(context)

    def test_addition(self, translator: ExpressionTranslator):
        """Test addition: 5 + 3 -> 5 + 3."""
        result = translator.translate(
            BinaryExpression(operator="+", left=Literal(value=5), right=Literal(value=3))
        )
        assert isinstance(result, SQLBinaryOp)
        assert result.operator == "+"
        assert result.left.value == 5
        assert result.right.value == 3
        assert result.to_sql() == "5 + 3"

    def test_subtraction(self, translator: ExpressionTranslator):
        """Test subtraction: 10 - 4 -> 10 - 4."""
        result = translator.translate(
            BinaryExpression(operator="-", left=Literal(value=10), right=Literal(value=4))
        )
        assert isinstance(result, SQLBinaryOp)
        assert result.operator == "-"
        assert result.to_sql() == "10 - 4"

    def test_multiplication(self, translator: ExpressionTranslator):
        """Test multiplication: 6 * 7 -> 6 * 7."""
        result = translator.translate(
            BinaryExpression(operator="*", left=Literal(value=6), right=Literal(value=7))
        )
        assert isinstance(result, SQLBinaryOp)
        assert result.operator == "*"
        assert result.to_sql() == "6 * 7"

    def test_division(self, translator: ExpressionTranslator):
        """Test division: 15 / 3 lowers to exact Decimal cqlDivide.

        CQL §16.4 divide is Decimal division at implementation scale;
        DuckDB's native `/` promotes DECIMAL to DOUBLE (artifacts), so the
        translator emits the exact cqlDivide UDF.
        """
        result = translator.translate(
            BinaryExpression(operator="/", left=Literal(value=15), right=Literal(value=3))
        )
        assert isinstance(result, SQLFunctionCall)
        assert result.name == "cqlDivide"

    def test_integer_division_div(self, translator: ExpressionTranslator):
        """Test integer division: 17 div 5 -> exact cqlDivide + TRUNC.

        CQL-11 SKEPTIC: div must not lower through DuckDB's DOUBLE `/`
        (0.3 div 0.1 -> 2); it uses the exact cqlDivide core, truncated
        toward zero, narrowed with TRY_CAST for Integer/Long operands.
        """
        result = translator.translate(
            BinaryExpression(operator="div", left=Literal(value=17), right=Literal(value=5))
        )
        # Bare Integer/Long literals (no Decimal type info) narrow to INTEGER
        # via a TRY_CAST wrapper around TRUNC(cqlDivide(...)).
        if isinstance(result, SQLCast):
            assert result.try_cast is True and result.target_type == "INTEGER"
            result = result.expression
        assert isinstance(result, SQLFunctionCall)
        assert result.name == "TRUNC"
        core = result.args[0]
        assert isinstance(core, SQLFunctionCall)
        assert core.name == "cqlDivide"

    def test_modulo(self, translator: ExpressionTranslator):
        """Test modulo: 17 mod 5 -> 17 % 5 (via SQLBinaryOp)."""
        result = translator.translate(
            BinaryExpression(operator="mod", left=Literal(value=17), right=Literal(value=5))
        )
        # Note: mod is mapped to "%" in BINARY_OPERATOR_MAP but handled specially
        # The actual implementation may use SQLFunctionCall with MOD or SQLBinaryOp
        sql_str = result.to_sql()
        # Either "17 % 5" or "MOD(17, 5)" are acceptable
        assert "%" in sql_str or "MOD" in sql_str.upper() or "mod" in sql_str

    def test_power(self, translator: ExpressionTranslator):
        """Test power: 2 ^ 10 -> TRY_CAST(mathPower(2, 10) AS DOUBLE)."""
        result = translator.translate(
            BinaryExpression(operator="^", left=Literal(value=2), right=Literal(value=10))
        )
        assert isinstance(result, SQLCast)
        assert result.target_type == "DOUBLE"
        assert result.try_cast
        assert isinstance(result.expression, SQLFunctionCall)
        assert result.expression.name == "mathPower"
        assert isinstance(result.expression.args[0], SQLCast)
        assert isinstance(result.expression.args[1], SQLCast)
        assert result.expression.args[0].target_type == "VARCHAR"
        assert result.expression.args[1].target_type == "VARCHAR"
        assert result.expression.args[0].expression.value == 2
        assert result.expression.args[1].expression.value == 10


class TestComparisonOperators:
    """Tests for comparison operator translation."""

    @pytest.fixture
    def translator(self) -> ExpressionTranslator:
        """Create an ExpressionTranslator instance for testing."""
        context = SQLTranslationContext()
        return ExpressionTranslator(context)

    def test_equality(self, translator: ExpressionTranslator):
        """Test equality: 5 = 5 -> 5 = 5."""
        result = translator.translate(
            BinaryExpression(operator="=", left=Literal(value=5), right=Literal(value=5))
        )
        assert isinstance(result, SQLBinaryOp)
        assert result.operator == "="
        assert result.to_sql() == "5 = 5"

    def test_inequality_angle(self, translator: ExpressionTranslator):
        """Test inequality with <>: 5 <> 3 -> 5 != 3."""
        result = translator.translate(
            BinaryExpression(operator="<>", left=Literal(value=5), right=Literal(value=3))
        )
        assert isinstance(result, SQLBinaryOp)
        assert result.operator == "!="
        assert result.to_sql() == "5 != 3"

    def test_less_than(self, translator: ExpressionTranslator):
        """Test less than: 5 < 10 -> 5 < 10."""
        result = translator.translate(
            BinaryExpression(operator="<", left=Literal(value=5), right=Literal(value=10))
        )
        assert isinstance(result, SQLBinaryOp)
        assert result.operator == "<"
        assert result.to_sql() == "5 < 10"

    def test_less_than_or_equal(self, translator: ExpressionTranslator):
        """Test less than or equal: 5 <= 5 -> 5 <= 5."""
        result = translator.translate(
            BinaryExpression(operator="<=", left=Literal(value=5), right=Literal(value=5))
        )
        assert isinstance(result, SQLBinaryOp)
        assert result.operator == "<="
        assert result.to_sql() == "5 <= 5"

    def test_greater_than(self, translator: ExpressionTranslator):
        """Test greater than: 10 > 5 -> 10 > 5."""
        result = translator.translate(
            BinaryExpression(operator=">", left=Literal(value=10), right=Literal(value=5))
        )
        assert isinstance(result, SQLBinaryOp)
        assert result.operator == ">"
        assert result.to_sql() == "10 > 5"

    def test_greater_than_or_equal(self, translator: ExpressionTranslator):
        """Test greater than or equal: 10 >= 10 -> 10 >= 10."""
        result = translator.translate(
            BinaryExpression(operator=">=", left=Literal(value=10), right=Literal(value=10))
        )
        assert isinstance(result, SQLBinaryOp)
        assert result.operator == ">="
        assert result.to_sql() == "10 >= 10"


class TestLogicalOperators:
    """Tests for logical operator translation."""

    @pytest.fixture
    def translator(self) -> ExpressionTranslator:
        """Create an ExpressionTranslator instance for testing."""
        context = SQLTranslationContext()
        return ExpressionTranslator(context)

    def test_and(self, translator: ExpressionTranslator):
        """Test logical and: true and false -> TRUE AND FALSE."""
        result = translator.translate(
            BinaryExpression(
                operator="and", left=Literal(value=True), right=Literal(value=False)
            )
        )
        assert isinstance(result, SQLBinaryOp)
        assert result.operator == "AND"
        assert result.to_sql() == "TRUE AND FALSE"

    def test_or(self, translator: ExpressionTranslator):
        """Test logical or: true or false -> TRUE OR FALSE."""
        result = translator.translate(
            BinaryExpression(
                operator="or", left=Literal(value=True), right=Literal(value=False)
            )
        )
        assert isinstance(result, SQLBinaryOp)
        assert result.operator == "OR"
        assert result.to_sql() == "TRUE OR FALSE"

    def test_logical_operands_translate_once(self):
        """Logical operators should not pretranslate operands as scalars."""

        class CountingTranslator(ExpressionTranslator):
            def __init__(self, context):
                super().__init__(context)
                self.literal_translations = 0

            def _translate_literal(self, node, boolean_context=False):
                self.literal_translations += 1
                return super()._translate_literal(node, boolean_context)

        translator = CountingTranslator(SQLTranslationContext())
        result = translator.translate(
            BinaryExpression(
                operator="or",
                left=Literal(value=True),
                right=Literal(value=False),
            )
        )

        assert isinstance(result, SQLBinaryOp)
        assert translator.literal_translations == 2

    def test_not(self, translator: ExpressionTranslator):
        """Test logical not: not true -> NOT TRUE."""
        result = translator.translate(
            UnaryExpression(operator="not", operand=Literal(value=True))
        )
        assert isinstance(result, SQLUnaryOp)
        assert result.operator == "NOT"
        assert result.to_sql() == "NOT TRUE"


class TestIntervalConstruction:
    """Tests for interval expression translation."""

    @pytest.fixture
    def translator(self) -> ExpressionTranslator:
        """Create an ExpressionTranslator instance for testing."""
        context = SQLTranslationContext()
        return ExpressionTranslator(context)

    def test_closed_interval(self, translator: ExpressionTranslator):
        """Test closed interval: Interval[1, 10]."""
        result = translator.translate(
            Interval(
                low=Literal(value=1),
                high=Literal(value=10),
                low_closed=True,
                high_closed=True,
            )
        )
        assert isinstance(result, SQLInterval)
        assert result.low_closed is True
        assert result.high_closed is True
        sql = result.to_sql()
        assert "intervalFromBounds" in sql
        assert "1" in sql
        assert "10" in sql
        assert "TRUE" in sql

    def test_open_interval(self, translator: ExpressionTranslator):
        """Test open interval: Interval(1, 10)."""
        result = translator.translate(
            Interval(
                low=Literal(value=1),
                high=Literal(value=10),
                low_closed=False,
                high_closed=False,
            )
        )
        assert isinstance(result, SQLInterval)
        assert result.low_closed is False
        assert result.high_closed is False
        sql = result.to_sql()
        assert "intervalFromBounds" in sql
        assert "FALSE" in sql

    def test_half_open_left_closed(self, translator: ExpressionTranslator):
        """Test half-open interval: Interval[1, 10)."""
        result = translator.translate(
            Interval(
                low=Literal(value=1),
                high=Literal(value=10),
                low_closed=True,
                high_closed=False,
            )
        )
        assert isinstance(result, SQLInterval)
        assert result.low_closed is True
        assert result.high_closed is False

    def test_half_open_right_closed(self, translator: ExpressionTranslator):
        """Test half-open interval: Interval(1, 10]."""
        result = translator.translate(
            Interval(
                low=Literal(value=1),
                high=Literal(value=10),
                low_closed=False,
                high_closed=True,
            )
        )
        assert isinstance(result, SQLInterval)
        assert result.low_closed is False
        assert result.high_closed is True


class TestConditionalExpressions:
    """Tests for conditional (if-then-else) expression translation."""

    @pytest.fixture
    def translator(self) -> ExpressionTranslator:
        """Create an ExpressionTranslator instance for testing."""
        context = SQLTranslationContext()
        return ExpressionTranslator(context)

    def test_simple_conditional(self, translator: ExpressionTranslator):
        """Test simple conditional: if true then 1 else 0."""
        result = translator.translate(
            ConditionalExpression(
                condition=Literal(value=True),
                then_expr=Literal(value=1),
                else_expr=Literal(value=0),
            )
        )
        assert isinstance(result, SQLCase)
        assert len(result.when_clauses) == 1
        condition, then_val = result.when_clauses[0]
        assert condition.to_sql() == "TRUE"
        assert then_val.to_sql() == "1"
        assert result.else_clause.to_sql() == "0"
        sql = result.to_sql()
        assert "CASE" in sql
        assert "WHEN" in sql
        assert "THEN" in sql
        assert "ELSE" in sql
        assert "END" in sql

    def test_conditional_with_comparison(self, translator: ExpressionTranslator):
        """Test conditional with comparison condition."""
        result = translator.translate(
            ConditionalExpression(
                condition=BinaryExpression(
                    operator=">", left=Literal(value=5), right=Literal(value=3)
                ),
                then_expr=Literal(value="yes"),
                else_expr=Literal(value="no"),
            )
        )
        assert isinstance(result, SQLCase)
        sql = result.to_sql()
        assert "CASE" in sql
        assert "5 > 3" in sql
        assert "'yes'" in sql
        assert "'no'" in sql


class TestOperatorMaps:
    """Tests for operator mapping constants."""

    def test_binary_operator_map_contains_arithmetic(self):
        """Test that BINARY_OPERATOR_MAP contains arithmetic operators."""
        assert "+" in BINARY_OPERATOR_MAP
        assert "-" in BINARY_OPERATOR_MAP
        assert "*" in BINARY_OPERATOR_MAP
        assert "/" in BINARY_OPERATOR_MAP
        assert "div" in BINARY_OPERATOR_MAP
        assert "mod" in BINARY_OPERATOR_MAP
        assert "^" in BINARY_OPERATOR_MAP

    def test_binary_operator_map_contains_comparison(self):
        """Test that BINARY_OPERATOR_MAP contains comparison operators."""
        assert "=" in BINARY_OPERATOR_MAP
        assert "<>" in BINARY_OPERATOR_MAP
        assert "<" in BINARY_OPERATOR_MAP
        assert "<=" in BINARY_OPERATOR_MAP
        assert ">" in BINARY_OPERATOR_MAP
        assert ">=" in BINARY_OPERATOR_MAP

    def test_binary_operator_map_contains_logical(self):
        """Test that BINARY_OPERATOR_MAP contains logical operators."""
        assert "and" in BINARY_OPERATOR_MAP
        assert "or" in BINARY_OPERATOR_MAP
        assert "xor" in BINARY_OPERATOR_MAP

    def test_unary_operator_map_contains_not(self):
        """Test that UNARY_OPERATOR_MAP contains 'not'."""
        assert "not" in UNARY_OPERATOR_MAP
        assert UNARY_OPERATOR_MAP["not"] == "NOT"

    def test_unary_operator_map_contains_null_checks(self):
        """Test that UNARY_OPERATOR_MAP contains null checks."""
        assert "is null" in UNARY_OPERATOR_MAP
        assert "is not null" in UNARY_OPERATOR_MAP


class TestClinicalFunctions:
    """Tests for clinical function translation."""

    @pytest.fixture
    def translator(self) -> ExpressionTranslator:
        """Create an ExpressionTranslator instance for testing."""
        context = SQLTranslationContext()
        return ExpressionTranslator(context)

    def test_latest_function(self, translator: ExpressionTranslator):
        """Test Latest function: Latest(values, date_path)."""
        from ...parser.ast_nodes import FunctionRef
        result = translator.translate(
            FunctionRef(
                name="Latest",
                arguments=[
                    Identifier(name="Observations"),
                    Literal(value="effectiveDateTime"),
                ]
            )
        )
        assert isinstance(result, SQLFunctionCall)
        assert result.name == "Latest"
        assert len(result.args) == 2

    def test_earliest_function(self, translator: ExpressionTranslator):
        """Test Earliest function: Earliest(values, date_path)."""
        from ...parser.ast_nodes import FunctionRef
        result = translator.translate(
            FunctionRef(
                name="Earliest",
                arguments=[
                    Identifier(name="Observations"),
                    Literal(value="effectiveDateTime"),
                ]
            )
        )
        assert isinstance(result, SQLFunctionCall)
        assert result.name == "Earliest"
        assert len(result.args) == 2


class TestDateTimeDifferenceFunctions:
    """Tests for datetime difference function translation."""

    @pytest.fixture
    def translator(self) -> ExpressionTranslator:
        """Create an ExpressionTranslator instance for testing."""
        context = SQLTranslationContext()
        return ExpressionTranslator(context)

    def test_weeks_between(self, translator: ExpressionTranslator):
        """Test weeksBetween function: weeksBetween(start, end)."""
        from ...parser.ast_nodes import FunctionRef
        result = translator.translate(
            FunctionRef(
                name="weeksBetween",
                arguments=[
                    Literal(value="2024-01-01"),
                    Literal(value="2024-01-29"),
                ]
            )
        )
        assert isinstance(result, SQLFunctionCall)
        # EXP1-005: emits the registered CQL duration UDF (whole-period
        # semantics, binds on VARCHAR operands) — the old date_diff emission
        # binder-failed at execution.
        assert result.name == "weeksBetween"
        import duckdb as _duckdb
        from ...duckdb import register as _reg

        _con = _duckdb.connect()
        _reg(_con)
        got = _con.execute(f"SELECT ({result.to_sql()})::VARCHAR").fetchone()[0]
        assert got == "4"

    def test_milliseconds_between(self, translator: ExpressionTranslator):
        """Test millisecondsBetween function: millisecondsBetween(start, end)."""
        from ...parser.ast_nodes import FunctionRef
        result = translator.translate(
            FunctionRef(
                name="millisecondsBetween",
                arguments=[
                    Literal(value="2024-01-01T00:00:00"),
                    Literal(value="2024-01-01T00:00:01"),
                ]
            )
        )
        assert isinstance(result, SQLFunctionCall)
        # EXP1-005: registered CQL duration UDF (see test_weeks_between).
        assert result.name == "millisecondsBetween"
        import duckdb as _duckdb
        from ...duckdb import register as _reg

        _con = _duckdb.connect()
        _reg(_con)
        got = _con.execute(f"SELECT ({result.to_sql()})::VARCHAR").fetchone()[0]
        assert got == "1000"


class TestAgeAtFunctions:
    """Tests for AgeAt function translation."""

    @pytest.fixture
    def translator(self) -> ExpressionTranslator:
        """Create an ExpressionTranslator instance for testing."""
        context = SQLTranslationContext()
        return ExpressionTranslator(context)

    def test_age_in_years_at(self, translator: ExpressionTranslator):
        """Test AgeInYearsAt function: AgeInYearsAt(patient, as_of)."""
        from ...parser.ast_nodes import FunctionRef
        result = translator.translate(
            FunctionRef(
                name="AgeInYearsAt",
                arguments=[
                    Identifier(name="Patient"),
                    Literal(value="2024-06-15"),
                ]
            )
        )
        assert isinstance(result, SQLFunctionCall)
        assert result.name == "AgeInYearsAt"
        assert len(result.args) == 2

    def test_age_in_months_at(self, translator: ExpressionTranslator):
        """Test AgeInMonthsAt function: AgeInMonthsAt(patient, as_of)."""
        from ...parser.ast_nodes import FunctionRef
        result = translator.translate(
            FunctionRef(
                name="AgeInMonthsAt",
                arguments=[
                    Identifier(name="Patient"),
                    Literal(value="2024-06-15"),
                ]
            )
        )
        assert isinstance(result, SQLFunctionCall)
        assert result.name == "AgeInMonthsAt"
        assert len(result.args) == 2

    def test_age_in_days_at(self, translator: ExpressionTranslator):
        """Test AgeInDaysAt function: AgeInDaysAt(patient, as_of)."""
        from ...parser.ast_nodes import FunctionRef
        result = translator.translate(
            FunctionRef(
                name="AgeInDaysAt",
                arguments=[
                    Identifier(name="Patient"),
                    Literal(value="2024-06-15"),
                ]
            )
        )
        assert isinstance(result, SQLFunctionCall)
        assert result.name == "AgeInDaysAt"
        assert len(result.args) == 2

    def test_age_in_years_at_single_arg(self, translator: ExpressionTranslator):
        """Test AgeInYearsAt with single arg routes through demographics helper."""
        from ...parser.ast_nodes import FunctionRef
        result = translator.translate(
            FunctionRef(
                name="AgeInYearsAt",
                arguments=[
                    Literal(value="2024-06-15"),
                ]
            )
        )
        assert isinstance(result, SQLFunctionCall)
        assert result.name == "CalculateAgeInYearsAt"
        assert len(result.args) == 2
        assert translator.context._needs_demographics is True

    def test_age_in_years_at_population_context(self):
        """Test AgeInYearsAt in population context uses patient demographics."""
        from ...parser.ast_nodes import FunctionRef
        # Create context with patient_alias set (population context)
        context = SQLTranslationContext()
        context.patient_alias = "_pt"  # Simulate "FROM patients p" context
        translator = ExpressionTranslator(context)

        result = translator.translate(
            FunctionRef(
                name="AgeInYearsAt",
                arguments=[
                    Literal(value="2024-06-15"),
                ]
            )
        )
        assert isinstance(result, SQLFunctionCall)
        assert result.name == "CalculateAgeInYearsAt"
        sql = result.to_sql()
        assert "_patient_demographics" not in sql
        assert "_pt.birth_date" in sql


class TestIntervalOperations:
    """Tests for interval operation translation (start of, end of, width of)."""

    @pytest.fixture
    def translator(self) -> ExpressionTranslator:
        """Create an ExpressionTranslator instance for testing."""
        context = SQLTranslationContext()
        return ExpressionTranslator(context)

    def test_interval_start(self, translator: ExpressionTranslator):
        """Test start of interval: start of Interval[1, 10]."""
        result = translator.translate(
            UnaryExpression(
                operator="start of",
                operand=Interval(
                    low=Literal(value=1),
                    high=Literal(value=10),
                    low_closed=True,
                    high_closed=True,
                ),
            )
        )
        assert isinstance(result, SQLFunctionCall)
        assert result.name == "intervalStart"
        assert len(result.args) == 1

    def test_interval_end(self, translator: ExpressionTranslator):
        """Test end of interval: end of Interval[1, 10]."""
        result = translator.translate(
            UnaryExpression(
                operator="end of",
                operand=Interval(
                    low=Literal(value=1),
                    high=Literal(value=10),
                    low_closed=True,
                    high_closed=True,
                ),
            )
        )
        assert isinstance(result, SQLFunctionCall)
        assert result.name == "intervalEnd"
        assert len(result.args) == 1

    def test_interval_width(self, translator: ExpressionTranslator):
        """Test width of interval: width of Interval[1, 10]."""
        result = translator.translate(
            UnaryExpression(
                operator="width of",
                operand=Interval(
                    low=Literal(value=1),
                    high=Literal(value=10),
                    low_closed=True,
                    high_closed=True,
                ),
            )
        )
        assert isinstance(result, SQLFunctionCall)
        assert result.name == "intervalWidth"
        assert len(result.args) == 1

    def test_interval_width_with_date_interval(self, translator: ExpressionTranslator):
        """Test width of date interval: width of Interval[@2024-01-01, @2024-01-31]."""
        result = translator.translate(
            UnaryExpression(
                operator="width of",
                operand=Interval(
                    low=DateTimeLiteral(value="2024-01-01"),
                    high=DateTimeLiteral(value="2024-01-31"),
                    low_closed=True,
                    high_closed=True,
                ),
            )
        )
        assert isinstance(result, SQLFunctionCall)
        assert result.name == "intervalWidth"
        assert len(result.args) == 1


class TestDateComponent:
    """Tests for date component extraction translation."""

    @pytest.fixture
    def translator(self) -> ExpressionTranslator:
        """Create an ExpressionTranslator instance for testing."""
        context = SQLTranslationContext()
        return ExpressionTranslator(context)

    def test_date_component_year(self, translator: ExpressionTranslator):
        """Test year extraction routes through the spec-aware component UDF."""
        from ...parser.ast_nodes import DateComponent
        result = translator.translate(
            DateComponent(component="year", operand=DateTimeLiteral(value="2024-01-15"))
        )
        assert isinstance(result, SQLFunctionCall)
        assert result.name == "dateComponent"
        assert len(result.args) == 2
        assert result.args[1] == SQLLiteral("year")

    def test_date_component_month(self, translator: ExpressionTranslator):
        """Test month extraction routes through the spec-aware component UDF."""
        from ...parser.ast_nodes import DateComponent
        result = translator.translate(
            DateComponent(component="month", operand=DateTimeLiteral(value="2024-06-15"))
        )
        assert isinstance(result, SQLFunctionCall)
        assert result.name == "dateComponent"
        assert len(result.args) == 2
        assert result.args[1] == SQLLiteral("month")

    def test_date_component_millisecond(self, translator: ExpressionTranslator):
        """Test millisecond extraction routes through the spec-aware component UDF."""
        from ...parser.ast_nodes import DateComponent, TimeLiteral
        result = translator.translate(
            DateComponent(component="millisecond", operand=TimeLiteral(value="T12:30:45.123"))
        )
        assert isinstance(result, SQLFunctionCall)
        assert result.name == "dateComponent"
        assert len(result.args) == 2
        assert result.args[1] == SQLLiteral("millisecond")


class TestExistsExpression:
    """Tests for exists expression translation."""

    @pytest.fixture
    def translator(self) -> ExpressionTranslator:
        """Create an ExpressionTranslator instance for testing."""
        context = SQLTranslationContext()
        return ExpressionTranslator(context)

    def test_exists_expression(self, translator: ExpressionTranslator):
        """Test exists expression: exists [Condition: "Diabetes"] -> array_length(...) > 0."""
        from ...parser.ast_nodes import ExistsExpression, ListExpression
        result = translator.translate(
            ExistsExpression(source=ListExpression(elements=[Literal(value=1), Literal(value=2)]))
        )
        assert isinstance(result, SQLBinaryOp)
        assert result.operator == ">"
        assert isinstance(result.left, SQLFunctionCall)
        assert result.left.name == "list_count"
        assert result.right.value == 0


class TestAggregateExpression:
    """Tests for aggregate expression translation."""

    @pytest.fixture
    def translator(self) -> ExpressionTranslator:
        """Create an ExpressionTranslator instance for testing."""
        context = SQLTranslationContext()
        return ExpressionTranslator(context)

    def test_aggregate_sum(self, translator: ExpressionTranslator):
        """Test sum aggregate: Sum([1, 2, 3]) -> list_sum(...)."""
        from ...parser.ast_nodes import AggregateExpression, ListExpression
        result = translator.translate(
            AggregateExpression(
                source=ListExpression(elements=[Literal(value=1), Literal(value=2), Literal(value=3)]),
                operator="Sum"
            )
        )
        assert isinstance(result, SQLFunctionCall)
        assert result.name == "list_sum"
        assert len(result.args) == 1

    def test_aggregate_count(self, translator: ExpressionTranslator):
        """Test count aggregate: Count([1, 2, 3]) -> COUNT(...)."""
        from ...parser.ast_nodes import AggregateExpression, ListExpression
        result = translator.translate(
            AggregateExpression(
                source=ListExpression(elements=[Literal(value=1), Literal(value=2), Literal(value=3)]),
                operator="Count"
            )
        )
        assert isinstance(result, SQLFunctionCall)
        assert result.name == "COUNT"
        assert len(result.args) == 1


class TestDurationBetween:
    """Tests for DurationBetween AST node translation."""

    @pytest.fixture
    def translator(self) -> ExpressionTranslator:
        """Create an ExpressionTranslator instance for testing."""
        context = SQLTranslationContext()
        return ExpressionTranslator(context)

    def test_duration_between_years(self, translator: ExpressionTranslator):
        """Test years between: years between @2020-01-01 and @2024-01-01 -> YearsBetween(...)."""
        result = translator.translate(
            DurationBetween(
                precision="year",
                operand_left=DateTimeLiteral(value="2020-01-01"),
                operand_right=DateTimeLiteral(value="2024-01-01"),
            )
        )
        assert isinstance(result, SQLFunctionCall)
        assert result.name == "cqlDurationBetween"
        assert len(result.args) == 3

    def test_duration_between_months(self, translator: ExpressionTranslator):
        """Test months between: months between A and B -> MonthsBetween(...)."""
        result = translator.translate(
            DurationBetween(
                precision="month",
                operand_left=DateTimeLiteral(value="2024-01-01"),
                operand_right=DateTimeLiteral(value="2024-06-15"),
            )
        )
        assert isinstance(result, SQLFunctionCall)
        assert result.name == "cqlDurationBetween"
        assert len(result.args) == 3

    def test_duration_between_days(self, translator: ExpressionTranslator):
        """Test days between: days between A and B -> DaysBetween(...)."""
        result = translator.translate(
            DurationBetween(
                precision="day",
                operand_left=DateTimeLiteral(value="2024-01-01"),
                operand_right=DateTimeLiteral(value="2024-01-31"),
            )
        )
        assert isinstance(result, SQLFunctionCall)
        assert result.name == "cqlDurationBetween"
        assert len(result.args) == 3

    def test_duration_between_weeks(self, translator: ExpressionTranslator):
        """Test weeks between: weeks between A and B -> weeksBetween(...)."""
        result = translator.translate(
            DurationBetween(
                precision="week",
                operand_left=DateTimeLiteral(value="2024-01-01"),
                operand_right=DateTimeLiteral(value="2024-01-29"),
            )
        )
        assert isinstance(result, SQLFunctionCall)
        assert result.name == "cqlDurationBetween"
        assert len(result.args) == 3

    def test_duration_between_hours(self, translator: ExpressionTranslator):
        """Test hours between: hours between A and B -> HoursBetween(...)."""
        result = translator.translate(
            DurationBetween(
                precision="hour",
                operand_left=DateTimeLiteral(value="2024-01-01T00:00:00"),
                operand_right=DateTimeLiteral(value="2024-01-01T12:00:00"),
            )
        )
        assert isinstance(result, SQLFunctionCall)
        assert result.name == "cqlDurationBetween"
        assert len(result.args) == 3


class TestDifferenceBetween:
    """Tests for DifferenceBetween AST node translation."""

    @pytest.fixture
    def translator(self) -> ExpressionTranslator:
        """Create an ExpressionTranslator instance for testing."""
        context = SQLTranslationContext()
        return ExpressionTranslator(context)

    def test_difference_between_years(self, translator: ExpressionTranslator):
        """Test difference in years lowers to the uncertainty-aware public helper."""
        result = translator.translate(
            DifferenceBetween(
                precision="year",
                operand_left=DateTimeLiteral(value="2020-12-31"),
                operand_right=DateTimeLiteral(value="2024-01-01"),
            )
        )
        assert isinstance(result, SQLFunctionCall)
        assert result.name == "cqlDifferenceBetween"
        assert len(result.args) == 3

    def test_difference_between_months(self, translator: ExpressionTranslator):
        """Test difference in months lowers to the uncertainty-aware public helper."""
        result = translator.translate(
            DifferenceBetween(
                precision="month",
                operand_left=DateTimeLiteral(value="2024-01-15"),
                operand_right=DateTimeLiteral(value="2024-06-15"),
            )
        )
        assert isinstance(result, SQLFunctionCall)
        assert result.name == "cqlDifferenceBetween"
        assert len(result.args) == 3

    def test_difference_between_days(self, translator: ExpressionTranslator):
        """Test difference in days lowers to the uncertainty-aware public helper."""
        result = translator.translate(
            DifferenceBetween(
                precision="day",
                operand_left=DateTimeLiteral(value="2024-01-01"),
                operand_right=DateTimeLiteral(value="2024-01-31"),
            )
        )
        assert isinstance(result, SQLFunctionCall)
        assert result.name == "cqlDifferenceBetween"
        assert len(result.args) == 3

    def test_difference_between_unknown_precision(self, translator: ExpressionTranslator):
        """Test unknown precision is passed to the public helper."""
        result = translator.translate(
            DifferenceBetween(
                precision="unknown",
                operand_left=DateTimeLiteral(value="2024-01-01"),
                operand_right=DateTimeLiteral(value="2024-01-31"),
            )
        )
        assert isinstance(result, SQLFunctionCall)
        assert result.name == "cqlDifferenceBetween"
        assert len(result.args) == 3


class TestTypeConversion:
    """Tests for type conversion function translation."""

    @pytest.fixture
    def translator(self) -> ExpressionTranslator:
        """Create an ExpressionTranslator instance for testing."""
        context = SQLTranslationContext()
        return ExpressionTranslator(context)

    def test_to_decimal(self, translator: ExpressionTranslator):
        """Test ToDecimal function: ToDecimal('3.14') -> ToDecimal('3.14')."""
        from ...parser.ast_nodes import FunctionRef
        result = translator.translate(
            FunctionRef(name="ToDecimal", arguments=[Literal(value="3.14")])
        )
        assert isinstance(result, SQLFunctionCall)
        assert result.name == "ToDecimal"
        sql = result.to_sql()
        assert "ToDecimal" in sql

    def test_to_decimal_from_integer(self, translator: ExpressionTranslator):
        """Test ToDecimal from integer: ToDecimal(42) -> ToDecimal(42)."""
        from ...parser.ast_nodes import FunctionRef
        result = translator.translate(
            FunctionRef(name="ToDecimal", arguments=[Literal(value=42)])
        )
        assert isinstance(result, SQLFunctionCall)
        assert result.name == "ToDecimal"

    def test_to_integer(self, translator: ExpressionTranslator):
        """Test ToInteger function: ToInteger('42') -> ToInteger('42')."""
        from ...parser.ast_nodes import FunctionRef
        result = translator.translate(
            FunctionRef(name="ToInteger", arguments=[Literal(value="42")])
        )
        assert isinstance(result, SQLFunctionCall)
        assert result.name == "ToInteger"
        sql = result.to_sql()
        assert "ToInteger" in sql

    def test_to_integer_from_decimal(self, translator: ExpressionTranslator):
        """Test ToInteger from decimal: ToInteger(3.14) -> ToInteger(3.14)."""
        from ...parser.ast_nodes import FunctionRef
        result = translator.translate(
            FunctionRef(name="ToInteger", arguments=[Literal(value=3.14)])
        )
        assert isinstance(result, SQLFunctionCall)
        assert result.name == "ToInteger"

    def test_to_string(self, translator: ExpressionTranslator):
        """Test ToString function routes through the spec-aware public macro."""
        from ...parser.ast_nodes import FunctionRef
        from ...translator.types import SQLFunctionCall
        result = translator.translate(
            FunctionRef(name="ToString", arguments=[Literal(value=42)])
        )
        assert isinstance(result, SQLFunctionCall)
        assert result.name == "ToString"
        sql = result.to_sql()
        assert "ToString" in sql

    def test_to_string_from_boolean(self, translator: ExpressionTranslator):
        """Test ToString from boolean routes through the public macro."""
        from ...parser.ast_nodes import FunctionRef
        from ...translator.types import SQLFunctionCall
        result = translator.translate(
            FunctionRef(name="ToString", arguments=[Literal(value=True)])
        )
        assert isinstance(result, SQLFunctionCall)
        assert result.name == "ToString"

    def test_to_boolean(self, translator: ExpressionTranslator):
        """Test ToBoolean function: ToBoolean('true') -> ToBoolean('true')."""
        from ...parser.ast_nodes import FunctionRef
        result = translator.translate(
            FunctionRef(name="ToBoolean", arguments=[Literal(value="true")])
        )
        assert isinstance(result, SQLFunctionCall)
        assert result.name == "ToBoolean"
        sql = result.to_sql()
        assert "ToBoolean" in sql

    def test_to_boolean_from_integer(self, translator: ExpressionTranslator):
        """Test ToBoolean from integer: ToBoolean(1) -> ToBoolean(1)."""
        from ...parser.ast_nodes import FunctionRef
        result = translator.translate(
            FunctionRef(name="ToBoolean", arguments=[Literal(value=1)])
        )
        assert isinstance(result, SQLFunctionCall)
        assert result.name == "ToBoolean"

    def test_to_datetime(self, translator: ExpressionTranslator):
        """Test ToDateTime function routes to spec-aware macro."""
        from ...parser.ast_nodes import FunctionRef
        result = translator.translate(
            FunctionRef(name="ToDateTime", arguments=[Literal(value="2024-01-15")])
        )
        assert isinstance(result, SQLFunctionCall)
        assert result.name == "ToDateTime"

    def test_to_datetime_from_string(self, translator: ExpressionTranslator):
        """Test ToDateTime with time routes to spec-aware macro."""
        from ...parser.ast_nodes import FunctionRef
        result = translator.translate(
            FunctionRef(name="ToDateTime", arguments=[Literal(value="2024-01-15T10:30:00")])
        )
        assert isinstance(result, SQLFunctionCall)
        assert result.name == "ToDateTime"

    def test_to_date(self, translator: ExpressionTranslator):
        """Test ToDate function routes to spec-aware macro."""
        from ...parser.ast_nodes import FunctionRef
        result = translator.translate(
            FunctionRef(name="ToDate", arguments=[Literal(value="2024-01-15")])
        )
        assert isinstance(result, SQLFunctionCall)
        assert result.name == "ToDate"

    def test_to_date_from_datetime(self, translator: ExpressionTranslator):
        """Test ToDate from datetime string routes to spec-aware macro."""
        from ...parser.ast_nodes import FunctionRef
        result = translator.translate(
            FunctionRef(name="ToDate", arguments=[Literal(value="2024-01-15T10:30:00")])
        )
        assert isinstance(result, SQLFunctionCall)
        assert result.name == "ToDate"

    def test_to_time(self, translator: ExpressionTranslator):
        """Test ToTime function: ToTime('10:30:00') -> ToTime(...)."""
        from ...parser.ast_nodes import FunctionRef
        result = translator.translate(
            FunctionRef(name="ToTime", arguments=[Literal(value="10:30:00")])
        )
        assert isinstance(result, SQLFunctionCall)
        assert result.name == "ToTime"

    def test_to_time_with_milliseconds(self, translator: ExpressionTranslator):
        """Test ToTime with milliseconds: ToTime('10:30:00.123') -> ToTime(...)."""
        from ...parser.ast_nodes import FunctionRef
        result = translator.translate(
            FunctionRef(name="ToTime", arguments=[Literal(value="10:30:00.123")])
        )
        assert isinstance(result, SQLFunctionCall)
        assert result.name == "ToTime"

    def test_type_conversion_with_identifier(self, translator: ExpressionTranslator):
        """Test type conversion with identifier: ToInteger(someVar) -> ToInteger(someVar)."""
        from ...parser.ast_nodes import FunctionRef
        result = translator.translate(
            FunctionRef(name="ToInteger", arguments=[Identifier(name="someVar")])
        )
        assert isinstance(result, SQLFunctionCall)
        assert result.name == "ToInteger"
        sql = result.to_sql()
        assert "someVar" in sql

    def test_type_conversion_case_insensitive(self, translator: ExpressionTranslator):
        """Test type conversion is case-insensitive: todecimal, ToDecimal, TODECIMAL all work."""
        from ...parser.ast_nodes import FunctionRef

        # Test various casings
        for name in ["todecimal", "ToDecimal", "TODECIMAL", "toDecimal"]:
            result = translator.translate(
                FunctionRef(name=name, arguments=[Literal(value="3.14")])
            )
            assert isinstance(result, SQLFunctionCall), f"Failed for name: {name}"
            assert result.name == "ToDecimal", f"Failed for name: {name}"


class TestQueryOperators:
    """Tests for query operator translation (skip, take, first, last, any, all)."""

    @pytest.fixture
    def translator(self) -> ExpressionTranslator:
        """Create an ExpressionTranslator instance for testing."""
        context = SQLTranslationContext()
        return ExpressionTranslator(context)

    def test_skip_expression(self, translator: ExpressionTranslator):
        """Test skip expression: route through CQL Skip macro semantics."""
        from ...parser.ast_nodes import ListExpression
        result = translator.translate(
            SkipExpression(
                source=ListExpression(elements=[Literal(value=1), Literal(value=2), Literal(value=3), Literal(value=4)]),
                count=Literal(value=2)
            )
        )
        assert isinstance(result, SQLFunctionCall)
        assert result.name == "Skip"
        assert len(result.args) == 2
        sql = result.to_sql()
        assert "Skip" in sql

    def test_take_expression(self, translator: ExpressionTranslator):
        """Test take expression: route through CQL Take macro semantics."""
        from ...parser.ast_nodes import ListExpression
        result = translator.translate(
            TakeExpression(
                source=ListExpression(elements=[Literal(value=1), Literal(value=2), Literal(value=3), Literal(value=4)]),
                count=Literal(value=2)
            )
        )
        assert isinstance(result, SQLFunctionCall)
        assert result.name == "Take"
        assert len(result.args) == 2
        sql = result.to_sql()
        assert "Take" in sql

    def test_first_expression(self, translator: ExpressionTranslator):
        """Test first expression: first element -> list_extract(arr, 1)."""
        from ...parser.ast_nodes import ListExpression
        result = translator.translate(
            FirstExpression(
                source=ListExpression(elements=[Literal(value=1), Literal(value=2), Literal(value=3)])
            )
        )
        assert isinstance(result, SQLFunctionCall)
        assert result.name == "LIST_EXTRACT"
        assert len(result.args) == 2
        assert result.args[1].value == 1

    def test_last_expression(self, translator: ExpressionTranslator):
        """Test last expression: last element -> list_extract(arr, -1)."""
        from ...parser.ast_nodes import ListExpression
        result = translator.translate(
            LastExpression(
                source=ListExpression(elements=[Literal(value=1), Literal(value=2), Literal(value=3)])
            )
        )
        assert isinstance(result, SQLFunctionCall)
        assert result.name == "LIST_EXTRACT"
        assert len(result.args) == 2
        assert result.args[1].value == -1

    def test_any_expression(self, translator: ExpressionTranslator):
        """Test any expression: any X where condition -> list_any(arr, alias, condition)."""
        from ...parser.ast_nodes import ListExpression
        result = translator.translate(
            AnyExpression(
                source=ListExpression(elements=[Literal(value=1), Literal(value=2), Literal(value=3)]),
                alias="X",
                condition=BinaryExpression(operator=">", left=Identifier(name="X"), right=Literal(value=1))
            )
        )
        assert isinstance(result, SQLFunctionCall)
        assert result.name == "LIST_ANY"
        assert len(result.args) == 3
        assert result.args[1].value == "X"

    def test_all_expression(self, translator: ExpressionTranslator):
        """Test all expression: all X where condition -> list_all(arr, alias, condition)."""
        from ...parser.ast_nodes import ListExpression
        result = translator.translate(
            AllExpression(
                source=ListExpression(elements=[Literal(value=1), Literal(value=2), Literal(value=3)]),
                alias="X",
                condition=BinaryExpression(operator=">", left=Identifier(name="X"), right=Literal(value=0))
            )
        )
        assert isinstance(result, SQLFunctionCall)
        assert result.name == "LIST_ALL"
        assert len(result.args) == 3
        assert result.args[1].value == "X"


class TestPredecessorSuccessor:
    """Tests for predecessor/successor ordinal operator translation."""

    @pytest.fixture
    def translator(self) -> ExpressionTranslator:
        """Create an ExpressionTranslator instance for testing."""
        context = SQLTranslationContext()
        return ExpressionTranslator(context)

    def test_predecessor_of_integer(self, translator: ExpressionTranslator):
        """Test predecessor of integer: predecessor of 5 -> predecessorOf(5)."""
        result = translator.translate(
            UnaryExpression(
                operator="predecessor of",
                operand=Literal(value=5),
            )
        )
        assert isinstance(result, SQLFunctionCall)
        assert result.name == "predecessorOf"
        assert len(result.args) == 1
        assert result.args[0].value == 5

    def test_successor_of_integer(self, translator: ExpressionTranslator):
        """Test successor of integer: successor of 5 -> successorOf(5)."""
        result = translator.translate(
            UnaryExpression(
                operator="successor of",
                operand=Literal(value=5),
            )
        )
        assert isinstance(result, SQLFunctionCall)
        assert result.name == "successorOf"
        assert len(result.args) == 1
        assert result.args[0].value == 5

    def test_predecessor_of_zero(self, translator: ExpressionTranslator):
        """Test predecessor of zero: predecessor of 0 -> predecessorOf(0)."""
        result = translator.translate(
            UnaryExpression(
                operator="predecessor of",
                operand=Literal(value=0),
            )
        )
        assert isinstance(result, SQLFunctionCall)
        assert result.name == "predecessorOf"
        assert len(result.args) == 1
        assert result.args[0].value == 0

    def test_successor_of_negative(self, translator: ExpressionTranslator):
        """Test successor of negative: successor of -1 -> successorOf(-1)."""
        result = translator.translate(
            UnaryExpression(
                operator="successor of",
                operand=Literal(value=-1),
            )
        )
        assert isinstance(result, SQLFunctionCall)
        assert result.name == "successorOf"
        assert len(result.args) == 1
        assert result.args[0].value == -1

    def test_predecessor_of_identifier(self, translator: ExpressionTranslator):
        """Test predecessor of identifier: predecessor of X -> predecessorOf(X)."""
        result = translator.translate(
            UnaryExpression(
                operator="predecessor of",
                operand=Identifier(name="X"),
            )
        )
        assert isinstance(result, SQLFunctionCall)
        assert result.name == "predecessorOf"
        assert len(result.args) == 1
        assert isinstance(result.args[0], SQLIdentifier)
        assert result.args[0].name == "X"

    def test_successor_of_identifier(self, translator: ExpressionTranslator):
        """Test successor of identifier: successor of X -> successorOf(X)."""
        result = translator.translate(
            UnaryExpression(
                operator="successor of",
                operand=Identifier(name="X"),
            )
        )
        assert isinstance(result, SQLFunctionCall)
        assert result.name == "successorOf"
        assert len(result.args) == 1
        assert isinstance(result.args[0], SQLIdentifier)
        assert result.args[0].name == "X"


class TestStatisticalFunctions:
    """Tests for statistical function translation."""

    @pytest.fixture
    def translator(self) -> ExpressionTranslator:
        """Create an ExpressionTranslator instance for testing."""
        context = SQLTranslationContext()
        return ExpressionTranslator(context)

    def test_median_function(self, translator: ExpressionTranslator):
        """Test Median function: Median(values) -> MEDIAN(...)."""
        from ...parser.ast_nodes import FunctionRef, ListExpression
        result = translator.translate(
            FunctionRef(
                name="Median",
                arguments=[
                    ListExpression(elements=[Literal(value=1), Literal(value=2), Literal(value=3)])
                ]
            )
        )
        from ...translator.types import SQLCast
        assert isinstance(result, SQLCast)
        # List literal → list_aggregate (DuckDB's MEDIAN is a column aggregate),
        # typed to the CQL §20 Decimal result type.
        assert result.target_type == "DECIMAL(38, 8)"
        inner = result.expression
        assert isinstance(inner, SQLFunctionCall)
        assert inner.name == "list_aggregate"
        assert len(inner.args) == 2

    def test_mode_function(self, translator: ExpressionTranslator):
        """Test Mode function: Mode(values) -> CQLListMode(values)."""
        from ...parser.ast_nodes import FunctionRef, ListExpression
        result = translator.translate(
            FunctionRef(
                name="Mode",
                arguments=[
                    ListExpression(elements=[Literal(value=1), Literal(value=2), Literal(value=2), Literal(value=3)])
                ]
            )
        )
        assert isinstance(result, SQLFunctionCall)
        assert result.name == "CQLListMode"
        assert len(result.args) == 1

    def test_variance_function(self, translator: ExpressionTranslator):
        """Test Variance function: Variance(values) -> list_aggregate(..., 'var_samp')."""
        from ...parser.ast_nodes import FunctionRef, ListExpression
        result = translator.translate(
            FunctionRef(
                name="Variance",
                arguments=[
                    ListExpression(elements=[Literal(value=1), Literal(value=2), Literal(value=3), Literal(value=4)])
                ]
            )
        )
        from ...translator.types import SQLCast
        assert isinstance(result, SQLCast)
        assert result.target_type == "DECIMAL(38, 8)"
        inner = result.expression
        assert isinstance(inner, SQLFunctionCall)
        assert inner.name == "list_aggregate"
        assert len(inner.args) == 2
        assert "'var_samp'" in result.to_sql()

    def test_stddev_function(self, translator: ExpressionTranslator):
        """Test StdDev function: StdDev(values) -> list_aggregate(..., 'stddev_samp')."""
        from ...parser.ast_nodes import FunctionRef, ListExpression
        result = translator.translate(
            FunctionRef(
                name="StdDev",
                arguments=[
                    ListExpression(elements=[Literal(value=1), Literal(value=2), Literal(value=3)])
                ]
            )
        )
        from ...translator.types import SQLCast
        assert isinstance(result, SQLCast)
        assert result.target_type == "DECIMAL(38, 8)"
        inner = result.expression
        assert isinstance(inner, SQLFunctionCall)
        assert inner.name == "list_aggregate"
        assert len(inner.args) == 2
        assert "'stddev_samp'" in result.to_sql()

    def test_population_variance_function(self, translator: ExpressionTranslator):
        """Test PopulationVariance function -> list_aggregate(..., 'var_pop')."""
        from ...parser.ast_nodes import FunctionRef, ListExpression
        result = translator.translate(
            FunctionRef(
                name="PopulationVariance",
                arguments=[
                    ListExpression(elements=[Literal(value=1), Literal(value=2), Literal(value=3)])
                ]
            )
        )
        from ...translator.types import SQLCast
        assert isinstance(result, SQLCast)
        assert result.target_type == "DECIMAL(38, 8)"
        inner = result.expression
        assert isinstance(inner, SQLFunctionCall)
        assert inner.name == "list_aggregate"
        assert len(inner.args) == 2
        assert "'var_pop'" in result.to_sql()

    def test_population_stddev_function(self, translator: ExpressionTranslator):
        """Test PopulationStdDev function -> list_aggregate(..., 'stddev_pop')."""
        from ...parser.ast_nodes import FunctionRef, ListExpression
        result = translator.translate(
            FunctionRef(
                name="PopulationStdDev",
                arguments=[
                    ListExpression(elements=[Literal(value=1), Literal(value=2), Literal(value=3)])
                ]
            )
        )
        from ...translator.types import SQLCast
        assert isinstance(result, SQLCast)
        assert result.target_type == "DECIMAL(38, 8)"
        inner = result.expression
        assert isinstance(inner, SQLFunctionCall)
        assert inner.name == "list_aggregate"
        assert len(inner.args) == 2
        assert "'stddev_pop'" in result.to_sql()


class TestOrdinalFunctions:
    """Tests for ordinal function translation (predecessor, successor)."""

    @pytest.fixture
    def translator(self) -> ExpressionTranslator:
        """Create an ExpressionTranslator instance for testing."""
        context = SQLTranslationContext()
        return ExpressionTranslator(context)

    def test_predecessor_of_integer(self, translator: ExpressionTranslator):
        """Test predecessor of integer: predecessor of 5 -> predecessorOf(5)."""
        result = translator.translate(
            UnaryExpression(operator="predecessor of", operand=Literal(value=5))
        )
        assert isinstance(result, SQLFunctionCall)
        assert result.name == "predecessorOf"
        assert len(result.args) == 1
        assert result.args[0].value == 5

    def test_successor_of_integer(self, translator: ExpressionTranslator):
        """Test successor of integer: successor of 5 -> successorOf(5)."""
        result = translator.translate(
            UnaryExpression(operator="successor of", operand=Literal(value=5))
        )
        assert isinstance(result, SQLFunctionCall)
        assert result.name == "successorOf"
        assert len(result.args) == 1
        assert result.args[0].value == 5

    def test_predecessor_of_identifier(self, translator: ExpressionTranslator):
        """Test predecessor of identifier: predecessor of X -> predecessorOf(X)."""
        result = translator.translate(
            UnaryExpression(operator="predecessor of", operand=Identifier(name="X"))
        )
        assert isinstance(result, SQLFunctionCall)
        assert result.name == "predecessorOf"
        assert len(result.args) == 1
        assert isinstance(result.args[0], SQLIdentifier)
        assert result.args[0].name == "X"

    def test_successor_of_identifier(self, translator: ExpressionTranslator):
        """Test successor of identifier: successor of X -> successorOf(X)."""
        result = translator.translate(
            UnaryExpression(operator="successor of", operand=Identifier(name="X"))
        )
        assert isinstance(result, SQLFunctionCall)
        assert result.name == "successorOf"
        assert len(result.args) == 1
        assert isinstance(result.args[0], SQLIdentifier)
        assert result.args[0].name == "X"


class TestSpecialAggregateFunctions:
    """Tests for special aggregate function translation (GeometricMean, Product)."""

    @pytest.fixture
    def translator(self) -> ExpressionTranslator:
        """Create an ExpressionTranslator instance for testing."""
        context = SQLTranslationContext()
        return ExpressionTranslator(context)

    def test_geometric_mean(self, translator: ExpressionTranslator):
        """GeometricMean never emits the LOG-domain expansion (EXP1-013).

        The parser only routes Count/Sum/Min/Max/Avg/Median/Mode tokens into
        AggregateExpression; GeometricMean arrives as a FunctionRef and the
        pre-translate hook lowers it to the exact GeometricMean UDF. The
        former EXP(AVG(LOG(x))) branch was dead from the parser AND doubly
        wrong (DuckDB 1-arg LOG is base-10, and the CQL Log(x, base) macro
        shadows it on registered connections). Deleted 2026-11-13; this
        pins the parser-reachable lowering plus correct execution.
        """
        import duckdb

        from fhir4ds.cql import translate_cql
        from fhir4ds.cql.duckdb import register

        r = translate_cql("library T\ndefine G: GeometricMean({2.0, 8.0})")
        sql = r["G"].to_sql()
        assert "GeometricMean(" in sql
        assert "EXP(" not in sql and "LOG(" not in sql

        con = duckdb.connect()
        register(con)
        assert con.execute(f"SELECT {sql}").fetchone()[0] == 4.0

    def test_geometric_mean_lowercase(self, translator: ExpressionTranslator):
        """Case-insensitive spelling lowers to the same exact UDF."""
        from fhir4ds.cql import translate_cql

        r = translate_cql("library T\ndefine G: geometricmean({2.0, 8.0})")
        sql = r["G"].to_sql()
        assert "eometricMean(" in sql  # case-insensitive dispatch
        assert "EXP(" not in sql and "LOG(" not in sql

    def test_product(self, translator: ExpressionTranslator):
        """Product lowers to exact list_aggregate('product'), never LOG-domain."""
        import duckdb

        from fhir4ds.cql import translate_cql
        from fhir4ds.cql.duckdb import register

        r = translate_cql("library T\ndefine P: Product({2.0, 3.0, 4.0})")
        sql = r["P"].to_sql()
        assert "list_aggregate" in sql and "'product'" in sql
        assert "EXP(" not in sql and "LOG(" not in sql

        con = duckdb.connect()
        register(con)
        assert con.execute(f"SELECT {sql}").fetchone()[0] == 24.0

    def test_product_lowercase(self, translator: ExpressionTranslator):
        """Case-insensitive spelling lowers to the same exact product path."""
        from fhir4ds.cql import translate_cql

        r = translate_cql("library T\ndefine P: product({2.0, 3.0, 4.0})")
        sql = r["P"].to_sql()
        assert "list_aggregate" in sql and "'product'" in sql
        assert "EXP(" not in sql

    def test_geometric_mean_sql_output(self, translator: ExpressionTranslator):
        """SQL output names the exact UDF, not an EXP/LOG expansion."""
        from fhir4ds.cql import translate_cql

        r = translate_cql("library T\ndefine G: GeometricMean({2.0, 8.0})")
        sql = r["G"].to_sql()
        assert "GeometricMean(" in sql
        assert "LOG" not in sql

    def test_product_sql_output(self, translator: ExpressionTranslator):
        """SQL output uses exact list_aggregate('product'), not EXP/SUM(LOG)."""
        from fhir4ds.cql import translate_cql

        r = translate_cql("library T\ndefine P: Product({2.0, 3.0})")
        sql = r["P"].to_sql()
        assert "list_aggregate" in sql
        assert "EXP" not in sql and "LOG" not in sql


class TestStringPositionFunctions:
    """Tests for string position function translation (PositionOf, LastPositionOf)."""

    @pytest.fixture
    def translator(self) -> ExpressionTranslator:
        """Create an ExpressionTranslator instance for testing."""
        context = SQLTranslationContext()
        return ExpressionTranslator(context)

    def test_position_of(self, translator: ExpressionTranslator):
        """Test PositionOf function: PositionOf('lo', 'hello') -> CASE WHEN strpos=0 THEN -1 ELSE strpos-1 END."""
        from ...parser.ast_nodes import FunctionRef
        from ...translator.types import SQLCase
        result = translator.translate(
            FunctionRef(
                name="PositionOf",
                arguments=[
                    Literal(value="lo"),
                    Literal(value="hello"),
                ]
            )
        )
        # PositionOf now returns SQLCase for proper 0-based indexing (CQL semantics)
        assert isinstance(result, SQLCase)
        # When not found (strpos=0), returns -1; otherwise returns strpos-1 for 0-based index

    def test_position_of_not_found(self, translator: ExpressionTranslator):
        """Test PositionOf when substring not found returns -1 (CQL 0-based semantics)."""
        from ...parser.ast_nodes import FunctionRef
        from ...translator.types import SQLCase, SQLLiteral
        result = translator.translate(
            FunctionRef(
                name="PositionOf",
                arguments=[
                    Literal(value="xyz"),
                    Literal(value="hello"),
                ]
            )
        )
        # PositionOf now returns SQLCase - returns -1 when not found
        assert isinstance(result, SQLCase)
        # The when clause checks strpos=0 and returns -1
        assert result.when_clauses[0][1].value == -1

    def test_last_position_of(self, translator: ExpressionTranslator):
        """Test LastPositionOf function: LastPositionOf('l', 'hello') -> UDF call."""
        from ...parser.ast_nodes import FunctionRef
        result = translator.translate(
            FunctionRef(
                name="LastPositionOf",
                arguments=[
                    Literal(value="l"),
                    Literal(value="hello"),
                ]
            )
        )
        assert isinstance(result, SQLFunctionCall)
        assert result.name == "LastPositionOf"

    def test_last_position_of_multiple_occurrences(self, translator: ExpressionTranslator):
        """Test LastPositionOf with multiple occurrences finds last one."""
        from ...parser.ast_nodes import FunctionRef
        result = translator.translate(
            FunctionRef(
                name="LastPositionOf",
                arguments=[
                    Literal(value="o"),
                    Literal(value="hello world"),
                ]
            )
        )
        assert isinstance(result, SQLFunctionCall)
        assert result.name == "LastPositionOf"

    def test_position_of_case_insensitive(self, translator: ExpressionTranslator):
        """Test PositionOf function name is case-insensitive."""
        from ...parser.ast_nodes import FunctionRef
        from ...translator.types import SQLCase
        for name in ["PositionOf", "positionof", "POSITIONOF"]:
            result = translator.translate(
                FunctionRef(
                    name=name,
                    arguments=[
                        Literal(value="a"),
                        Literal(value="abc"),
                    ]
                )
            )
            # PositionOf now returns SQLCase for proper 0-based indexing
            assert isinstance(result, SQLCase)

    def test_last_position_of_case_insensitive(self, translator: ExpressionTranslator):
        """Test LastPositionOf function name is case-insensitive."""
        from ...parser.ast_nodes import FunctionRef
        for name in ["LastPositionOf", "lastpositionof", "LASTPOSITIONOF"]:
            result = translator.translate(
                FunctionRef(
                    name=name,
                    arguments=[
                        Literal(value="a"),
                        Literal(value="abc"),
                    ]
                )
            )
            assert isinstance(result, SQLFunctionCall)
            assert result.name == "LastPositionOf"

    def test_position_of_with_identifiers(self, translator: ExpressionTranslator):
        """Test PositionOf with identifier arguments."""
        from ...parser.ast_nodes import FunctionRef
        from ...translator.types import SQLCase
        result = translator.translate(
            FunctionRef(
                name="PositionOf",
                arguments=[
                    Identifier(name="substr"),
                    Identifier(name="source"),
                ]
            )
        )
        # PositionOf now returns SQLCase for proper 0-based indexing
        assert isinstance(result, SQLCase)


class TestTimezoneOffset:
    """Tests for timezoneoffset date component extraction."""

    @pytest.fixture
    def translator(self) -> ExpressionTranslator:
        """Create an ExpressionTranslator instance for testing."""
        context = SQLTranslationContext()
        return ExpressionTranslator(context)

    def test_timezoneoffset_from_datetime(self, translator: ExpressionTranslator):
        """Test timezoneoffset from dateTime returns UDF call."""
        from ...parser.ast_nodes import DateComponent
        result = translator.translate(
            DateComponent(component="timezoneoffset", operand=DateTimeLiteral(value="2024-01-15T10:30:00"))
        )
        assert isinstance(result, SQLFunctionCall)
        assert result.name == "cqlTimezoneOffset"

    def test_timezoneoffset_case_insensitive(self, translator: ExpressionTranslator):
        """Test timezoneoffset is case-insensitive."""
        from ...parser.ast_nodes import DateComponent
        for component in ["timezoneoffset", "TimeZoneOffset", "TIMEZONEOFFSET"]:
            result = translator.translate(
                DateComponent(component=component, operand=DateTimeLiteral(value="2024-01-15"))
            )
            assert isinstance(result, SQLFunctionCall)
            assert result.name == "cqlTimezoneOffset"

    def test_timezoneoffset_with_identifier(self, translator: ExpressionTranslator):
        """Test timezoneoffset from identifier returns UDF call."""
        from ...parser.ast_nodes import DateComponent
        result = translator.translate(
            DateComponent(component="timezoneoffset", operand=Identifier(name="someDateTime"))
        )
        assert isinstance(result, SQLFunctionCall)
        assert result.name == "cqlTimezoneOffset"


class TestIntervalCollapseExpand:
    """Tests for interval collapse and expand functions."""

    @pytest.fixture
    def translator(self) -> ExpressionTranslator:
        """Create an ExpressionTranslator instance for testing."""
        context = SQLTranslationContext()
        return ExpressionTranslator(context)

    def test_collapse_intervals(self, translator: ExpressionTranslator):
        """Test collapse function: collapse intervals -> collapse(...)."""
        from ...parser.ast_nodes import FunctionRef, ListExpression
        result = translator.translate(
            FunctionRef(
                name="collapse",
                arguments=[
                    ListExpression(elements=[
                        Interval(
                            low=Literal(value=1),
                            high=Literal(value=5),
                            low_closed=True,
                            high_closed=True,
                        ),
                        Interval(
                            low=Literal(value=3),
                            high=Literal(value=10),
                            low_closed=True,
                            high_closed=True,
                        ),
                    ])
                ]
            )
        )
        assert isinstance(result, SQLFunctionCall)
        assert result.name == "collapse_intervals"
        assert len(result.args) == 1

    def test_expand_interval(self, translator: ExpressionTranslator):
        """Test expand function: expand interval -> expand UDF call."""
        from ...parser.ast_nodes import FunctionRef
        result = translator.translate(
            FunctionRef(
                name="expand",
                arguments=[
                    Interval(
                        low=Literal(value=1),
                        high=Literal(value=5),
                        low_closed=True,
                        high_closed=True,
                    ),
                ]
            )
        )
        assert isinstance(result, SQLFunctionCall)
        # expand may use expand_points1 or expand internally
        assert "expand" in result.name.lower()

    def test_expand_interval_with_per(self, translator: ExpressionTranslator):
        """Test expand function with per quantity."""
        from ...parser.ast_nodes import FunctionRef, Quantity
        result = translator.translate(
            FunctionRef(
                name="expand",
                arguments=[
                    Interval(
                        low=DateTimeLiteral(value="2024-01-01"),
                        high=DateTimeLiteral(value="2024-01-31"),
                        low_closed=True,
                        high_closed=True,
                    ),
                    Quantity(value=1, unit="day"),
                ]
            )
        )
        assert isinstance(result, SQLFunctionCall)
        assert "expand" in result.name.lower()

    def test_collapse_case_insensitive(self, translator: ExpressionTranslator):
        """Test collapse function name is case-insensitive."""
        from ...parser.ast_nodes import FunctionRef, ListExpression
        for name in ["collapse", "Collapse", "COLLAPSE"]:
            result = translator.translate(
                FunctionRef(
                    name=name,
                    arguments=[
                        ListExpression(elements=[])
                    ]
                )
            )
            assert isinstance(result, SQLFunctionCall)

    def test_expand_case_insensitive(self, translator: ExpressionTranslator):
        """Test expand function name is case-insensitive."""
        from ...parser.ast_nodes import FunctionRef
        for name in ["expand", "Expand", "EXPAND"]:
            result = translator.translate(
                FunctionRef(
                    name=name,
                    arguments=[
                        Interval(
                            low=Literal(value=1),
                            high=Literal(value=5),
                            low_closed=True,
                            high_closed=True,
                        ),
                    ]
                )
            )
            assert isinstance(result, SQLFunctionCall)


class TestPatientCorrelation:
    """Test that retrieve returns placeholders (patient correlation is in CTE builder)."""

    @pytest.fixture
    def context(self) -> SQLTranslationContext:
        """Create a fresh context for each test."""
        return SQLTranslationContext()

    @pytest.fixture
    def translator(self, context: SQLTranslationContext) -> ExpressionTranslator:
        """Create an ExpressionTranslator instance for testing."""
        return ExpressionTranslator(context)

    def test_retrieve_returns_placeholder(self, translator: ExpressionTranslator):
        """Test that retrieve returns a RetrievePlaceholder."""
        from ...translator.placeholder import RetrievePlaceholder

        retrieve_node = Retrieve(type="Condition", terminology=None)
        result = translator.translate(retrieve_node)

        assert isinstance(result, RetrievePlaceholder)
        assert result.resource_type == "Condition"
        assert result.valueset is None

    def test_retrieve_with_valueset_returns_placeholder(self, context: SQLTranslationContext):
        """Test that retrieve with valueset returns placeholder with valueset."""
        from ...translator.placeholder import RetrievePlaceholder

        context.valuesets["Diabetes"] = "http://example.com/ValueSet/Diabetes"
        translator = ExpressionTranslator(context)

        retrieve_node = Retrieve(type="Condition", terminology="Diabetes")
        result = translator.translate(retrieve_node)

        assert isinstance(result, RetrievePlaceholder)
        assert result.resource_type == "Condition"
        assert result.valueset == "http://example.com/ValueSet/Diabetes"

    def test_placeholder_key_is_unique(self, translator: ExpressionTranslator):
        """Test that placeholder key uniquely identifies retrieve."""
        from ...translator.placeholder import RetrievePlaceholder

        retrieve_node = Retrieve(type="Observation", terminology=None)
        result = translator.translate(retrieve_node)

        assert isinstance(result, RetrievePlaceholder)
        assert result.key == ("Observation", None, None)

    def test_placeholder_with_valueset_key(self, context: SQLTranslationContext):
        """Test placeholder key with valueset."""
        from ...translator.placeholder import RetrievePlaceholder

        context.valuesets["BP"] = "http://example.com/ValueSet/BP"
        translator = ExpressionTranslator(context)

        retrieve_node = Retrieve(type="Observation", terminology="BP")
        result = translator.translate(retrieve_node)

        assert isinstance(result, RetrievePlaceholder)
        assert result.key == ("Observation", "http://example.com/ValueSet/BP", None)


class TestDuringOperatorNullHandling:
    """Tests for 'during precision of' operator with NULL end date handling.

    Tests that COALESCE is applied to handle NULL end dates in intervals,
    which can occur when a Period is ongoing (no end date specified).
    """

    @pytest.fixture
    def translator(self) -> ExpressionTranslator:
        """Create an ExpressionTranslator instance for testing."""
        context = SQLTranslationContext()
        return ExpressionTranslator(context)

    def test_during_day_of_uses_boundary_comparisons(self, translator: ExpressionTranslator):
        """Test 'during day of' uses boundary-aware AND comparisons (Gap 11)."""
        result = translator.translate(
            BinaryExpression(
                operator="during day of",
                left=DateTimeLiteral(value="2024-06-15"),
                right=Interval(
                    low=DateTimeLiteral(value="2024-01-01"),
                    high=DateTimeLiteral(value="2024-12-31"),
                    low_closed=True,
                    high_closed=True,
                ),
            )
        )

        # Gap 11: Result should be AND (not BETWEEN) for boundary awareness
        assert isinstance(result, SQLBinaryOp)
        assert result.operator == "AND"
        # For closed-closed [A, B], use >= and <=
        assert isinstance(result.left, SQLBinaryOp)
        assert result.left.operator == ">="
        assert isinstance(result.right, SQLBinaryOp)
        assert result.right.operator == "<="

    def test_during_month_of_uses_boundary_comparisons(self, translator: ExpressionTranslator):
        """Test 'during month of' uses boundary-aware AND comparisons (Gap 11)."""
        result = translator.translate(
            BinaryExpression(
                operator="during month of",
                left=DateTimeLiteral(value="2024-06-15"),
                right=Interval(
                    low=DateTimeLiteral(value="2024-01-01"),
                    high=DateTimeLiteral(value="2024-12-31"),
                    low_closed=True,
                    high_closed=True,
                ),
            )
        )

        # Gap 11: Result should be AND for boundary awareness
        assert isinstance(result, SQLBinaryOp)
        assert result.operator == "AND"

    def test_during_year_of_uses_boundary_comparisons(self, translator: ExpressionTranslator):
        """Test 'during year of' uses boundary-aware AND comparisons (Gap 11)."""
        result = translator.translate(
            BinaryExpression(
                operator="during year of",
                left=DateTimeLiteral(value="2024-06-15"),
                right=Interval(
                    low=DateTimeLiteral(value="2024-01-01"),
                    high=DateTimeLiteral(value="2024-12-31"),
                    low_closed=True,
                    high_closed=True,
                ),
            )
        )

        # Gap 11: Result should be AND for boundary awareness
        assert isinstance(result, SQLBinaryOp)
        assert result.operator == "AND"

    def test_during_half_open_uses_less_than(self, translator: ExpressionTranslator):
        """Test 'during day of' with half-open [A, B) uses < for end (Gap 11)."""
        result = translator.translate(
            BinaryExpression(
                operator="during day of",
                left=DateTimeLiteral(value="2024-06-15"),
                right=Interval(
                    low=DateTimeLiteral(value="2024-01-01"),
                    high=DateTimeLiteral(value="2024-12-31"),
                    low_closed=True,
                    high_closed=False,  # Half-open
                ),
            )
        )

        # Gap 11: Half-open end should use < not <=
        assert isinstance(result, SQLBinaryOp)
        assert result.operator == "AND"
        assert result.left.operator == ">="
        assert result.right.operator == "<"  # NOT <= because high_closed=False

    def test_during_without_precision_uses_intervalcontains(
        self, translator: ExpressionTranslator
    ):
        """Test 'during' without precision uses intervalContains UDF (no COALESCE)."""
        result = translator.translate(
            BinaryExpression(
                operator="during",
                left=DateTimeLiteral(value="2024-06-15"),
                right=Interval(
                    low=DateTimeLiteral(value="2024-01-01"),
                    high=DateTimeLiteral(value="2024-12-31"),
                    low_closed=True,
                    high_closed=True,
                ),
            )
        )

        # Without precision, should use intervalContains
        assert isinstance(result, SQLFunctionCall)
        assert result.name == "intervalContains"

    def test_during_hour_of_uses_boundary_comparisons(self, translator: ExpressionTranslator):
        """QA-D4H-001: sub-day 'during hour of' over a recognized interval
        routes to the tz-normalizing intervalIncludedInPrecise (CQL 1.5
        mandates offset normalization at hour-or-finer precision)."""
        result = translator.translate(
            BinaryExpression(
                operator="during hour of",
                left=DateTimeLiteral(value="2024-06-15T10:30:00"),
                right=Interval(
                    low=DateTimeLiteral(value="2024-06-15T08:00:00"),
                    high=DateTimeLiteral(value="2024-06-15T18:00:00"),
                    low_closed=True,
                    high_closed=True,
                ),
            )
        )

        assert isinstance(result, SQLFunctionCall)
        assert result.name == "intervalContainsPrecise"
        assert result.args[-1] == SQLLiteral(value="hour")

    def test_during_day_of_keeps_boundary_decomposition(self, translator: ExpressionTranslator):
        """Day-and-coarser precision keeps the optimized boundary-aware AND
        decomposition (pinned CQL-14 doctrine: raw components at day
        precision; timezone normalization applies only hour-or-finer)."""
        result = translator.translate(
            BinaryExpression(
                operator="during day of",
                left=DateTimeLiteral(value="2024-06-15T10:30:00"),
                right=Interval(
                    low=DateTimeLiteral(value="2024-06-15T08:00:00"),
                    high=DateTimeLiteral(value="2024-06-15T18:00:00"),
                    low_closed=True,
                    high_closed=True,
                ),
            )
        )

        # Gap 11: Result should be AND for boundary awareness
        assert isinstance(result, SQLBinaryOp)
        assert result.operator == "AND"
