"""Unit tests for HTTPTerminologyEndpoint.

The httpx transport is mocked so these tests are hermetic and run
without a live medterm4ds sidecar.
"""

from __future__ import annotations

import json
from typing import Any
from unittest.mock import MagicMock, patch

import pytest

from fhir4ds.cql.terminology import (
    CodeRef,
    SearchResult,
    TerminologyCapabilityError,
    TerminologyEndpointError,
)
from fhir4ds.cql.terminology.http_adapter import HTTPTerminologyEndpoint


# ----------------------------------------------------------------------
# Helpers
# ----------------------------------------------------------------------


def _expand_payload(contains: list[dict[str, Any]]) -> dict[str, Any]:
    """Build a FHIR R4 ValueSet $expand response body."""
    return {
        "resourceType": "ValueSet",
        "expansion": {"contains": contains},
    }


def _search_bundle(entries: list[dict[str, Any]]) -> dict[str, Any]:
    """Build a $search Bundle response body."""
    return {
        "resourceType": "Bundle",
        "entry": [{"resource": e} for e in entries],
    }


class _MockResponse:
    """Minimal httpx.Response stand-in."""

    def __init__(self, payload: dict[str, Any], status_code: int = 200):
        self._payload = payload
        self.status_code = status_code
        self.text = json.dumps(payload)

    def json(self) -> dict[str, Any]:
        return self._payload

    def raise_for_status(self) -> None:
        if self.status_code >= 400:
            raise RuntimeError(f"HTTP {self.status_code}")


class _MockClient:
    """Captures calls and returns canned responses."""

    def __init__(self, response: _MockResponse, records: list[tuple[str, str, dict]]):
        self._response = response
        self._records = records

    def __enter__(self) -> "_MockClient":
        return self

    def __exit__(self, *args: object) -> None:
        return None

    def get(self, url: str, params: dict | None = None) -> _MockResponse:
        self._records.append(("GET", url, params or {}))
        return self._response

    def post(
        self,
        url: str,
        json: dict | None = None,
        params: dict | None = None,
    ) -> _MockResponse:
        self._records.append(("POST", url, json or {}, params or {}))
        return self._response


# ----------------------------------------------------------------------
# Construction
# ----------------------------------------------------------------------


def test_constructor_strips_trailing_slash():
    adapter = HTTPTerminologyEndpoint("http://localhost:8001/fhir/", timeout_seconds=3.0)
    assert adapter._base_url == "http://localhost:8001/fhir"


def test_constructor_requires_base_url():
    with pytest.raises(ValueError, match="base_url"):
        HTTPTerminologyEndpoint("", timeout_seconds=3.0)


# ----------------------------------------------------------------------
# QA-014: HTTPTerminologyEndpoint validates base_url shape at
# construction (fail-fast). Common typos must be caught here, not
# deferred to the first network call where httpx throws an opaque
# protocol error far from the construction site.
# ----------------------------------------------------------------------


@pytest.mark.parametrize(
    "bad_url",
    [
        "not-a-url",          # plain string, no scheme
        "ftp://example",      # wrong scheme
        "localhost:8001",     # missing scheme — common typo
        "//example.com/fhir", # scheme-relative, no scheme
        "http://",            # no host
        "https:///fhir",      # no host
    ],
)
def test_qa014_constructor_rejects_malformed_base_url(bad_url):
    """Non-URL / wrong-scheme base_url must raise at construction."""
    with pytest.raises(ValueError, match="base_url must be an http\\(s\\) URL") as exc:
        HTTPTerminologyEndpoint(bad_url, timeout_seconds=3.0)
    # The invalid URL must be echoed back so the operator can see the typo.
    assert bad_url in str(exc.value)


@pytest.mark.parametrize(
    "good_url",
    [
        "http://localhost:8001/fhir",
        "https://example.com/fhir",
        "http://127.0.0.1:7860/fhir",
    ],
)
def test_qa014_constructor_accepts_well_formed_base_url(good_url):
    """Positive control: well-formed http(s) URLs must construct cleanly."""
    adapter = HTTPTerminologyEndpoint(good_url, timeout_seconds=3.0)
    assert adapter._base_url == good_url.rstrip("/")


def test_constructor_requires_finite_timeout():
    with pytest.raises(ValueError, match="positive float"):
        HTTPTerminologyEndpoint("http://localhost:8001/fhir", timeout_seconds=0)
    with pytest.raises(ValueError, match="positive float"):
        HTTPTerminologyEndpoint("http://localhost:8001/fhir", timeout_seconds=-1)


def test_constructor_rejects_none_timeout():
    """INV-6: no infinite hangs."""
    with pytest.raises(ValueError, match="positive float"):
        HTTPTerminologyEndpoint("http://localhost:8001/fhir", timeout_seconds=None)  # type: ignore[arg-type]


# ----------------------------------------------------------------------
# expand()
# ----------------------------------------------------------------------


def test_expand_invokes_get_with_canonical_url():
    payload = _expand_payload(
        [{"system": "http://snomed.info/sct", "code": "73211009", "display": "Diabetes"}]
    )
    response = _MockResponse(payload)
    records: list[tuple[str, str, dict]] = []
    adapter = HTTPTerminologyEndpoint("http://localhost:8001/fhir", timeout_seconds=5.0)
    with patch.object(adapter, "_client", return_value=_MockClient(response, records)):
        refs = adapter.expand("http://example.org/ValueSet/Foo")
    assert refs == [CodeRef("http://snomed.info/sct", "73211009", "Diabetes")]
    # MT-003: count=1000 (server max; medterm default 20 silently
    # truncated large value sets) and activeOnly=false (expansion feeds
    # membership resolution — retired codes included per settled policy).
    assert records == [
        (
            "GET",
            "http://localhost:8001/fhir/ValueSet/$expand",
            {
                "url": "http://example.org/ValueSet/Foo",
                "count": 1000,
                "activeOnly": "false",
            },
        )
    ]


def test_expand_refused_by_backend_raises_actionable_typed_error():
    """A 400/422 on $expand is a backend capability gap, not a bare HTTP error.

    medterm4ds resolves only a POSTed ValueSet body, a SNOMED fhir_vs implicit
    URL, or a filter parameter — it has no stored-ValueSet-by-canonical
    registry, so ``?url=`` is refused. DependencyResolver degrades any endpoint
    failure to None + WARNING (INV-8), so this message is the only diagnosis a
    user ever sees: it must name the cause and a remedy, not say "400".
    """
    payload = {
        "resourceType": "OperationOutcome",
        "issue": [
            {
                "severity": "error",
                "diagnostics": "Provide a ValueSet body, a fhir_vs URL, or a "
                               "filter parameter.",
            }
        ],
    }
    response = _MockResponse(payload, status_code=400)
    adapter = HTTPTerminologyEndpoint("http://localhost:8001/fhir", timeout_seconds=5.0)
    with patch.object(adapter, "_client", return_value=_MockClient(response, [])):
        with pytest.raises(TerminologyCapabilityError) as excinfo:
            adapter.expand("http://example.org/ValueSet/Foo")

    message = str(excinfo.value)
    assert "HTTP 400" in message
    assert "Provide a ValueSet body" in message       # server diagnostics carried through
    assert "fhir_vs" in message and "medterm4ds" in message  # names the cause
    assert "expand_intensional" in message           # names a remedy
    # QA-D12H-002 (v0.0.26 D12 HISTORIAN): capability refusals are
    # deterministic and must NOT count toward the circuit breaker — the
    # in-process doctrine (QA-D12S-001) applies here too. The former
    # `failures >= 1` expectation predates that doctrine and, if honored,
    # let five refusals trip the breaker into silent [] short-circuiting.
    failures, _ = adapter._breaker_snapshot()
    assert failures == 0


def test_expand_normalizes_snomed_module_url():
    """INV-5 regression: SNOMED module URLs reduce to base."""
    payload = _expand_payload(
        [
            {
                "system": "http://snomed.info/sct/731000124108",
                "code": "73211009",
            }
        ]
    )
    response = _MockResponse(payload)
    records: list[tuple[str, str, dict]] = []
    adapter = HTTPTerminologyEndpoint("http://localhost:8001/fhir")
    with patch.object(adapter, "_client", return_value=_MockClient(response, records)):
        refs = adapter.expand("http://example.org/ValueSet/Foo")
    assert len(refs) == 1
    assert refs[0].system == "http://snomed.info/sct"


def test_expand_empty_payload_returns_empty_list():
    payload = _expand_payload([])
    response = _MockResponse(payload)
    records: list[tuple[str, str, dict]] = []
    adapter = HTTPTerminologyEndpoint("http://localhost:8001/fhir")
    with patch.object(adapter, "_client", return_value=_MockClient(response, records)):
        assert adapter.expand("http://example.org/ValueSet/Empty") == []


def test_expand_skips_entries_missing_system_or_code():
    payload = _expand_payload(
        [
            {"system": "http://snomed.info/sct", "code": "73211009"},
            {"system": "http://snomed.info/sct"},  # missing code
            {"code": "12345"},  # missing system
        ]
    )
    response = _MockResponse(payload)
    records: list[tuple[str, str, dict]] = []
    adapter = HTTPTerminologyEndpoint("http://localhost:8001/fhir")
    with patch.object(adapter, "_client", return_value=_MockClient(response, records)):
        refs = adapter.expand("http://example.org/ValueSet/Foo")
    assert len(refs) == 1
    assert refs[0].code == "73211009"


# ----------------------------------------------------------------------
# expand_intensional()
# ----------------------------------------------------------------------


def test_expand_intensional_posts_value_set_body():
    payload = _expand_payload(
        [{"system": "http://snomed.info/sct", "code": "73211009"}]
    )
    response = _MockResponse(payload)
    records: list[tuple[str, str, dict]] = []
    adapter = HTTPTerminologyEndpoint("http://localhost:8001/fhir")
    body = {"resourceType": "ValueSet", "compose": {"include": []}}
    with patch.object(adapter, "_client", return_value=_MockClient(response, records)):
        refs = adapter.expand_intensional(body)
    assert refs == [CodeRef("http://snomed.info/sct", "73211009", None)]
    assert records[0][0] == "POST"
    assert records[0][1] == "http://localhost:8001/fhir/ValueSet/$expand"
    assert records[0][2] == body
    # MT-003: intensional expansion is capped at the same count=1000 and
    # activeOnly=false as plain expansion (membership path, retired in).
    assert records[0][3] == {"count": 1000, "activeOnly": "false"}


# ----------------------------------------------------------------------
# search_text() / search_batch()
# ----------------------------------------------------------------------


def test_search_text_returns_search_results():
    payload = _search_bundle(
        [
            {
                "system": "http://snomed.info/sct",
                "code": "73211009",
                "display": "Diabetes mellitus",
                "score": 0.95,
                "matchGrade": "certain",
            }
        ]
    )
    response = _MockResponse(payload)
    records: list[tuple[str, str, dict]] = []
    adapter = HTTPTerminologyEndpoint("http://localhost:8001/fhir")
    with patch.object(adapter, "_client", return_value=_MockClient(response, records)):
        results = adapter.search_text("diabetes", "condition", mode="hybrid")
    assert len(results) == 1
    r = results[0]
    assert isinstance(r, SearchResult)
    assert r.system == "http://snomed.info/sct"
    assert r.code == "73211009"
    assert r.score == pytest.approx(0.95)
    assert r.match_grade == "certain"
    assert r.search_mode == "hybrid"


# ----------------------------------------------------------------------
# MT-002: $search must send the params medterm4ds actually reads
# (system / searchMode / count). The legacy category/mode params were
# silently dropped by FastAPI, making every HTTP search all-systems
# lexical regardless of the caller's request.
# ----------------------------------------------------------------------


def _recorded_search_params(
    category: str, mode: str = "hybrid"
) -> dict[str, str]:
    response = _MockResponse(_search_bundle([]))
    records: list[tuple[str, str, dict]] = []
    adapter = HTTPTerminologyEndpoint("http://localhost:8001/fhir")
    with patch.object(adapter, "_client", return_value=_MockClient(response, records)):
        adapter.search_text("diabetes", category, mode=mode)
    assert len(records) == 1
    return records[0][2]


def test_mt002_search_sends_system_searchmode_count():
    params = _recorded_search_params("condition")
    assert params["query"] == "diabetes"
    # condition -> SNOMEDCT_US -> canonical URL.
    assert params["system"] == "http://snomed.info/sct"
    assert params["searchMode"] == "hybrid"
    # 25 = parity with the in-process discovery limit.
    assert params["count"] == "25"
    # Legacy params medterm4ds never read must be gone.
    assert "category" not in params
    assert "mode" not in params


def test_mt002_search_maps_each_known_category():
    assert (
        _recorded_search_params("medication")["system"]
        == "http://www.nlm.nih.gov/research/umls/rxnorm"
    )
    assert _recorded_search_params("lab")["system"] == "http://loinc.org"
    assert _recorded_search_params("icd10")["system"] == (
        "http://hl7.org/fhir/sid/icd-10-cm"
    )


@pytest.mark.parametrize("category", ["", "unknown-category", "   "])
def test_mt002_unknown_or_empty_category_omits_system(category):
    """All-systems is the medterm semantic — omit ``system`` entirely."""
    params = _recorded_search_params(category)
    assert "system" not in params
    assert params["query"] == "diabetes"


def test_mt002_search_mode_forwarded():
    params = _recorded_search_params("condition", mode="semantic")
    assert params["searchMode"] == "semantic"


def test_search_batch_loops_over_queries():
    payload = _search_bundle([])
    response = _MockResponse(payload)
    records: list[tuple[str, str, dict]] = []
    adapter = HTTPTerminologyEndpoint("http://localhost:8001/fhir")
    with patch.object(adapter, "_client", return_value=_MockClient(response, records)):
        results = adapter.search_batch([("diabetes", "condition"), ("metformin", "medication")])
    assert len(results) == 2
    assert results[0] == []
    assert results[1] == []
    assert len(records) == 2


# ----------------------------------------------------------------------
# Timeout behavior (INV-6)
# ----------------------------------------------------------------------


def test_client_passes_explicit_timeout():
    """Every httpx.Client constructor must receive a non-None timeout (INV-6)."""
    captured: dict[str, Any] = {}
    adapter = HTTPTerminologyEndpoint("http://localhost:8001/fhir", timeout_seconds=4.5)

    # httpx is imported lazily inside _client(); patch the real httpx
    # module attribute since the adapter no longer keeps it at module
    # top level (lazy-import discipline — see REV-001).
    import httpx as _httpx_mod

    class _ClientShim:
        def __init__(self, client_kwargs: dict[str, Any]) -> None:
            captured.update(client_kwargs)

        def __enter__(self) -> "_ClientShim":
            return self

        def __exit__(self, *args: object) -> None:
            return None

        def get(self, url: str, params: dict | None = None) -> _MockResponse:
            return _MockResponse(_expand_payload([]))

        def post(self, url: str, json: dict | None = None) -> _MockResponse:
            return _MockResponse(_expand_payload([]))

    with patch.object(_httpx_mod, "Client", side_effect=lambda **kwargs: _ClientShim(kwargs)):
        adapter.expand("http://example.org/ValueSet/Foo")

    assert captured.get("timeout") == 4.5
    assert captured.get("timeout") is not None


def test_client_called_with_timeout_kwarg_only():
    """Verify httpx.Client is constructed with keyword timeout= (INV-6)."""
    adapter = HTTPTerminologyEndpoint("http://localhost:8001/fhir", timeout_seconds=2.0)
    import httpx as _httpx_mod

    mock_client = MagicMock()
    mock_client.__enter__.return_value.get.return_value = _MockResponse(_expand_payload([]))
    with patch.object(_httpx_mod, "Client", return_value=mock_client) as mock_factory:
        adapter.expand("http://example.org/ValueSet/Foo")

    mock_factory.assert_called_once_with(timeout=2.0)


# ----------------------------------------------------------------------
# Circuit breaker
# ----------------------------------------------------------------------


class _FailingClient:
    """Client that raises on every request, for breaker failure tests."""

    def __init__(self, records: list[tuple[str, str, dict]]):
        self._records = records

    def __enter__(self) -> "_FailingClient":
        return self

    def __exit__(self, *args: object) -> None:
        return None

    def get(self, url: str, params: dict | None = None) -> _MockResponse:
        self._records.append(("GET", url, params or {}))
        raise RuntimeError("simulated sidecar down")

    def post(self, url: str, json: dict | None = None) -> _MockResponse:
        self._records.append(("POST", url, json or {}))
        raise RuntimeError("simulated sidecar down")


def test_circuit_breaker_starts_closed():
    """Fresh adapter has breaker closed; calls go through to the client."""
    payload = _expand_payload(
        [{"system": "http://snomed.info/sct", "code": "73211009"}]
    )
    response = _MockResponse(payload)
    records: list[tuple[str, str, dict]] = []
    adapter = HTTPTerminologyEndpoint("http://localhost:8001/fhir")
    assert adapter._consecutive_failures == 0
    assert adapter._tripped_until == 0.0
    with patch.object(adapter, "_client", return_value=_MockClient(response, records)):
        refs = adapter.expand("http://example.org/ValueSet/Foo")
    assert len(refs) == 1
    # Success resets counters (they were already 0).
    assert adapter._consecutive_failures == 0
    assert len(records) == 1


def test_circuit_breaker_trips_after_threshold():
    """N consecutive failures trip the breaker."""
    adapter = HTTPTerminologyEndpoint(
        "http://localhost:8001/fhir",
        breaker_threshold=3,
        breaker_cooldown_seconds=60.0,
    )
    records: list[tuple[str, str, dict]] = []
    with patch.object(adapter, "_client", return_value=_FailingClient(records)):
        for _ in range(3):
            with pytest.raises(RuntimeError, match="simulated sidecar down"):
                adapter.expand("http://example.org/ValueSet/Foo")
    # Three failures reach the threshold — breaker should be tripped.
    assert adapter._consecutive_failures == 3
    assert adapter._tripped_until > 0.0
    # All three calls reached the client.
    assert len(records) == 3


def test_circuit_breaker_fast_returns_empty_when_open():
    """Once tripped, expand() returns [] without calling _client."""
    adapter = HTTPTerminologyEndpoint(
        "http://localhost:8001/fhir",
        breaker_threshold=2,
        breaker_cooldown_seconds=60.0,
    )
    records: list[tuple[str, str, dict]] = []
    with patch.object(adapter, "_client", return_value=_FailingClient(records)):
        for _ in range(2):
            with pytest.raises(RuntimeError):
                adapter.expand("http://example.org/ValueSet/Foo")
    assert adapter._tripped_until > 0.0

    # Breaker is now open — a new expand() must short-circuit to []
    # WITHOUT touching the client.
    records_before = len(records)
    refs = adapter.expand("http://example.org/ValueSet/Foo")
    assert refs == []
    assert len(records) == records_before  # no new client call


def test_circuit_breaker_half_open_after_cooldown():
    """After cooldown, one probe call is allowed (half-open)."""
    adapter = HTTPTerminologyEndpoint(
        "http://localhost:8001/fhir",
        breaker_threshold=2,
        breaker_cooldown_seconds=60.0,
    )
    records: list[tuple[str, str, dict]] = []
    with patch.object(adapter, "_client", return_value=_FailingClient(records)):
        for _ in range(2):
            with pytest.raises(RuntimeError):
                adapter.expand("http://example.org/ValueSet/Foo")
    assert adapter._tripped_until > 0.0

    # Force the cooldown to elapse by rewinding the trip timestamp.
    import time as _time

    adapter._tripped_until = _time.monotonic() - 0.001

    # Now a probe call is permitted. Give it a healthy response so the
    # probe succeeds and closes the breaker.
    response = _MockResponse(_expand_payload([]))
    with patch.object(adapter, "_client", return_value=_MockClient(response, records)):
        refs = adapter.expand("http://example.org/ValueSet/Foo")
    assert refs == []
    assert adapter._consecutive_failures == 0  # reset on success
    assert adapter._tripped_until == 0.0


def test_circuit_breaker_resets_on_success():
    """A single success resets the failure counter even before tripping."""
    adapter = HTTPTerminologyEndpoint(
        "http://localhost:8001/fhir",
        breaker_threshold=4,
        breaker_cooldown_seconds=60.0,
    )
    records: list[tuple[str, str, dict]] = []
    # Two failures (below threshold).
    with patch.object(adapter, "_client", return_value=_FailingClient(records)):
        for _ in range(2):
            with pytest.raises(RuntimeError):
                adapter.expand("http://example.org/ValueSet/Foo")
    assert adapter._consecutive_failures == 2

    # A single success resets the counter.
    response = _MockResponse(_expand_payload([]))
    with patch.object(adapter, "_client", return_value=_MockClient(response, records)):
        adapter.expand("http://example.org/ValueSet/Foo")
    assert adapter._consecutive_failures == 0
    assert adapter._tripped_until == 0.0


# ----------------------------------------------------------------------
# Health probe (is_healthy)
# ----------------------------------------------------------------------


class _ProbeMockClient:
    """Mock client used for is_healthy() tests. Records the probe URL."""

    def __init__(self, response: _MockResponse):
        self._response = response
        self.probe_url: str | None = None

    def __enter__(self) -> "_ProbeMockClient":
        return self

    def __exit__(self, *args: object) -> None:
        return None

    def get(self, url: str, params: dict | None = None) -> _MockResponse:
        self.probe_url = url
        return self._response


def test_is_healthy_returns_true_for_200():
    adapter = HTTPTerminologyEndpoint("http://localhost:8001/fhir")
    import httpx as _httpx_mod

    probe_client = _ProbeMockClient(_MockResponse({"resourceType": "CapabilityStatement"}, status_code=200))
    with patch.object(_httpx_mod, "Client", return_value=probe_client):
        assert adapter.is_healthy() is True
    assert probe_client.probe_url == "http://localhost:8001/fhir/metadata"


def test_is_healthy_returns_false_for_500():
    adapter = HTTPTerminologyEndpoint("http://localhost:8001/fhir")
    import httpx as _httpx_mod

    probe_client = _ProbeMockClient(_MockResponse({}, status_code=500))
    with patch.object(_httpx_mod, "Client", return_value=probe_client):
        assert adapter.is_healthy() is False


def test_is_healthy_returns_false_on_timeout():
    adapter = HTTPTerminologyEndpoint("http://localhost:8001/fhir")
    import httpx as _httpx_mod

    class _TimeoutClient:
        def __enter__(self) -> "_TimeoutClient":
            return self

        def __exit__(self, *args: object) -> None:
            return None

        def get(self, url: str, params: dict | None = None) -> _MockResponse:
            raise httpx.ReadTimeout("read timed out")

    with patch.object(_httpx_mod, "Client", return_value=_TimeoutClient()):
        # Must not raise — failure swallowed and reported as False.
        assert adapter.is_healthy() is False


def test_is_healthy_returns_false_on_connection_refused():
    adapter = HTTPTerminologyEndpoint("http://localhost:8001/fhir")
    import httpx as _httpx_mod

    class _ConnRefusedClient:
        def __enter__(self) -> "_ConnRefusedClient":
            return self

        def __exit__(self, *args: object) -> None:
            return None

        def get(self, url: str, params: dict | None = None) -> _MockResponse:
            raise httpx.ConnectError("connection refused")

    with patch.object(_httpx_mod, "Client", return_value=_ConnRefusedClient()):
        assert adapter.is_healthy() is False


# ----------------------------------------------------------------------
# Iteration 5 / Domain 6 HISTORIAN — hierarchical expansions
# ----------------------------------------------------------------------


def test_expand_walks_hierarchical_contains_tree():
    """FHIR R4 expansion.contains.contains (0..*) is recursive.

    A terminology server answers an is-a expansion with a hierarchy
    (ancestors carrying their descendants). A flat walk silently drops every
    descendant, under-reporting membership.
    """
    payload = _expand_payload([
        {
            "system": "http://snomed.info/sct",
            "code": "73211009",
            "display": "Diabetes mellitus",
            "contains": [
                {"system": "http://snomed.info/sct", "code": "44054006",
                 "contains": [
                     {"system": "http://snomed.info/sct", "code": "deep"},
                 ]},
                {"system": "http://snomed.info/sct", "code": "46635009"},
            ],
        },
    ])
    adapter = HTTPTerminologyEndpoint("http://localhost:8001/fhir")
    with patch.object(adapter, "_client", return_value=_MockClient(_MockResponse(payload), [])):
        refs = adapter.expand("http://ex.org/VS/hier")
    assert [r.code for r in refs] == ["73211009", "44054006", "deep", "46635009"]


def test_expand_skips_blank_code_grouping_nodes_in_hierarchy():
    """expansion.contains.code is 0..1 — a grouping header is not a member."""
    payload = _expand_payload([
        {
            "display": "Grouping header",
            "contains": [
                {"system": "http://snomed.info/sct", "code": "real-code"},
            ],
        },
    ])
    adapter = HTTPTerminologyEndpoint("http://localhost:8001/fhir")
    with patch.object(adapter, "_client", return_value=_MockClient(_MockResponse(payload), [])):
        refs = adapter.expand("http://ex.org/VS/grouped")
    assert [r.code for r in refs] == ["real-code"]


# ----------------------------------------------------------------------
# D12 HISTORIAN (v0.0.26, QA-D12H-001/002) — intensional capability parity
# + breaker semantics for capability refusals.
# ----------------------------------------------------------------------


def test_expand_intensional_refused_by_backend_raises_capability_error():
    """A 400/422 on POST $expand must escalate to TerminologyCapabilityError.

    The sidecar maps medterm4ds's intensional-expansion ValueErrors
    (QC-252 unresolvable compose system, QC-246 null code) to HTTP 400,
    and the in-process adapter raises TerminologyCapabilityError for the
    identical refusals (QA-D12S-001). The HTTP surface must match —
    otherwise HTTP callers see a raw httpx.HTTPStatusError and the
    failure counts toward the circuit breaker.
    """
    payload = {
        "resourceType": "OperationOutcome",
        "issue": [{"diagnostics": "unresolvable compose system"}],
    }
    response = _MockResponse(payload, status_code=400)
    adapter = HTTPTerminologyEndpoint("http://localhost:8001/fhir")
    with patch.object(adapter, "_client", return_value=_MockClient(response, [])):
        with pytest.raises(TerminologyCapabilityError) as excinfo:
            adapter.expand_intensional({
                "resourceType": "ValueSet",
                "compose": {"include": [
                    {"system": "http://example.nowhere",
                     "concept": [{"code": "x"}]}]},
            })
    message = str(excinfo.value)
    assert "HTTP 400" in message
    assert "unresolvable compose system" in message  # server diagnostics
    assert "medterm4ds" in message or "compose" in message


def test_expand_capability_refusal_does_not_poison_breaker():
    """Capability refusals are deterministic — they must not trip the breaker.

    The in-process adapter's QA-D12S-001 doctrine: "Capability refusals
    are not faults: they do NOT count toward the circuit breaker." The
    HTTP adapter must match. If 5 refusals trip the breaker, the breaker
    short-circuits subsequent calls to [] — converting the loud
    TerminologyCapabilityError back into the silent empty-membership
    degradation the AMUX-115 ruling exists to prevent.
    """
    payload = {
        "resourceType": "OperationOutcome",
        "issue": [{"diagnostics": "unsupported url form"}],
    }
    response = _MockResponse(payload, status_code=400)
    adapter = HTTPTerminologyEndpoint("http://localhost:8001/fhir")
    with patch.object(adapter, "_client", return_value=_MockClient(response, [])):
        for _ in range(6):  # past breaker_threshold=5
            with pytest.raises(TerminologyCapabilityError):
                adapter.expand("http://example.org/ValueSet/Foo")
    failures, _ = adapter._breaker_snapshot()
    assert failures == 0, (
        "capability refusals must not count toward the circuit breaker "
        f"(got {failures} consecutive failures)"
    )


def test_expand_intensional_capability_refusal_does_not_poison_breaker():
    """Same doctrine on the intensional surface."""
    payload = {
        "resourceType": "OperationOutcome",
        "issue": [{"diagnostics": "unresolvable compose system"}],
    }
    response = _MockResponse(payload, status_code=400)
    adapter = HTTPTerminologyEndpoint("http://localhost:8001/fhir")
    with patch.object(adapter, "_client", return_value=_MockClient(response, [])):
        for _ in range(6):
            with pytest.raises(TerminologyCapabilityError):
                adapter.expand_intensional({"compose": {"include": []}})
    failures, _ = adapter._breaker_snapshot()
    assert failures == 0


def test_expand_transient_failure_still_counts_toward_breaker():
    """Transient 5xx failures keep counting (the breaker still protects)."""
    response = _MockResponse({}, status_code=500)
    adapter = HTTPTerminologyEndpoint("http://localhost:8001/fhir")
    with patch.object(adapter, "_client", return_value=_MockClient(response, [])):
        with pytest.raises(RuntimeError):
            adapter.expand("http://example.org/ValueSet/Foo")
    failures, _ = adapter._breaker_snapshot()
    assert failures == 1


# ----------------------------------------------------------------------
# QA-D12E-001 (v0.0.26 Domain 12 EXPLORER): hostile non-string `system`
# values in an otherwise-valid 200 response must not poison the whole
# expansion/search. `SystemResolver.normalize` raises TypeError on
# non-str input, so ONE malformed contains/entry used to crash the
# entire call (losing every valid code and counting a phantom breaker
# failure). FHIR `system` is `uri` (string) — non-string entries are
# malformed and must be SKIPPED, exactly like missing/None systems.
# ----------------------------------------------------------------------


def test_qa_d12e001_expand_skips_non_string_system_entries():
    """A hostile contains[] entry with a non-string system (int, list)
    is skipped; valid siblings survive and the breaker stays at 0."""
    payload = _expand_payload([
        {"system": "http://snomed.info/sct", "code": "73211009"},
        {"system": 42, "code": "bad-int"},
        {"system": ["http://x"], "code": "bad-list"},
        {"system": True, "code": "bad-bool"},
    ])
    response = _MockResponse(payload)
    adapter = HTTPTerminologyEndpoint("http://localhost:8001/fhir")
    with patch.object(adapter, "_client", return_value=_MockClient(response, [])):
        refs = adapter.expand("http://example.org/ValueSet/Foo")
    assert refs == [CodeRef(
        system="http://snomed.info/sct", code="73211009", display=None
    )]
    failures, _ = adapter._breaker_snapshot()
    assert failures == 0


def test_qa_d12e001_search_skips_non_string_system_entries():
    """Same doctrine on the $search path: one hostile entry resource
    with a non-string system cannot crash the whole query."""
    payload = _search_bundle([
        {"system": 42, "code": "bad"},
        {"system": {"nested": True}, "code": "bad-dict"},
        {"system": "http://loinc.org", "code": "718-7", "display": "Hgb"},
    ])
    response = _MockResponse(payload)
    adapter = HTTPTerminologyEndpoint("http://localhost:8001/fhir")
    with patch.object(adapter, "_client", return_value=_MockClient(response, [])):
        results = adapter.search_text("hemoglobin", "lab")
    assert [r.code for r in results] == ["718-7"]
    failures, _ = adapter._breaker_snapshot()
    assert failures == 0
