"""
DuckDB Extension Registration

Provides the register_fhirpath function to register the FHIRPath UDF
with a DuckDB connection.
"""

from __future__ import annotations

import logging
import orjson
import os
from typing import TYPE_CHECKING

import duckdb

if TYPE_CHECKING:
    pass


# Module-level logger for FHIRPath errors
_logger = logging.getLogger("duckdb_fhirpath")

# Global flag for debug logging (can be set via environment variable)
_DEBUG_LOGGING = os.environ.get("FHIRPATH_DEBUG", "").lower() in ("1", "true", "yes")

_STRICT_MODE = os.environ.get("FHIRPATH_STRICT_MODE") == "1"


def set_debug_logging(enabled: bool) -> None:
    """
    Enable or disable debug logging for FHIRPath evaluation errors.

    When enabled, errors during FHIRPath evaluation are logged at DEBUG level
    instead of being silently swallowed. This is useful for debugging while
    still maintaining FHIRPath's empty collection semantics.

    Args:
        enabled: True to enable debug logging, False to disable.

    Example:
        >>> from fhir4ds.fhirpath.duckdb.extension import set_debug_logging
        >>> set_debug_logging(True)  # Enable debug logging
    """
    global _DEBUG_LOGGING
    _DEBUG_LOGGING = enabled


def is_debug_logging() -> bool:
    """
    Check if debug logging is currently enabled.

    Returns:
        True if debug logging is enabled, False otherwise.
    """
    return _DEBUG_LOGGING


def _bundled_extension_filename() -> str | None:
    """D2 dual-support: pick the bundled binary for the RUNNING DuckDB.

    Extensions are ABI-locked to the DuckDB ``major.minor`` they were
    built against (a 1.5 binary will not load in 2.0 and vice versa), so
    the wheel ships one binary per supported line and this selector maps
    the running version to the right file. Any UNSUPPORTED line (1.4,
    1.6, 2.1, dev builds of unreleased lines) returns None → the caller
    falls back to Python UDFs rather than attempting an ABI-mismatched
    LOAD (FEATURE_DUCKDB2_DUAL_SUPPORT §3.2).

    The 1.5 line is ABI-locked at PATCH level as of 1.5.6 (the v1.5.5
    binary refuses to load in a 1.5.6 client), so the wheel bundles both:
    ``.duckdb_extension`` (v1.5.5 ABI) and ``.duckdb156_extension``
    (v1.5.6 ABI). Unsupported 1.5.x patches (1.5.0-1.5.4, 1.5.7+) keep
    the legacy v1.5.5 selection and fall back on load failure.
    """
    import re

    m = re.match(r"^(\d+)\.(\d+)(?:\.(\d+))?", duckdb.__version__ or "")
    if not m:
        return None
    key = (int(m.group(1)), int(m.group(2)))
    patch = int(m.group(3)) if m.group(3) else None
    if key == (1, 5) and patch == 6:
        return "fhirpath.duckdb156_extension"
    return {
        (1, 5): "fhirpath.duckdb_extension",
        (2, 0): "fhirpath.duckdb2_extension",
    }.get(key)


def _staged_load_path(ext_path: "Path") -> "Path":
    """DuckDB 2.x enforces the `.duckdb_extension` suffix at LOAD.

    The wheel bundles the 2.0 binary as `<name>.duckdb2_extension`
    (distinct suffix so a 1.5-only environment can never LOAD the 2.0
    binary by accident, per D2). DuckDB rejects loading files with any
    other suffix, so stage the bundle into a content-addressed cache
    under the loadable name before LOAD. The cache key is the bundle's
    size+mtime, so a wheel upgrade re-stages automatically.
    """
    import hashlib
    import re
    import tempfile
    from pathlib import Path

    stat = ext_path.stat()
    key = hashlib.sha1(f"{ext_path.name}:{stat.st_size}:{int(stat.st_mtime)}".encode()).hexdigest()[:16]
    # Per-bundle cache DIRECTORY (content-keyed) with the plain loadable
    # filename inside: DuckDB derives the extension entrypoint from the
    # file name, so it must stay `<name>.duckdb_extension`, while the
    # per-bundle directory ensures distinct bundles (unit-test fakes,
    # wheel upgrades) never share a mutable slot — the single-slot design
    # let a later stage overwrite the binary mid-use and segfault the loader.
    cache_dir = Path(tempfile.gettempdir()) / "fhir4ds-ext-cache" / key
    cache_dir.mkdir(parents=True, exist_ok=True)
    staged = cache_dir / re.sub(r"\.duckdb[0-9]*_extension$", ".duckdb_extension", ext_path.name)
    if not staged.exists() or staged.stat().st_size != stat.st_size:
        staged.write_bytes(ext_path.read_bytes())
    return staged


def _try_load_bundled_cpp_extension(con: "duckdb.DuckDBPyConnection") -> bool:
    """
    Try to load the compiled C++ FHIRPath extension bundled inside this wheel.

    The build hook (hatch_build.py) copies `fhirpath.duckdb_extension` into
    ``duckdb_fhirpath_py/extensions/`` at wheel-build time when the compiled
    binary is available.  At runtime this function checks for that file and
    loads it via DuckDB's native extension mechanism.

    Note: Development builds of the extension are unsigned. To load them,
    create your DuckDB connection with::

        con = duckdb.connect(config={"allow_unsigned_extensions": True})

    Production releases will be signed and load without this config.

    Returns True if the C++ extension was loaded, False otherwise.
    """
    # D2 dual-support: select the binary for the RUNNING DuckDB line
    # (extensions are ABI-locked to major.minor). Unsupported lines and
    # missing bundles fall back to Python UDFs; a strict mode (env
    # FHIR4DS_REQUIRE_CPP=1) turns the missing-bundle case into a loud
    # error for wheel installs that need the native engine.
    from pathlib import Path

    _duckdb_version = duckdb.__version__
    filename = _bundled_extension_filename()
    if filename is None:
        msg = (
            "fhir4ds C++ extension unavailable for DuckDB %s: this build "
            "bundles binaries for the 1.5.x and 2.0.x lines only, so the "
            "Python UDF fallback will be used. Install a fhir4ds build "
            "matching your DuckDB line (extras: fhir4ds-v2[duckdb1] for "
            "1.5.x, fhir4ds-v2[duckdb2] for 2.0.x on Python >= 3.11) or run "
            "a supported DuckDB version."
        ) % _duckdb_version
        # Strict mode covers BOTH failure shapes (unsupported DuckDB line and
        # missing/mismatched bundle file); see the CQL twin.
        if os.environ.get("FHIR4DS_REQUIRE_CPP") == "1":
            raise RuntimeError(msg)
        _logger.info("duckdb_fhirpath_py: %s", msg)
        return False

    ext_path = Path(__file__).parent / "extensions" / filename
    if not ext_path.exists():
        msg = (
            "fhir4ds C++ extension bundle mismatch: SUPPORTED RANGE "
            "DuckDB 1.5.x / 2.0.x, DETECTED DuckDB %s — this install does "
            "not bundle the %s binary for the detected version. The Python "
            "UDF fallback will be used. To get the native engine, install "
            "a fhir4ds build matching your DuckDB version (extras: "
            "fhir4ds-v2[duckdb1] for the 1.5.x line, fhir4ds-v2[duckdb2] "
            "for the 2.0.x line on Python >= 3.11), or set "
            "FHIR4DS_REQUIRE_CPP=1 to make this mismatch fatal."
        ) % (_duckdb_version, filename)
        if os.environ.get("FHIR4DS_REQUIRE_CPP") == "1":
            raise RuntimeError(msg)
        _logger.warning("%s: %s", "duckdb_fhirpath_py", msg)
        return False

    # duckdb 2.x Python client requires pytz for TIMESTAMPTZ rendering.
    if _duckdb_version.startswith("2."):
        try:
            import pytz  # noqa: F401
        except ImportError:
            _logger.warning(
                "duckdb_fhirpath_py: DuckDB %s detected but pytz is not installed — "
                "TIMESTAMPTZ rendering will fail on direct timestamp "
                "columns. Fix: pip install fhir4ds-v2[duckdb2] (or pytz).",
                _duckdb_version,
            )
    # Version-suffixed bundles (`.duckdb2_extension`, `.duckdb156_extension`)
    # are staged into the loadable `.duckdb_extension` name before LOAD.
    import re
    if re.search(r"\.duckdb[0-9]+_extension$", ext_path.name):
        try:
            ext_path = _staged_load_path(ext_path)
        except OSError as exc:
            _logger.warning("duckdb_py: failed to stage 2.0 bundle for load: %s", exc)
            return False

    try:
        escaped_path = str(ext_path).replace("'", "''")
        con.execute(f"LOAD '{escaped_path}'")
        _logger.debug("duckdb_fhirpath_py: loaded bundled C++ extension from %s", ext_path)
        return True
    except duckdb.Error as exc:
        msg = str(exc)
        if "already loaded" in msg.lower():
            _logger.debug("duckdb_fhirpath_py: C++ extension already loaded")
            return True
        if "unsigned" in msg or "signature" in msg:
            # The setting cannot be flipped after the database is running
            # (DuckDB rejects `SET allow_unsigned_extensions` mid-session with
            # "Cannot change allow_unsigned_extensions setting while database
            # is running"), so there is no in-session retry: the connection
            # must be created with the config up front.
            _logger.warning(
                "duckdb_fhirpath_py: bundled C++ extension is an unsigned dev "
                "build and cannot be loaded on this connection. Reconnect with "
                "duckdb.connect(config={'allow_unsigned_extensions': True}) "
                "(or fhir4ds.create_connection(), which sets it by default) to enable "
                "the native engine. Falling back to Python UDFs."
            )
        else:
            _logger.warning("duckdb_fhirpath_py: failed to load bundled C++ extension: %s", exc)
        return False
    except OSError as exc:
        _logger.debug("duckdb_fhirpath_py: OS error loading C++ extension: %s", exc)
        return False


def _function_exists(con: "duckdb.DuckDBPyConnection", name: str) -> bool:
    """Return True when a function with *name* exists in the connection."""
    try:
        row = con.execute(
            "SELECT COUNT(*) FROM duckdb_functions() WHERE lower(function_name) = lower(?)",
            [name],
        ).fetchall()
        # DuckDB 2.0: parameterized results stay open after fetchone(),
        # blocking create_function (ResourceInUse). Fully DRAINING the
        # result closes it (1.5-equivalent).
        return bool(row) and row[0][0] > 0
    except duckdb.Error:
        return False


def _is_cpp_extension_loaded(con: "duckdb.DuckDBPyConnection") -> bool:
    """Detect the bundled FHIRPath C++ extension without attempting to load it."""
    # fhirpath_predicate is registered by the C++ extension and not by the
    # Python fallback, making it a reliable signal for status reporting.
    return _function_exists(con, "fhirpath_predicate")


def register_fhirpath(con: duckdb.DuckDBPyConnection) -> bool:
    """
    Register the fhirpath UDF with a DuckDB connection.

    Attempts to load a bundled compiled C++ extension for maximum performance.
    Falls back to vectorised Python UDFs when the C++ binary is not present.

    This function registers a UDF that evaluates FHIRPath expressions
    against FHIR resources stored as JSON strings.

    Args:
        con: A DuckDB connection object.

    Returns:
        True when the bundled C++ extension is active, False when Python UDFs
        were registered or reused.

    Example:
        >>> import duckdb
        >>> from fhir4ds.fhirpath.duckdb import register_fhirpath
        >>> con = duckdb.connect()
        >>> register_fhirpath(con)
        >>> result = con.execute(
        ...     "SELECT fhirpath('{\"resourceType\":\"Patient\",\"id\":\"123\"}', 'id')"
        ... ).fetchone()
        >>> print(result)
        (['123'],)

    Note:
        The resource parameter accepts JSON strings representing FHIR resources.
        Returns a list of matching values following FHIRPath collection semantics.
    """
    if _is_cpp_extension_loaded(con):
        return True

    # Idempotency guard: if fhirpath UDF already exists, skip registration.
    try:
        con.execute("SELECT fhirpath(NULL, 'id')").fetchone()
        return _is_cpp_extension_loaded(con)
    except duckdb.Error:
        pass  # not yet registered, proceed

    cpp_conflicts = [
        name for name in (
            "fhirpath",
            "fhirpath_bool",
            "fhirpath_date",
            "fhirpath_json",
            "fhirpath_number",
            "fhirpath_quantity",
            "fhirpath_repeat",
            "fhirpath_text",
            "fhirpath_timestamp",
        )
        if _function_exists(con, name)
    ]

    # Try the bundled C++ extension first, unless a user-defined function would
    # make DuckDB's extension initialization fail with a catalog conflict.
    if cpp_conflicts:
        _logger.debug(
            "Skipping bundled FHIRPath C++ extension because functions already exist: %s",
            ", ".join(cpp_conflicts),
        )
    elif _try_load_bundled_cpp_extension(con):
        return True

    def _safe_create_function(name: str, function, *args, **kwargs) -> None:
        """Register a Python UDF unless the name already exists on this connection."""
        try:
            con.create_function(name, function, *args, **kwargs)
        except (
            duckdb.CatalogException,
            duckdb.InvalidInputException,
            duckdb.NotImplementedException,
        ) as exc:
            _logger.debug("Skipping FHIRPath UDF %s registration: %s", name, exc)

    # Register Tier 1 SQL macros first (zero Python overhead)
    from .macros import register_all_macros
    try:
        register_all_macros(con)
    except (
        duckdb.CatalogException,
        duckdb.InvalidInputException,
        duckdb.NotImplementedException,
        duckdb.BinderException,
    ) as exc:
        _logger.debug("Skipping FHIRPath SQL macro registration: %s", exc)

    from .evaluator import FHIRPathEvaluator
    from .udf import (
        fhirpath_scalar,
        fhirpath_is_valid_udf,
        _get_compiled_evaluator,
    )

    # Register the main fhirpath UDF (delegates to shared implementation in udf.py)
    _safe_create_function(
        "fhirpath",
        fhirpath_scalar,
        return_type="VARCHAR[]",
    )

    # Register validation function
    _safe_create_function(
        "fhirpath_is_valid",
        fhirpath_is_valid_udf,
    )

    # Import convenience UDFs
    from .udf import (
        fhirpath_bool_udf,
        fhirpath_date_udf,
        fhirpath_json_udf,
        fhirpath_number_udf,
        fhirpath_text_udf,
        fhirpath_timestamp_udf,
        fhirpath_quantity_udf,
    )

    # Register convenience UDFs with SPECIAL null handling
    # This allows the UDFs to return NULL values when appropriate
    # (e.g., when a FHIRPath doesn't match any values)
    _safe_create_function(
        "fhirpath_text",
        fhirpath_text_udf,
        null_handling="special",
    )

    _safe_create_function(
        "fhirpath_bool",
        fhirpath_bool_udf,
        null_handling="special",
    )

    _safe_create_function(
        "fhirpath_number",
        fhirpath_number_udf,
        null_handling="special",
    )

    _safe_create_function(
        "fhirpath_date",
        fhirpath_date_udf,
        null_handling="special",
    )

    _safe_create_function(
        "fhirpath_json",
        fhirpath_json_udf,
        null_handling="special",
    )

    _safe_create_function(
        "fhirpath_timestamp",
        fhirpath_timestamp_udf,
        null_handling="special",
    )

    _safe_create_function(
        "fhirpath_quantity",
        fhirpath_quantity_udf,
        null_handling="special",
    )

    # Register repeat traversal UDF for SQL-on-FHIR v2 ``repeat`` directive
    from .udf import fhirpath_repeat_udf
    _safe_create_function(
        "fhirpath_repeat",
        fhirpath_repeat_udf,
        return_type="VARCHAR[]",
        null_handling="special",
    )
    return False
