"""Terminology subpackage unit tests."""
