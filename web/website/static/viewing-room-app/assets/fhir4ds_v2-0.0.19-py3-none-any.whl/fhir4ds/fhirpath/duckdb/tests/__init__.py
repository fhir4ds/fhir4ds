"""Tests for duckdb-fhirpath."""
