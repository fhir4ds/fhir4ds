"""Serialize typed CQL evaluation results to FHIR R4 Parameters."""

from __future__ import annotations

import json
from decimal import Decimal
from typing import Any

from .parameters import empty_list_parameter, empty_tuple_parameter, null_parameter
from .types import (
    CQF_CQL_TYPE_URL,
    CQLEvaluationResult,
    CQLFacadeError,
    CQLResultMetadata,
    CQLTypeRef,
    CQLErrorCategory,
    FHIR_PARAMETERS,
    RETURN_PARAMETER,
    json_number,
)


def serialize_evaluation_result(result: CQLEvaluationResult) -> dict[str, Any]:
    """Return a FHIR Parameters response for an evaluated CQL expression."""
    params = serialize_value(RETURN_PARAMETER, result.value, result.metadata.type_ref, result.metadata)
    return {"resourceType": FHIR_PARAMETERS, "parameter": params}


def serialize_value(
    name: str,
    value: Any,
    type_ref: CQLTypeRef,
    metadata: CQLResultMetadata | None = None,
) -> list[dict[str, Any]]:
    """Serialize one CQL value as one or more Parameters.parameter entries."""
    bare = type_ref.bare_name
    if value is None:
        return [null_parameter(name)]
    if bare == "List":
        values = _as_python_list(value)
        if not values:
            return [empty_list_parameter(name, metadata.cql_type if metadata else type_ref.canonical())]
        result: list[dict[str, Any]] = []
        for item in values:
            if type_ref.element_type.bare_name == "List":
                result.append(
                    {
                        "name": name,
                        "part": [
                            part
                            for nested in serialize_value(
                                "element",
                                item,
                                type_ref.element_type,
                                metadata,
                            )
                            for part in [nested]
                        ],
                    }
                )
            else:
                result.extend(serialize_value(name, item, type_ref.element_type, metadata))
        return result
    if bare == "Tuple":
        obj = _as_json_object(value)
        if not obj:
            return [empty_tuple_parameter(name, metadata.cql_type if metadata else type_ref.canonical())]
        fields = dict(type_ref.fields)
        parts = []
        for field_name, field_value in obj.items():
            field_type = fields.get(field_name, CQLTypeRef.parse("Any"))
            parts.extend(serialize_value(field_name, field_value, field_type, metadata))
        return [{"name": name, "part": parts}]
    return [_serialize_scalar(name, value, type_ref, metadata)]


def _serialize_scalar(
    name: str,
    value: Any,
    type_ref: CQLTypeRef,
    metadata: CQLResultMetadata | None,
) -> dict[str, Any]:
    bare = type_ref.bare_name
    if bare == "Any":
        inferred = _infer_runtime_type(value)
        if inferred != "Any":
            return _serialize_scalar(name, value, CQLTypeRef.parse(inferred), metadata)
        raise CQLFacadeError(
            "Cannot serialize CQL result with unknown CQL type metadata",
            category=CQLErrorCategory.SERIALIZER_GAP,
            status_code=200,
        )
    if bare == "Boolean":
        return {"name": name, "valueBoolean": bool(value)}
    if bare == "Integer":
        return {"name": name, "valueInteger": int(value)}
    if bare == "Long":
        return _with_cql_type({"name": name, "valueDecimal": json_number(value)}, "System.Long")
    if bare == "Decimal":
        return {"name": name, "valueDecimal": json_number(value)}
    if bare == "String":
        return {"name": name, "valueString": str(value)}
    if bare == "Date":
        return {"name": name, "valueDate": _strip_temporal_marker(value, "Date")}
    if bare == "DateTime":
        return {"name": name, "valueDateTime": _strip_temporal_marker(value, "DateTime")}
    if bare == "Time":
        return {"name": name, "valueTime": _strip_temporal_marker(value, "Time")}
    if bare == "Quantity":
        return {"name": name, "valueQuantity": _quantity_to_fhir(value)}
    if bare == "Ratio":
        return {"name": name, "valueRatio": _ratio_to_fhir(value)}
    if bare == "Code":
        return {"name": name, "valueCoding": _code_to_fhir(value)}
    if bare == "Concept":
        return {"name": name, "valueCodeableConcept": _concept_to_fhir(value)}
    if bare == "Interval":
        return _interval_to_fhir(name, value, type_ref)
    raise CQLFacadeError(
        f"Cannot serialize unsupported CQL result type {type_ref.canonical()}",
        category=CQLErrorCategory.SERIALIZER_GAP,
        status_code=200,
    )


def _interval_to_fhir(name: str, value: Any, type_ref: CQLTypeRef) -> dict[str, Any]:
    interval = _as_json_object(value)
    low_closed = bool(interval.get("lowClosed", True))
    high_closed = bool(interval.get("highClosed", True))
    if (interval.get("low") is not None and not low_closed) or (
        interval.get("high") is not None and not high_closed
    ):
        raise CQLFacadeError(
            "Open bounded CQL intervals cannot be represented faithfully with runner FHIR Range/Period extraction",
            category=CQLErrorCategory.SERIALIZER_GAP,
            status_code=200,
        )
    point = type_ref.point_type.bare_name
    if point in {"Date", "DateTime", "Time", "Any"}:
        period: dict[str, Any] = {}
        if interval.get("low") is not None:
            period["start"] = _format_interval_temporal(interval["low"], point)
        if interval.get("high") is not None:
            period["end"] = _format_interval_temporal(interval["high"], point)
        return _with_cql_type({"name": name, "valuePeriod": period}, type_ref.canonical())
    if point in {"Quantity", "Integer", "Decimal", "Long"}:
        range_value: dict[str, Any] = {}
        if interval.get("low") is not None:
            range_value["low"] = _interval_bound_quantity(interval["low"], point)
        if interval.get("high") is not None:
            range_value["high"] = _interval_bound_quantity(interval["high"], point)
        return _with_cql_type({"name": name, "valueRange": range_value}, type_ref.canonical())
    raise CQLFacadeError(
        f"Cannot serialize Interval<{point}> to runner-compatible FHIR",
        category=CQLErrorCategory.SERIALIZER_GAP,
        status_code=200,
    )


def _quantity_to_fhir(value: Any) -> dict[str, Any]:
    obj = _as_json_object(value)
    if "value" not in obj:
        raise CQLFacadeError(
            "CQL Quantity result is missing value",
            category=CQLErrorCategory.SERIALIZER_GAP,
            status_code=200,
        )
    unit = obj.get("code", obj.get("unit", "1"))
    result = {
        "value": json_number(obj["value"]),
        "unit": obj.get("unit", unit),
        "system": obj.get("system", "http://unitsofmeasure.org"),
        "code": unit,
    }
    return {k: v for k, v in result.items() if v is not None}


def _ratio_to_fhir(value: Any) -> dict[str, Any]:
    obj = _as_json_object(value)
    return {
        "numerator": _quantity_to_fhir(obj.get("numerator")),
        "denominator": _quantity_to_fhir(obj.get("denominator")),
    }


def _code_to_fhir(value: Any) -> dict[str, Any]:
    obj = _as_json_object(value)
    result = {
        "system": obj.get("system"),
        "code": obj.get("code"),
        "display": obj.get("display"),
        "version": obj.get("version"),
    }
    return {k: v for k, v in result.items() if v is not None}


def _concept_to_fhir(value: Any) -> dict[str, Any]:
    obj = _as_json_object(value)
    codings = obj.get("coding", obj.get("codes", []))
    result: dict[str, Any] = {"coding": [_code_to_fhir(code) for code in codings]}
    display = obj.get("display", obj.get("text"))
    if display is not None:
        result["text"] = display
    return result


def _interval_bound_quantity(value: Any, point_type: str) -> dict[str, Any]:
    if point_type == "Quantity":
        return _quantity_to_fhir(value)
    return {
        "value": json_number(_coerce_number(value)),
        "unit": "1",
        "system": "http://unitsofmeasure.org",
        "code": "1",
    }


def _format_interval_temporal(value: Any, point_type: str) -> str:
    text = str(value)
    if point_type == "Time" and not text.startswith("T"):
        return f"T{text}"
    return text[1:] if text.startswith("@") else text


def _strip_temporal_marker(value: Any, type_name: str) -> str:
    text = str(value)
    if text.startswith("@"):
        text = text[1:]
    if type_name == "Time" and text.startswith("T"):
        text = text[1:]
    if type_name == "DateTime" and text.startswith("T"):
        return text
    return text


def _as_json_object(value: Any) -> dict[str, Any]:
    if isinstance(value, dict):
        return value
    if isinstance(value, str):
        try:
            parsed = json.loads(value)
        except json.JSONDecodeError as exc:
            raise CQLFacadeError(
                "CQL result value is not valid JSON for its semantic type",
                category=CQLErrorCategory.SERIALIZER_GAP,
                status_code=200,
            ) from exc
        if isinstance(parsed, dict):
            return parsed
    raise CQLFacadeError(
        "CQL result value is not a JSON object for its semantic type",
        category=CQLErrorCategory.SERIALIZER_GAP,
        status_code=200,
    )


def _as_python_list(value: Any) -> list[Any]:
    if isinstance(value, list):
        return value
    if isinstance(value, tuple):
        return list(value)
    if isinstance(value, str):
        try:
            parsed = json.loads(value)
        except json.JSONDecodeError as exc:
            raise CQLFacadeError(
                "CQL result value is not valid JSON for List<T> metadata",
                category=CQLErrorCategory.SERIALIZER_GAP,
                status_code=200,
            ) from exc
        if isinstance(parsed, list):
            return parsed
    raise CQLFacadeError(
        "CQL result value is not a list for List<T> metadata",
        category=CQLErrorCategory.SERIALIZER_GAP,
        status_code=200,
    )


def _with_cql_type(param: dict[str, Any], cql_type: str) -> dict[str, Any]:
    param.setdefault("extension", []).append({"url": CQF_CQL_TYPE_URL, "valueString": cql_type})
    return param


def _coerce_number(value: Any) -> int | float | Decimal:
    if isinstance(value, (int, float, Decimal)) and not isinstance(value, bool):
        return value
    return Decimal(str(value))


def _infer_runtime_type(value: Any) -> str:
    if isinstance(value, bool):
        return "Boolean"
    if isinstance(value, int):
        return "Integer"
    if isinstance(value, (float, Decimal)):
        return "Decimal"
    if isinstance(value, str):
        stripped = value.strip()
        if stripped.startswith("{") and stripped.endswith("}"):
            try:
                obj = json.loads(stripped)
            except json.JSONDecodeError:
                return "String"
            if isinstance(obj, dict):
                if {"low", "high", "lowClosed", "highClosed"} & set(obj):
                    return "Interval<Any>"
                if "codes" in obj or "coding" in obj:
                    return "Concept"
                if "code" in obj and "system" in obj:
                    return "Code"
                if "numerator" in obj and "denominator" in obj:
                    return "Ratio"
                if "value" in obj and ("unit" in obj or "code" in obj):
                    return "Quantity"
                return "Tuple"
        return "String"
    if isinstance(value, list):
        return "List<Any>"
    if isinstance(value, dict):
        return "Tuple"
    return "Any"
