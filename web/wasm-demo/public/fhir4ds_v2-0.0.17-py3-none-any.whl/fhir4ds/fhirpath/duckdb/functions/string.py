"""
FHIRPath String Functions

Implements string manipulation functions defined in the FHIRPath specification.

Key FHIRPath semantics:
- String functions on empty collection return empty collection
- Most functions work on singleton string values
- The & operator converts null/empty to empty string for concatenation

Reference: https://hl7.org/fhirpath/#string-manipulation
"""

from __future__ import annotations

from functools import lru_cache
import re
from typing import TYPE_CHECKING, Any

from ..collection import FHIRPathCollection, EMPTY, wrap_as_collection
from ..errors import FHIRPathFunctionError

if TYPE_CHECKING:
    pass

_MAX_REGEX_LENGTH = 1000
_REDOS_PATTERNS = re.compile(
    r"(\((?:[^()]*[+*])[^()]*\)[+*])"
    r"|(\([^()]*\|[^()]*\)[+*])"
)


def _validate_regex(pattern: str, func_name: str) -> None:
    if len(pattern) > _MAX_REGEX_LENGTH:
        raise FHIRPathFunctionError(
            func_name,
            f"Regex pattern too long ({len(pattern)} chars, max {_MAX_REGEX_LENGTH})"
        )
    if _REDOS_PATTERNS.search(pattern):
        raise FHIRPathFunctionError(
            func_name,
            "Regex pattern contains nested quantifiers or quantified alternations"
        )


def _regex_flags(flags: str = "", func_name: str = "matches") -> int:
    invalid = sorted({ch for ch in flags if ch not in {"i", "m"}})
    if invalid:
        raise FHIRPathFunctionError(func_name, f"Invalid regex flags: {''.join(invalid)}")
    compiled_flags = re.DOTALL
    if "i" in flags:
        compiled_flags |= re.IGNORECASE
    if "m" in flags:
        compiled_flags |= re.MULTILINE
    return compiled_flags


@lru_cache(maxsize=256)
def _compile_regex(pattern: str, flags: int = 0) -> re.Pattern[str]:
    return re.compile(pattern, flags)


def _get_singleton_string(collection: FHIRPathCollection, func_name: str) -> str | None:
    """
    Extract singleton string value from collection.

    Args:
        collection: Input collection
        func_name: Function name for error messages

    Returns:
        String value if singleton, None if empty

    Raises:
        FHIRPathFunctionError: If collection has multiple elements or non-string value
    """
    if collection.is_empty:
        return None
    if not collection.is_singleton:
        raise FHIRPathFunctionError(
            func_name,
            f"Expected singleton collection, got {len(collection)} elements"
        )
    value = collection.singleton_value
    if value is None:
        return None
    if not isinstance(value, str):
        raise FHIRPathFunctionError(
            func_name,
            f"Expected string value, got {type(value).__name__}"
        )
    return value


def _string_result(value: str | None) -> FHIRPathCollection:
    """
    Wrap string result in collection, returning empty for None.

    Args:
        value: String value or None

    Returns:
        Collection with string or empty collection
    """
    if value is None:
        return FHIRPathCollection([])
    return FHIRPathCollection([value])


def _bool_result(value: bool | None) -> FHIRPathCollection:
    """
    Wrap boolean result in collection, returning empty for None.

    Args:
        value: Boolean value or None

    Returns:
        Collection with boolean or empty collection
    """
    if value is None:
        return FHIRPathCollection([])
    return FHIRPathCollection([value])


# =============================================================================
# Length and Substring Functions
# =============================================================================


def length(collection: FHIRPathCollection) -> FHIRPathCollection:
    """
    Returns the length of the input string.

    If the input collection is empty, the result is empty.
    If the input collection contains multiple items, an error is raised.

    FHIRPath: length() : integer

    Args:
        collection: A collection containing a single string

    Returns:
        Collection containing the length of the string

    Example:
        >>> length(FHIRPathCollection(['hello']))
        FHIRPathCollection([5])
        >>> length(FHIRPathCollection([]))
        FHIRPathCollection({})
    """
    value = _get_singleton_string(collection, "length")
    if value is None:
        return FHIRPathCollection([])
    return FHIRPathCollection([len(value)])


def index_of(collection: FHIRPathCollection, substring_val: str | None) -> FHIRPathCollection:
    """
    Returns the 0-based index of the first position substring_val is found
    in the input string, or -1 if it is not found.

    If substring_val is an empty string (''), the function returns 0.
    If the input or substring_val argument is empty (None here), the result
    is empty.

    FHIRPath: indexOf(substring : string) : integer

    Args:
        collection: A collection containing a single string
        substring_val: The substring to search for, or None for an empty
            argument collection

    Returns:
        Collection containing the 0-based index, or empty if input or
        argument is empty

    Example:
        >>> index_of(FHIRPathCollection(['abcdefg']), 'bc')
        FHIRPathCollection([1])
        >>> index_of(FHIRPathCollection(['abcdefg']), 'x')
        FHIRPathCollection([-1])
        >>> index_of(FHIRPathCollection(['abcdefg']), '')
        FHIRPathCollection([0])
    """
    value = _get_singleton_string(collection, "indexOf")
    if value is None or substring_val is None:
        return FHIRPathCollection([])
    return FHIRPathCollection([value.find(substring_val)])


def substring(
    collection: FHIRPathCollection,
    start: int,
    length_val: int | None = None
) -> FHIRPathCollection:
    """
    Returns the part of the string starting at position start (0-based).

    If start is less than 0 or greater than the length of the string,
    the result is empty. If length is provided, at most that many characters
    are returned.

    FHIRPath:
        substring(start : integer) : string
        substring(start : integer, length : integer) : string

    Args:
        collection: A collection containing a single string
        start: Starting position (0-based)
        length_val: Optional maximum number of characters to return

    Returns:
        Collection containing the substring

    Example:
        >>> substring(FHIRPathCollection(['hello']), 1)
        FHIRPathCollection(['ello'])
        >>> substring(FHIRPathCollection(['hello']), 1, 2)
        FHIRPathCollection(['el'])
        >>> substring(FHIRPathCollection(['hello']), 10)
        FHIRPathCollection({})
    """
    value = _get_singleton_string(collection, "substring")
    if value is None:
        return FHIRPathCollection([])

    # Engine parity: empty start argument (empty collection) -> empty result
    if start is None:
        return FHIRPathCollection([])

    # Validate start index
    if start < 0 or start >= len(value):
        return FHIRPathCollection([])

    if length_val is None:
        return _string_result(value[start:])
    else:
        # Engine parity (§5.6.2): a negative or zero length returns the empty
        # STRING, not an empty collection (both core evaluator and native
        # fn_substring return '' for length <= 0).
        if length_val <= 0:
            return _string_result("")
        return _string_result(value[start:start + length_val])


# =============================================================================
# Prefix/Suffix Functions
# =============================================================================


def _validate_string_arg(value: object, func_name: str, arg_name: str) -> str | None:
    """Validate a FHIRPath String function argument (engine-contract parity).

    The engine paths (core evaluator and native extension) treat an empty
    argument collection as "argument is empty" and reject non-String
    singleton arguments with a typed error. Direct helpers must follow the
    same contract instead of raising raw TypeError.

    Returns None when the argument collection is empty (the function result
    is an empty collection); otherwise the validated String.
    """
    if value is None:
        return None
    if not isinstance(value, str):
        raise FHIRPathFunctionError(
            func_name,
            f"Expected String {arg_name} argument, got {type(value).__name__}",
        )
    return value


def starts_with(collection: FHIRPathCollection, prefix: str) -> FHIRPathCollection:
    """
    Returns true if the string starts with the given prefix.

    FHIRPath: startsWith(prefix : string) : boolean

    Args:
        collection: A collection containing a single string
        prefix: The prefix to check for

    Returns:
        Collection containing true or false, or empty if input is empty

    Example:
        >>> starts_with(FHIRPathCollection(['hello']), 'he')
        FHIRPathCollection([True])
        >>> starts_with(FHIRPathCollection(['hello']), 'xy')
        FHIRPathCollection([False])
    """
    value = _get_singleton_string(collection, "startsWith")
    if value is None:
        return FHIRPathCollection([])
    prefix = _validate_string_arg(prefix, "startsWith", "prefix")
    if prefix is None:
        return FHIRPathCollection([])
    return _bool_result(value.startswith(prefix))


def ends_with(collection: FHIRPathCollection, suffix: str) -> FHIRPathCollection:
    """
    Returns true if the string ends with the given suffix.

    FHIRPath: endsWith(suffix : string) : boolean

    Args:
        collection: A collection containing a single string
        suffix: The suffix to check for

    Returns:
        Collection containing true or false, or empty if input is empty

    Example:
        >>> ends_with(FHIRPathCollection(['hello']), 'lo')
        FHIRPathCollection([True])
        >>> ends_with(FHIRPathCollection(['hello']), 'xy')
        FHIRPathCollection([False])
    """
    value = _get_singleton_string(collection, "endsWith")
    if value is None:
        return FHIRPathCollection([])
    suffix = _validate_string_arg(suffix, "endsWith", "suffix")
    if suffix is None:
        return FHIRPathCollection([])
    return _bool_result(value.endswith(suffix))


# =============================================================================
# Contains and Case Functions
# =============================================================================


def contains(collection: FHIRPathCollection, substring_val: str) -> FHIRPathCollection:
    """
    Returns true if the string contains the given substring.

    FHIRPath: contains(substring : string) : boolean

    Args:
        collection: A collection containing a single string
        substring_val: The substring to search for

    Returns:
        Collection containing true or false, or empty if input is empty

    Example:
        >>> contains(FHIRPathCollection(['hello world']), 'world')
        FHIRPathCollection([True])
        >>> contains(FHIRPathCollection(['hello world']), 'xyz')
        FHIRPathCollection([False])
    """
    value = _get_singleton_string(collection, "contains")
    if value is None:
        return FHIRPathCollection([])
    substring_val = _validate_string_arg(substring_val, "contains", "substring")
    if substring_val is None:
        return FHIRPathCollection([])
    return _bool_result(substring_val in value)


def upper(collection: FHIRPathCollection) -> FHIRPathCollection:
    """
    Returns the string with all characters converted to uppercase.

    FHIRPath: upper() : string

    Args:
        collection: A collection containing a single string

    Returns:
        Collection containing the uppercase string, or empty if input is empty

    Example:
        >>> upper(FHIRPathCollection(['hello']))
        FHIRPathCollection(['HELLO'])
    """
    value = _get_singleton_string(collection, "upper")
    if value is None:
        return FHIRPathCollection([])
    return _string_result(value.upper())


def lower(collection: FHIRPathCollection) -> FHIRPathCollection:
    """
    Returns the string with all characters converted to lowercase.

    FHIRPath: lower() : string

    Args:
        collection: A collection containing a single string

    Returns:
        Collection containing the lowercase string, or empty if input is empty

    Example:
        >>> lower(FHIRPathCollection(['HELLO']))
        FHIRPathCollection(['hello'])
    """
    value = _get_singleton_string(collection, "lower")
    if value is None:
        return FHIRPathCollection([])
    return _string_result(value.lower())


# =============================================================================
# Replace and Regex Functions
# =============================================================================


def replace(
    collection: FHIRPathCollection,
    pattern: str,
    replacement: str
) -> FHIRPathCollection:
    """
    Returns a string with all occurrences of pattern replaced with replacement.

    This is a simple string replacement, not regex-based.

    FHIRPath: replace(pattern : string, replacement : string) : string

    Args:
        collection: A collection containing a single string
        pattern: The substring pattern to replace
        replacement: The replacement string

    Returns:
        Collection containing the string with replacements, or empty if input is empty

    Example:
        >>> replace(FHIRPathCollection(['hello world']), 'world', 'universe')
        FHIRPathCollection(['hello universe'])
    """
    value = _get_singleton_string(collection, "replace")
    if value is None:
        return FHIRPathCollection([])
    pattern = _validate_string_arg(pattern, "replace", "pattern")
    if pattern is None:
        return FHIRPathCollection([])
    replacement = _validate_string_arg(replacement, "replace", "replacement")
    if replacement is None:
        return FHIRPathCollection([])
    return _string_result(value.replace(pattern, replacement))


def matches(collection: FHIRPathCollection, regex: str, flags: str = "") -> FHIRPathCollection:
    """
    Returns true if the string matches the given regular expression.

    FHIRPath: matches(regex : string) : boolean

    Args:
        collection: A collection containing a single string
        regex: The regular expression pattern (Python regex syntax)

    Returns:
        Collection containing true or false, or empty if input is empty

    Example:
        >>> matches(FHIRPathCollection(['123']), r'\\d+')
        FHIRPathCollection([True])
        >>> matches(FHIRPathCollection(['hello123']), r'\\d+')
        FHIRPathCollection([True])
    """
    value = _get_singleton_string(collection, "matches")
    if value is None:
        return FHIRPathCollection([])
    # FP-10 HISTORIAN QA-002: None regex -> empty result (sibling-helper
    # contract); non-String regex -> typed FHIRPathFunctionError.
    if regex is None:
        return FHIRPathCollection([])
    _validate_regex(_validate_string_arg(regex, "matches", "regex"), "matches")
    from ...engine.invocations.strings import (
        _translate_named_groups,
        _translate_pcre_ascii_classes,
    )

    try:
        result = (
            _compile_regex(
                _translate_named_groups(_translate_pcre_ascii_classes(regex)),
                _regex_flags(flags, "matches"),
            ).search(value)
            is not None
        )
        return _bool_result(result)
    except re.error as e:
        raise FHIRPathFunctionError("matches", f"Invalid regular expression: {e}")


def replace_matches(
    collection: FHIRPathCollection,
    regex: str,
    replacement: str,
    flags: str = "",
) -> FHIRPathCollection:
    """
    Returns a string with all matches of the regex replaced.

    FHIRPath: replaceMatches(regex : string, replacement : string) : string

    Args:
        collection: A collection containing a single string
        regex: The regular expression pattern
        replacement: The replacement string (can include backreferences)

    Returns:
        Collection containing the string with replacements, or empty if input is empty

    Example:
        >>> replace_matches(FHIRPathCollection(['hello123world']), r'\\d+', 'X')
        FHIRPathCollection(['helloXworld'])
    """
    value = _get_singleton_string(collection, "replaceMatches")
    if value is None:
        return FHIRPathCollection([])
    # Delegate to the engine implementation so the §5.6.10 substitution
    # contract ($N, ${name}, $$, out-of-range $N, (?<name>...) named groups)
    # is identical on the direct-helper surface and the engine surface
    # (FP-10 QA-006: helper previously passed the replacement straight to
    # re.sub, producing literal '$1' and rejecting named-group patterns).
    # The helper keeps its typed ReDoS/length guard (engine converts the same
    # error to an empty collection for row resilience).
    regex = _validate_string_arg(regex, "replaceMatches", "regex")
    if regex is None:
        return FHIRPathCollection([])
    _validate_regex(regex, "replaceMatches")
    replacement = _validate_string_arg(replacement, "replaceMatches", "replacement")
    if replacement is None:
        return FHIRPathCollection([])
    flags = _validate_string_arg(flags, "replaceMatches", "flags") or ""
    from ...engine.invocations.strings import replace_matches as _engine_replace_matches

    result = _engine_replace_matches(None, [value], regex, replacement, flags)
    if isinstance(result, str):
        return _string_result(result)
    return FHIRPathCollection([])


def to_chars(collection: FHIRPathCollection) -> FHIRPathCollection:
    """
    Returns the list of characters in the input string.

    FHIRPath: toChars() : collection
    """
    value = _get_singleton_string(collection, "toChars")
    if value is None:
        return FHIRPathCollection([])
    return FHIRPathCollection(list(value))


# =============================================================================
# Split and Join Functions
# =============================================================================


def split(collection: FHIRPathCollection, separator: str) -> FHIRPathCollection:
    """
    Splits the string by the given separator and returns a collection of strings.

    FHIRPath: split(separator : string) : collection

    Args:
        collection: A collection containing a single string
        separator: The separator string to split on

    Returns:
        Collection containing the split parts

    Example:
        >>> split(FHIRPathCollection(['a,b,c']), ',')
        FHIRPathCollection(['a', 'b', 'c'])
        >>> split(FHIRPathCollection(['hello']), ',')
        FHIRPathCollection(['hello'])
    """
    value = _get_singleton_string(collection, "split")
    if value is None:
        return FHIRPathCollection([])
    parts = value.split(separator)
    return FHIRPathCollection(parts)


def join(collection: FHIRPathCollection, separator: str) -> FHIRPathCollection:
    """
    Joins a collection of strings into a single string with the given separator.

    FHIRPath: join(separator : string) : string

    Args:
        collection: A collection of strings to join
        separator: The separator string to join with

    Returns:
        Collection containing the joined string, or empty if input is empty

    Example:
        >>> join(FHIRPathCollection(['a', 'b', 'c']), ',')
        FHIRPathCollection(['a,b,c'])
    """
    if collection.is_empty:
        return FHIRPathCollection([])

    # Convert all values to strings
    str_values = []
    for val in collection.values:
        if val is None:
            str_values.append("")
        else:
            str_values.append(str(val))

    return _string_result(separator.join(str_values))


def trim(collection: FHIRPathCollection) -> FHIRPathCollection:
    """
    Returns the string with leading and trailing whitespace removed.

    FHIRPath: trim() : string

    Args:
        collection: A collection containing a single string

    Returns:
        Collection containing the trimmed string, or empty if input is empty

    Example:
        >>> trim(FHIRPathCollection(['  hello  ']))
        FHIRPathCollection(['hello'])
    """
    value = _get_singleton_string(collection, "trim")
    if value is None:
        return FHIRPathCollection([])
    return _string_result(value.strip())


# =============================================================================
# String Concatenation Operator
# =============================================================================


def concatenate(
    left: FHIRPathCollection,
    right: FHIRPathCollection
) -> FHIRPathCollection:
    """
    Concatenate two strings using FHIRPath & operator semantics.

    The & operator in FHIRPath:
    - Converts null/empty to empty string
    - Returns empty if both operands are empty
    - Returns the non-empty operand if one is empty

    FHIRPath: left & right

    Args:
        left: Left operand collection
        right: Right operand collection

    Returns:
        Collection containing the concatenated string, or empty if both are empty

    Example:
        >>> concatenate(FHIRPathCollection(['hello']), FHIRPathCollection([' world']))
        FHIRPathCollection(['hello world'])
        >>> concatenate(FHIRPathCollection([]), FHIRPathCollection(['world']))
        FHIRPathCollection(['world'])
        >>> concatenate(FHIRPathCollection([]), FHIRPathCollection([]))
        FHIRPathCollection({})
    """
    # Get left value (empty string if empty/null)
    left_value = ""
    if not left.is_empty:
        val = left.singleton_value if left.is_singleton else None
        if val is not None:
            left_value = str(val) if not isinstance(val, str) else val

    # Get right value (empty string if empty/null)
    right_value = ""
    if not right.is_empty:
        val = right.singleton_value if right.is_singleton else None
        if val is not None:
            right_value = str(val) if not isinstance(val, str) else val

    # If both are empty strings (from empty collections), return empty
    if left.is_empty and right.is_empty:
        return FHIRPathCollection([])

    return _string_result(left_value + right_value)


# =============================================================================
# Function Registry for Evaluator Integration
# =============================================================================

STRING_FUNCTIONS = {
    # No-argument functions
    "length": lambda col: length(col),
    "upper": lambda col: upper(col),
    "lower": lambda col: lower(col),
    "trim": lambda col: trim(col),
    "toChars": lambda col: to_chars(col),

    # Single-argument functions
    "indexOf": lambda col, arg: index_of(col, arg),
    "startsWith": lambda col, arg: starts_with(col, arg),
    "endsWith": lambda col, arg: ends_with(col, arg),
    "contains": lambda col, arg: contains(col, arg),
    "matches": lambda col, arg: matches(col, arg),
    "split": lambda col, arg: split(col, arg),
    "join": lambda col, arg: join(col, arg),
    "substring": lambda col, arg: substring(col, arg),

    # Two-argument functions
    "replace": lambda col, arg1, arg2: replace(col, arg1, arg2),
    "replaceMatches": lambda col, arg1, arg2: replace_matches(col, arg1, arg2),

    # Variable-argument substring
    "substringWithLength": lambda col, start, length_val: substring(col, start, length_val),
}
