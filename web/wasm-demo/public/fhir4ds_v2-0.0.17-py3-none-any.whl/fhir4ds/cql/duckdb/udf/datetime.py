"""
CQL Date/Time Difference UDFs

Implements all CQL date/time difference functions:
- yearsBetween(a, b), monthsBetween(a, b), daysBetween(a, b)
- hoursBetween(a, b), minutesBetween(a, b), secondsBetween(a, b)
- millisecondsBetween(a, b)
- weeksBetween(a, b)
"""

from __future__ import annotations

from datetime import date, datetime, timezone
from typing import TYPE_CHECKING

import orjson

if TYPE_CHECKING:
    import duckdb



import calendar
import logging
import math
from datetime import timedelta, datetime as _dt_class

_logger = logging.getLogger(__name__)


def _split_timezone_suffix(value: str) -> tuple[str, str]:
    """Split and validate a CQL timezone suffix."""
    s = value.strip()
    if not s:
        return s, ""

    is_time_only = s.startswith("T") or (
        len(s) >= 2 and s[:2].isdigit() and (len(s) == 2 or s[2] == ":")
    )
    looks_date_like = len(s) >= 4 and s[:4].isdigit() and (len(s) == 4 or s[4] in "-T ")
    if not is_time_only and not looks_date_like:
        return s, ""
    search_start = 1 if is_time_only else 10

    sign_positions = [
        pos for pos in (s.find("+", search_start), s.find("-", search_start)) if pos >= 0
    ]
    if sign_positions:
        idx = min(sign_positions)
        suffix = s[idx:]
        if (
            len(suffix) != 6
            or suffix[0] not in "+-"
            or suffix[3] != ":"
            or not suffix[1:3].isdigit()
            or not suffix[4:6].isdigit()
        ):
            raise ValueError(f"Invalid timezone offset {suffix!r}")
        hours = int(suffix[1:3])
        minutes = int(suffix[4:6])
        if hours > 14 or minutes > 59 or (hours == 14 and minutes != 0):
            raise ValueError(f"Invalid timezone offset {suffix!r}")
        return s[:idx], suffix

    if s.endswith("Z") and len(s) > search_start:
        return s[:-1], "Z"
    return s, ""


def _has_invalid_timezone_suffix(value: str) -> bool:
    try:
        _split_timezone_suffix(value)
        return False
    except ValueError:
        return True


# Unit aliases for dateAddQuantity - maps unit string to (handler_type, timedelta_key)
_TIMEDELTA_UNITS: dict[str, str] = {
    "week": "weeks", "weeks": "weeks", "wk": "weeks",
    "day": "days", "days": "days", "d": "days",
    "hour": "hours", "hours": "hours", "h": "hours",
    "minute": "minutes", "minutes": "minutes", "min": "minutes",
    "second": "seconds", "seconds": "seconds", "s": "seconds",
    "millisecond": "milliseconds", "milliseconds": "milliseconds", "ms": "milliseconds",
}
_YEAR_UNITS = frozenset(("year", "years", "a"))
_MONTH_UNITS = frozenset(("month", "months", "mo"))
# CQL §Add / §Subtract: "For precisions above seconds, any decimal portion
# of the time-valued quantity is ignored." Membership is determined by the
# quantity unit (not the input precision). Seconds and milliseconds are
# at-or-below-seconds and preserve decimal portions (combined as a single
# decimal precision per CQL §Types/DateTime).
_ABOVE_SECONDS_UNITS = frozenset((
    "year", "years", "a",
    "month", "months", "mo",
    "week", "weeks", "wk",
    "day", "days", "d",
    "hour", "hours", "h",
    "minute", "minutes", "min",
))
def _parse_date(value: str) -> date | None:
    """Parse date from ISO 8601 string.

    Handles partial-precision strings: year-only ('2014') and
    year-month ('2014-01') by padding to full date.
    """
    if not value:
        return None
    try:
        val = value.strip()
        # Year-only: '2014' → date(2014, 1, 1)
        if len(val) == 4 and val.isdigit():
            return date(int(val), 1, 1)
        # Year-month: '2014-01' → date(2014, 1, 1)
        if len(val) == 7 and val[4] == '-' and val[:4].isdigit() and val[5:7].isdigit():
            return date(int(val[:4]), int(val[5:7]), 1)
        return date.fromisoformat(val[:10])
    except ValueError as e:
        _logger.warning("_parse_date failed: %s", e)
        return None


def _parse_time(value: str) -> "time | None":
    """Parse time from ISO 8601 / CQL time string (e.g. '15:59:59.999' or 'T15:59:59.999')."""
    from datetime import time as _time_class
    if not value:
        return None
    try:
        s = value.lstrip("T").strip()
        body, tz_suffix = _split_timezone_suffix(s)
        s = body + ("+00:00" if tz_suffix == "Z" else tz_suffix)
        # Normalize fractional seconds to 6 digits for fromisoformat compatibility
        if '.' in s:
            base, frac = s.split('.', 1)
            frac = frac.ljust(6, '0')[:6]
            s = f"{base}.{frac}"
        return _time_class.fromisoformat(s)
    except (ValueError, TypeError):
        return None


def _parse_datetime(value: str) -> datetime | None:
    """Parse datetime from ISO 8601 string.

    Handles partial-precision strings by padding to minimum valid datetime.
    """
    if not value:
        return None
    try:
        val, tz_suffix = _split_timezone_suffix(value.strip())
        val = val + ("+00:00" if tz_suffix == "Z" else tz_suffix)

        # Handle partial-precision strings
        # Year-only with T suffix: '2014T' → datetime(2014, 1, 1)
        if val.endswith('T') and len(val) == 5 and val[:4].isdigit():
            return datetime(int(val[:4]), 1, 1)
        # Year-month with T suffix: '2014-01T' → datetime(2014, 1, 1)
        if val.endswith('T') and len(val) == 8 and val[4] == '-':
            return datetime(int(val[:4]), int(val[5:7]), 1)
        # Day-precision DateTime with no time components: '2014-01-15T'
        if val.endswith('T') and len(val) == 11 and val[4] == '-' and val[7] == '-':
            d = date.fromisoformat(val[:10])
            return datetime(d.year, d.month, d.day)
        # Year-only: '2014' → datetime(2014, 1, 1)
        if len(val) == 4 and val.isdigit():
            return datetime(int(val), 1, 1)
        # Year-month: '2014-01' → datetime(2014, 1, 1)
        if len(val) == 7 and val[4] == '-' and val[:4].isdigit() and val[5:7].isdigit():
            return datetime(int(val[:4]), int(val[5:7]), 1)
        # Date-only: '2014-01-15' → datetime(2014, 1, 15)
        if len(val) == 10 and val[4] == '-' and val[7] == '-':
            d = date.fromisoformat(val)
            return datetime(d.year, d.month, d.day)
        # Hour-only: '2014-01-15T10' → datetime(2014, 1, 15, 10, 0, 0)
        if len(val) == 13 and 'T' in val:
            date_part = val[:10]
            hour = int(val[11:13])
            d = date.fromisoformat(date_part)
            return datetime(d.year, d.month, d.day, hour)

        # Normalize partial fractional seconds (.4 → .400000) for Python 3.10 compat
        if '.' in val:
            dot_idx = val.rindex('.')
            end = dot_idx + 1
            while end < len(val) and val[end].isdigit():
                end += 1
            frac = val[dot_idx+1:end]
            frac = frac.ljust(6, '0')[:6]
            val = val[:dot_idx+1] + frac + val[end:]
        # Handle space-separated datetime
        if ' ' in val and 'T' not in val:
            val = val.replace(' ', 'T', 1)
        return datetime.fromisoformat(val)
    except ValueError as e:
        _logger.warning("_parse_datetime failed: %s", e)
        return None


def _parse_to_datetime(iso_str: str) -> datetime | None:
    """Parse any ISO 8601 string (date, datetime, or time) to a datetime object.

    Handles Time-only strings ('T10:30:00', '10:30:00') by placing time
    components on epoch day (0001-01-01).
    """
    if iso_str is None:
        return None
    s = iso_str.strip()
    if _has_invalid_timezone_suffix(s):
        return None
    is_time = s.startswith('T') or (len(s) < 10 and ':' in s and '-' not in s)
    if is_time:
        comps = _parse_components(s)
        return datetime(comps['year'], comps['month'], comps['day'],
                        comps['hour'], comps['minute'], comps['second'],
                        comps['millisecond'] * 1000)
    result = _parse_datetime(s) or _parse_date(s)
    if result is None:
        return None
    if isinstance(result, date) and not isinstance(result, datetime):
        return datetime(result.year, result.month, result.day)
    return result


def _low_boundary(iso_str: str) -> datetime:
    """Compute the lowest possible datetime for a partial-precision ISO string.

    CQL §22.9: LowBoundary fills unspecified components with their minimum values.
    """
    comps = _parse_components(iso_str)
    return datetime(comps['year'], comps['month'], comps['day'],
                    comps['hour'], comps['minute'], comps['second'],
                    comps['millisecond'] * 1000)


def _high_boundary(iso_str: str) -> datetime:
    """Compute the highest possible datetime for a partial-precision ISO string.

    CQL §22.10: HighBoundary fills unspecified components with their maximum values.
    """
    prec = _infer_precision(iso_str)
    prec_idx = _PRECISION_INDEX.get(prec, 6)
    comps = _parse_components(iso_str)
    y, mo, d = comps['year'], comps['month'], comps['day']
    h, mi, s, ms = comps['hour'], comps['minute'], comps['second'], comps['millisecond']
    if prec_idx < 6:  # millisecond
        ms = 999
    if prec_idx < 5:  # second
        s = 59
    if prec_idx < 4:  # minute
        mi = 59
    if prec_idx < 3:  # hour
        h = 23
    if prec_idx < 2:  # day
        d = calendar.monthrange(y, mo)[1]
    if prec_idx < 1:  # month
        mo = 12
        d = 31
    return datetime(y, mo, d, h, mi, s, ms * 1000)


def _duration_high_boundary(iso_str: str, unit_key: str) -> datetime:
    """Highest endpoint for duration uncertainty at the requested precision.

    Difference counts crossed boundaries, so it uses the full high boundary.
    Duration counts whole calendar periods; finer unspecified components of
    the end operand must stay at their minimums or a partial period can be
    counted as whole. For example, months between 2012-01-02 and @2012 is
    [0,10], not [0,11].

    For year-target duration with a year-precision operand, the uncertain
    month/day must be maxed (month=December, day=1 so no partial month is
    introduced) so the year count reflects the maximum possible whole years.
    For example, years between @2012-06-01 and @2014 is Interval[1, 2],
    not 1. The official conformance test `years between DateTime(2005) and
    DateTime(2010) // Interval[4, 5]` exercises this path.
    """
    comps = _parse_components(iso_str)
    current_idx = _PRECISION_INDEX.get(_infer_precision(iso_str), 6)
    target_idx = _PRECISION_INDEX.get(unit_key, 2)

    y, mo, d = comps["year"], comps["month"], comps["day"]
    h, mi, s, ms = comps["hour"], comps["minute"], comps["second"], comps["millisecond"]

    # When the operand lacks month precision (year-only), max the month
    # to December and zero finer components. This applies for ANY target
    # precision (year-or-finer) because the operand's missing month is
    # uncertain and must be maxed to give the highest possible duration.
    # Day is zeroed to 1 so that no partial-month period is counted as
    # whole for month-or-finer target precisions.
    if current_idx < 1:
        mo = 12
        d = 1
        h = mi = s = ms = 0
    if current_idx < 2 <= target_idx:
        d = calendar.monthrange(y, mo)[1]
        h = mi = s = ms = 0
    if current_idx < 3 <= target_idx:
        h = 23
        mi = s = ms = 0
    if current_idx < 4 <= target_idx:
        mi = 59
        s = ms = 0
    if current_idx < 5 <= target_idx:
        s = 59
        ms = 0
    if current_idx < 6 <= target_idx:
        ms = 999

    return datetime(y, mo, d, h, mi, s, ms * 1000)


def _days_in_month(year: int, month: int) -> int:
    return calendar.monthrange(year, month)[1]


def _add_calendar_months(value: datetime, months: int) -> datetime:
    month_index = value.year * 12 + (value.month - 1) + months
    year, month_zero = divmod(month_index, 12)
    month = month_zero + 1
    day = min(value.day, _days_in_month(year, month))
    return value.replace(year=year, month=month, day=day)


def _wall_clock(value: datetime) -> datetime:
    """Drop tzinfo so calendar-duration math compares wall components.

    Matches the native engine (DurationInCalendarYears/Months compare the
    parsed components as written). Also avoids Python TypeError when one
    operand is offset-naive and the other offset-aware.
    """
    if value.tzinfo is not None:
        return value.replace(tzinfo=None)
    return value


def _duration_in_calendar_months(s: datetime, e: datetime) -> int:
    s, e = _wall_clock(s), _wall_clock(e)
    if e < s:
        return -_duration_in_calendar_months(e, s)

    months = (e.year - s.year) * 12 + (e.month - s.month)
    if _add_calendar_months(s, months) > e:
        months -= 1
    return months


def _duration_in_calendar_years(s: datetime, e: datetime) -> int:
    s, e = _wall_clock(s), _wall_clock(e)
    if e < s:
        return -_duration_in_calendar_years(e, s)

    years = e.year - s.year
    if _add_calendar_months(s, years * 12) > e:
        years -= 1
    return years


def _elapsed_seconds(s: datetime, e: datetime) -> float | None:
    """Return elapsed seconds, rejecting mixed timezone-aware/naive inputs."""
    if (s.tzinfo is None) != (e.tzinfo is None):
        return None
    if s.tzinfo is not None and e.tzinfo is not None:
        s = s.astimezone(timezone.utc)
        e = e.astimezone(timezone.utc)
    return (e - s).total_seconds()


def _compute_duration(s: datetime, e: datetime, unit: str, is_week: bool) -> int | None:
    """Compute integer duration between two datetimes in the given unit.

    CQL §22.21: returns the number of whole calendar periods, truncated
    toward zero (not floored).
    """
    if unit in ('year', 'years'):
        return _duration_in_calendar_years(s, e)
    if unit in ('month', 'months'):
        return _duration_in_calendar_months(s, e)
    total_seconds = _elapsed_seconds(s, e)
    if total_seconds is None:
        return None
    # Use int(x / divisor) for truncation toward zero, NOT // (floor)
    if is_week or unit in ('week', 'weeks'):
        return int(total_seconds / 86400 / 7)
    if unit in ('day', 'days'):
        return int(total_seconds / 86400)
    if unit in ('hour', 'hours'):
        return int(total_seconds / 3600)
    if unit in ('minute', 'minutes'):
        return int(total_seconds / 60)
    if unit in ('second', 'seconds'):
        return int(total_seconds)
    if unit in ('millisecond', 'milliseconds'):
        return int(total_seconds * 1000)
    return int(total_seconds / 86400)


_SUBDAY_BOUNDARY_MS: dict[str, int] = {
    'hour': 3_600_000,
    'minute': 60_000,
    'second': 1_000,
    'millisecond': 1,
}


def _subday_boundary_difference(s: datetime, e: datetime, unit_ms: int) -> int | None:
    """Count sub-day precision boundaries crossed between two instants.

    CQL 1.5 §8.7 Difference: "returns the number of boundaries crossed for
    the specified precision" — for hour/minute/second/millisecond precision
    a boundary is a unit mark on the (UTC-normalized for timezone-aware
    operands) timeline, so the count is the difference of floor(epoch/unit)
    boundary indices, NOT truncation of the elapsed duration (that is
    §8.8 Duration semantics).
    """
    if (s.tzinfo is None) != (e.tzinfo is None):
        return None
    epoch = _dt_class(1970, 1, 1)
    if s.tzinfo is not None:
        s = s.astimezone(timezone.utc).replace(tzinfo=None)
        e = e.astimezone(timezone.utc).replace(tzinfo=None)
    s_ms = round((s - epoch).total_seconds() * 1000)
    e_ms = round((e - epoch).total_seconds() * 1000)
    return (e_ms // unit_ms) - (s_ms // unit_ms)


def _compute_difference(s: datetime, e: datetime, unit: str, is_week: bool) -> int | None:
    """Compute CQL difference boundary crossings between two datetimes."""
    if unit in ('year', 'years'):
        return e.year - s.year
    if unit in ('month', 'months'):
        return (e.year - s.year) * 12 + (e.month - s.month)
    if is_week or unit in ('week', 'weeks'):
        # CQL 1.5 §8.7 Difference: "For calculations involving weeks, Sunday
        # is considered to be the first day of the week for the purposes of
        # determining the number of boundaries crossed." Count Sunday
        # boundaries, not whole elapsed weeks. In the proleptic Gregorian
        # ordinal calendar, ordinal 7 (0001-01-07) is a Sunday, so Sunday
        # ordinals are ≡ 0 (mod 7) and ordinal // 7 is the Sunday-based week
        # index; the difference increments exactly once per Sunday crossed.
        s_ord = s.date().toordinal()
        e_ord = e.date().toordinal()
        return (e_ord // 7) - (s_ord // 7)
    if unit in ('day', 'days'):
        return (e.date() - s.date()).days
    for unit_key, unit_ms in _SUBDAY_BOUNDARY_MS.items():
        if unit in (unit_key, unit_key + 's'):
            return _subday_boundary_difference(s, e, unit_ms)
    return (e.date() - s.date()).days


def _normalize_between_unit(unit: str) -> str | None:
    """Normalize a CQL duration/difference precision name or UCUM alias."""
    normalized = str(unit).strip().lower()
    aliases = {
        "a": "year",
        "mo": "month",
        "wk": "week",
        "d": "day",
        "h": "hour",
        "min": "minute",
        "s": "second",
        "ms": "millisecond",
    }
    if normalized in aliases:
        return aliases[normalized]
    if normalized.endswith("s"):
        normalized = normalized[:-1]
    if normalized in _PRECISION_INDEX or normalized == "week":
        return normalized
    return None


def _duration_between_with_uncertainty(start_str: str, end_str: str, unit: str) -> str | None:
    """CQL §22.21 DurationBetween with uncertainty interval support.

    Always returns VARCHAR: either an integer string or a JSON interval string.
    """
    s_prec = _infer_precision(start_str)
    e_prec = _infer_precision(end_str)

    unit_key = _normalize_between_unit(unit)
    if unit_key is None:
        return None
    is_week = unit_key == 'week'
    if is_week:
        unit_key = 'day'

    unit_idx = _PRECISION_INDEX.get(unit_key, 2)
    s_idx = _PRECISION_INDEX.get(s_prec, 0)
    e_idx = _PRECISION_INDEX.get(e_prec, 0)

    # CQL §22.21: A result is certain when both operands carry at least the
    # requested precision. Missing components only create uncertainty when an
    # operand is coarser than the requested unit.
    is_date_only = 'T' not in start_str and 'T' not in end_str
    date_unit = unit_key in ('year', 'month', 'day', 'week')
    date_fully_specified = is_date_only and date_unit and s_prec == 'day' and e_prec == 'day'
    if date_unit and unit_key in ('year', 'month'):
        # Calendar year/month durations depend on the (possibly unknown)
        # day-of-month of both operands, so a certain result requires at
        # least day precision on BOTH sides. A month-precision operand
        # yields an uncertainty interval, mirroring the official test
        # `years between DateTime(2005) and DateTime(2010) // Interval[4,5]`.
        both_sufficient_precision = s_idx >= 2 and e_idx >= 2
    elif date_unit and not date_fully_specified:
        both_sufficient_precision = s_idx > unit_idx and e_idx > unit_idx
    else:
        both_sufficient_precision = s_idx >= unit_idx and e_idx >= unit_idx
    if both_sufficient_precision or date_fully_specified:
        # Both have sufficient precision — certain result
        s = _parse_to_datetime(start_str)
        e = _parse_to_datetime(end_str)
        if s is None or e is None:
            return None
        duration = _compute_duration(s, e, unit, is_week)
        return None if duration is None else str(duration)

    # Uncertainty: compute min/max by using low/high boundaries
    s_low = _low_boundary(start_str)
    s_high = _high_boundary(start_str)
    if date_unit and unit_key in ('year', 'month') and 'T' not in start_str:
        # Date-only operands follow the midnight convention for calendar
        # (year/month) durations — the crisp day-precision path parses
        # them at midnight — so the uncertain start's latest possible
        # instant must not inject a phantom 23:59:59.999 that would flip
        # an exact anniversary boundary (e.g. years between @1975-03 and
        # @2020-03-31 must stay 45, not Interval[44,45]).
        s_high = s_high.replace(hour=0, minute=0, second=0, microsecond=0)
    e_low = _low_boundary(end_str)
    e_high = _duration_high_boundary(end_str, unit_key)

    # Min duration: start at highest, end at lowest
    min_val = _compute_duration(s_high, e_low, unit, is_week)
    # Max duration: start at lowest, end at highest
    max_val = _compute_duration(s_low, e_high, unit, is_week)
    if min_val is None or max_val is None:
        return None

    if min_val == max_val:
        return str(min_val)

    return orjson.dumps({
        "start": min_val, "end": max_val,
        "lowClosed": True, "highClosed": True
    }).decode('utf-8')


def _difference_between_with_uncertainty(start_str: str, end_str: str, unit: str) -> str | None:
    """CQL §22.22 DifferenceBetween with uncertainty interval support."""
    s_prec = _infer_precision(start_str)
    e_prec = _infer_precision(end_str)

    unit_key = _normalize_between_unit(unit)
    if unit_key is None:
        return None
    is_week = unit_key == 'week'
    if is_week:
        unit_key = 'day'

    unit_idx = _PRECISION_INDEX.get(unit_key, 2)
    s_idx = _PRECISION_INDEX.get(s_prec, 0)
    e_idx = _PRECISION_INDEX.get(e_prec, 0)

    is_date_only = 'T' not in start_str and 'T' not in end_str
    date_unit = unit_key in ('year', 'month', 'day', 'week')
    both_sufficient_precision = s_idx >= unit_idx and e_idx >= unit_idx
    date_fully_specified = is_date_only and date_unit and s_prec == 'day' and e_prec == 'day'
    if both_sufficient_precision or date_fully_specified:
        s = _parse_to_datetime(start_str)
        e = _parse_to_datetime(end_str)
        if s is None or e is None:
            return None
        difference = _compute_difference(s, e, unit, is_week)
        return None if difference is None else str(difference)

    s_low = _low_boundary(start_str)
    s_high = _high_boundary(start_str)
    e_low = _low_boundary(end_str)
    e_high = _high_boundary(end_str)

    min_val = _compute_difference(s_high, e_low, unit, is_week)
    max_val = _compute_difference(s_low, e_high, unit, is_week)
    if min_val is None or max_val is None:
        return None
    if min_val > max_val:
        min_val, max_val = max_val, min_val
    if min_val == max_val:
        return str(min_val)

    return orjson.dumps({
        "start": min_val, "end": max_val,
        "lowClosed": True, "highClosed": True
    }).decode('utf-8')


def yearsBetween(start: str | None, end: str | None) -> int | None:
    """CQL whole calendar years between two date/time values."""
    s, e = _parse_to_datetime(start), _parse_to_datetime(end)
    if not s or not e:
        return None
    return _duration_in_calendar_years(s, e)


def monthsBetween(start: str | None, end: str | None) -> int | None:
    """CQL whole calendar months between two date/time values."""
    s, e = _parse_to_datetime(start), _parse_to_datetime(end)
    if not s or not e:
        return None
    return _duration_in_calendar_months(s, e)


def weeksBetween(start: str | None, end: str | None) -> int | None:
    """CQL weeks between two dates (integer result)."""
    s, e = _parse_to_datetime(start), _parse_to_datetime(end)
    if not s or not e:
        return None
    total_seconds = _elapsed_seconds(s, e)
    if total_seconds is None:
        return None
    return int(total_seconds / 86400 / 7)


def daysBetween(start: str | None, end: str | None) -> int | None:
    """CQL whole days between two date/time values."""
    s, e = _parse_to_datetime(start), _parse_to_datetime(end)
    if not s or not e:
        return None
    total_seconds = _elapsed_seconds(s, e)
    if total_seconds is None:
        return None
    return int(total_seconds / 86400)


def hoursBetween(start: str | None, end: str | None) -> int | None:
    """CQL hours between two datetimes (integer result)."""
    s, e = _parse_datetime(start), _parse_datetime(end)
    if not s or not e:
        return None
    total_seconds = _elapsed_seconds(s, e)
    if total_seconds is None:
        return None
    return int(total_seconds / 3600)


def minutesBetween(start: str | None, end: str | None) -> int | None:
    """CQL minutes between two datetimes (integer result)."""
    s, e = _parse_datetime(start), _parse_datetime(end)
    if not s or not e:
        return None
    total_seconds = _elapsed_seconds(s, e)
    if total_seconds is None:
        return None
    return int(total_seconds / 60)


def secondsBetween(start: str | None, end: str | None) -> int | None:
    """CQL seconds between two datetimes (integer result)."""
    s, e = _parse_datetime(start), _parse_datetime(end)
    if not s or not e:
        return None
    total_seconds = _elapsed_seconds(s, e)
    if total_seconds is None:
        return None
    return int(total_seconds)


def millisecondsBetween(start: str | None, end: str | None) -> int | None:
    """CQL milliseconds between two datetimes (integer result)."""
    s, e = _parse_datetime(start), _parse_datetime(end)
    if not s or not e:
        return None
    total_seconds = _elapsed_seconds(s, e)
    if total_seconds is None:
        return None
    return int(total_seconds * 1000)


# ==============================================
# Uncertainty-aware DurationBetween (returns VARCHAR)
# CQL §22.21: Used by translator for DurationBetween/DifferenceBetween
# expressions where partial precision may produce uncertainty intervals.
# ==============================================

def cqlDurationBetween(start_str: str | None, end_str: str | None, unit: str | None) -> str | None:
    """CQL §22.21 DurationBetween with uncertainty interval support.

    Always returns VARCHAR: integer string if certain, JSON interval string if uncertain.
    """
    if start_str is None or end_str is None or unit is None:
        return None
    try:
        return _duration_between_with_uncertainty(str(start_str), str(end_str), str(unit))
    except (ValueError, TypeError):
        return None


def cqlDifferenceBetween(start_str: str | None, end_str: str | None, unit: str | None) -> str | None:
    """CQL §22.22 DifferenceBetween with uncertainty interval support."""
    if start_str is None or end_str is None or unit is None:
        return None
    try:
        return _difference_between_with_uncertainty(str(start_str), str(end_str), str(unit))
    except (ValueError, TypeError):
        return None


def _parse_int_or_interval(val: str) -> int | dict:
    """Parse a Between result: integer string → int, JSON interval → dict."""
    try:
        return int(val)
    except (ValueError, TypeError):
        return orjson.loads(val)


def cqlUncertainAdd(a: str | None, b: str | None) -> str | None:
    """Add two values that may be integers or uncertainty intervals.

    CQL uncertainty arithmetic: Interval[a,b] + Interval[c,d] = Interval[a+c, b+d]
    """
    if a is None or b is None:
        return None
    try:
        av = _parse_int_or_interval(str(a))
        bv = _parse_int_or_interval(str(b))
    except (ValueError, TypeError, orjson.JSONDecodeError):
        return None
    a_is_int = isinstance(av, int)
    b_is_int = isinstance(bv, int)
    if a_is_int and b_is_int:
        return str(av + bv)
    a_low = av if a_is_int else av.get('start', 0)
    a_high = av if a_is_int else av.get('end', 0)
    b_low = bv if b_is_int else bv.get('start', 0)
    b_high = bv if b_is_int else bv.get('end', 0)
    return orjson.dumps({
        "start": a_low + b_low, "end": a_high + b_high,
        "lowClosed": True, "highClosed": True
    }).decode('utf-8')


def cqlUncertainSubtract(a: str | None, b: str | None) -> str | None:
    """Subtract two values that may be integers or uncertainty intervals.

    CQL: Interval[a,b] - Interval[c,d] = Interval[a-d, b-c]
    """
    if a is None or b is None:
        return None
    try:
        av = _parse_int_or_interval(str(a))
        bv = _parse_int_or_interval(str(b))
    except (ValueError, TypeError, orjson.JSONDecodeError):
        return None
    a_is_int = isinstance(av, int)
    b_is_int = isinstance(bv, int)
    if a_is_int and b_is_int:
        return str(av - bv)
    a_low = av if a_is_int else av.get('start', 0)
    a_high = av if a_is_int else av.get('end', 0)
    b_low = bv if b_is_int else bv.get('start', 0)
    b_high = bv if b_is_int else bv.get('end', 0)
    return orjson.dumps({
        "start": a_low - b_high, "end": a_high - b_low,
        "lowClosed": True, "highClosed": True
    }).decode('utf-8')


def cqlUncertainMultiply(a: str | None, b: str | None) -> str | None:
    """Multiply two values that may be integers or uncertainty intervals.

    CQL: Products of all endpoint combinations, take min/max.
    """
    if a is None or b is None:
        return None
    try:
        av = _parse_int_or_interval(str(a))
        bv = _parse_int_or_interval(str(b))
    except (ValueError, TypeError, orjson.JSONDecodeError):
        return None
    a_is_int = isinstance(av, int)
    b_is_int = isinstance(bv, int)
    if a_is_int and b_is_int:
        return str(av * bv)
    a_low = av if a_is_int else av.get('start', 0)
    a_high = av if a_is_int else av.get('end', 0)
    b_low = bv if b_is_int else bv.get('start', 0)
    b_high = bv if b_is_int else bv.get('end', 0)
    products = [a_low * b_low, a_low * b_high, a_high * b_low, a_high * b_high]
    return orjson.dumps({
        "start": min(products), "end": max(products),
        "lowClosed": True, "highClosed": True
    }).decode('utf-8')


def cqlUncertainCompare(a: str | None, b: str | None, op: str | None) -> bool | None:
    """Compare integer-or-interval with integer-or-interval.

    CQL three-valued logic: If ranges overlap for the comparison, return null.
    E.g., Interval[4,16] > 5 → null (could be 4 which is not > 5, or 16 which is).
    """
    if a is None or b is None:
        return None
    try:
        av = _parse_int_or_interval(str(a))
        bv = _parse_int_or_interval(str(b))
    except (ValueError, TypeError, orjson.JSONDecodeError):
        return None
    a_is_int = isinstance(av, int)
    b_is_int = isinstance(bv, int)
    a_low = av if a_is_int else av.get('start', 0)
    a_high = av if a_is_int else av.get('end', 0)
    b_low = bv if b_is_int else bv.get('start', 0)
    b_high = bv if b_is_int else bv.get('end', 0)
    op_str = str(op) if op else '>'
    if op_str == '>':
        if a_low > b_high:
            return True
        if a_high <= b_low:
            return False
        return None
    if op_str == '>=':
        if a_low >= b_high:
            return True
        if a_high < b_low:
            return False
        return None
    if op_str == '<':
        if a_high < b_low:
            return True
        if a_low >= b_high:
            return False
        return None
    if op_str == '<=':
        if a_high <= b_low:
            return True
        if a_low > b_high:
            return False
        return None
    if op_str in ('=', '=='):
        if a_low == a_high == b_low == b_high:
            return True
        if a_high < b_low or a_low > b_high:
            return False
        return None
    return None


def _uncertain_bounds(val: str) -> tuple[int, int]:
    """Parse an int-or-interval VARCHAR into (low, high)."""
    parsed = _parse_int_or_interval(val)
    if isinstance(parsed, int):
        return parsed, parsed
    return int(parsed.get('start', 0)), int(parsed.get('end', 0))


def _format_int_or_interval(low: int, high: int) -> str:
    if low == high:
        return str(low)
    return orjson.dumps({
        "start": low, "end": high, "lowClosed": True, "highClosed": True
    }).decode('utf-8')


def cqlUncertainMin(a: str | None, b: str | None) -> str | None:
    """CQL 1.5 Min (scalar) over uncertainty-capable operands.

    Interval-aware minimum: Min(Interval[a,b], Interval[c,d]) covers the
    range of possible minima = Interval[min(a,c), min(b,d)]; collapses to a
    crisp integer when both operands are crisp (or the range degenerates).
    """
    if a is None or b is None:
        return None
    try:
        a_low, a_high = _uncertain_bounds(str(a))
        b_low, b_high = _uncertain_bounds(str(b))
    except (ValueError, TypeError, orjson.JSONDecodeError):
        return None
    return _format_int_or_interval(min(a_low, b_low), min(a_high, b_high))


def cqlUncertainMax(a: str | None, b: str | None) -> str | None:
    """CQL 1.5 Max (scalar) over uncertainty-capable operands.

    Interval-aware maximum: Max(Interval[a,b], Interval[c,d]) =
    Interval[max(a,c), max(b,d)] over possible maxima; collapses when crisp.
    """
    if a is None or b is None:
        return None
    try:
        a_low, a_high = _uncertain_bounds(str(a))
        b_low, b_high = _uncertain_bounds(str(b))
    except (ValueError, TypeError, orjson.JSONDecodeError):
        return None
    return _format_int_or_interval(max(a_low, b_low), max(a_high, b_high))


def cqlUncertainListMin(values) -> str | None:
    """CQL 1.5 Min (list aggregate) over uncertainty-capable elements.

    Null elements are ignored (CQL aggregate null handling); empty or
    all-null lists return null. Interval-aware: the minimum over uncertain
    elements ranges from the min of lows to the min of highs.
    """
    if values is None:
        return None
    low = high = None
    for v in values:
        if v is None:
            continue
        try:
            v_low, v_high = _uncertain_bounds(str(v))
        except (ValueError, TypeError, orjson.JSONDecodeError):
            return None
        low = v_low if low is None else min(low, v_low)
        high = v_high if high is None else min(high, v_high)
    if low is None or high is None:
        return None
    return _format_int_or_interval(low, high)


def cqlUncertainListMax(values) -> str | None:
    """CQL 1.5 Max (list aggregate) over uncertainty-capable elements.

    Null elements are ignored; empty or all-null lists return null. The
    maximum over uncertain elements ranges from the max of lows to the max
    of highs.
    """
    if values is None:
        return None
    low = high = None
    for v in values:
        if v is None:
            continue
        try:
            v_low, v_high = _uncertain_bounds(str(v))
        except (ValueError, TypeError, orjson.JSONDecodeError):
            return None
        low = v_low if low is None else max(low, v_low)
        high = v_high if high is None else max(high, v_high)
    if low is None or high is None:
        return None
    return _format_int_or_interval(low, high)


def cqlUncertainListSum(values) -> str | None:
    """CQL 1.5 Sum (list aggregate) over uncertainty-capable elements.

    Null elements are ignored (CQL aggregate null handling); empty or
    all-null lists return null. Interval-aware (§22.21): the sum of
    uncertain elements ranges from the sum of lows to the sum of highs —
    uncertain elements are never silently dropped as null.
    """
    if values is None:
        return None
    low = high = None
    for v in values:
        if v is None:
            continue
        try:
            v_low, v_high = _uncertain_bounds(str(v))
        except (ValueError, TypeError, orjson.JSONDecodeError):
            return None
        low = v_low if low is None else low + v_low
        high = v_high if high is None else high + v_high
    if low is None or high is None:
        return None
    return _format_int_or_interval(low, high)


# ========================================
# Now/Today/TimeOfDay Functions
# ========================================

def dateTimeNow() -> str:
    """CQL Now() - current datetime."""
    from datetime import datetime, timezone
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def dateTimeToday() -> str:
    """CQL Today() - current date."""
    from datetime import datetime, timezone
    return datetime.now(timezone.utc).date().isoformat()


def dateTimeTimeOfDay() -> str:
    """CQL TimeOfDay() - current time."""
    from datetime import datetime, timezone
    return datetime.now(timezone.utc).strftime("T%H:%M:%S")


# ========================================
# DifferenceBetween UDFs (boundary crossings)
# ========================================

def differenceInYears(start: str | None, end: str | None) -> int | None:
    """
    Calculate difference in years (boundary crossings).

    Example: difference between 2023-12-31 and 2024-01-01 = 1
    (crossed a year boundary, even though not a full year)
    """
    if start is None or end is None:
        return None
    try:
        s = _parse_date(start)
        e = _parse_date(end)
        if not s or not e:
            return None
        return e.year - s.year
    except (ValueError, TypeError, AttributeError) as e:
        _logger.warning("UDF differenceInYears failed: %s", e)
        return None


def differenceInMonths(start: str | None, end: str | None) -> int | None:
    """Calculate difference in months (boundary crossings)."""
    if start is None or end is None:
        return None
    try:
        s = _parse_date(start)
        e = _parse_date(end)
        if not s or not e:
            return None
        return (e.year - s.year) * 12 + (e.month - s.month)
    except (ValueError, TypeError, AttributeError) as e:
        _logger.warning("UDF differenceInMonths failed: %s", e)
        return None


def differenceInDays(start: str | None, end: str | None) -> int | None:
    """Calculate difference in days (boundary crossings)."""
    if start is None or end is None:
        return None
    try:
        s = _parse_date(start)
        e = _parse_date(end)
        if not s or not e:
            return None
        return (e - s).days
    except (ValueError, TypeError, AttributeError) as e:
        _logger.warning("UDF differenceInDays failed: %s", e)
        return None


def differenceInWeeks(start: str | None, end: str | None) -> int | None:
    """Calculate difference in weeks (boundary crossings).

    CQL 1.5 §8.7 Difference: Sunday is the first day of the week for
    boundary counting; count Sunday boundaries crossed, not whole elapsed
    weeks (ordinal // 7 is the Sunday-based week index because proleptic
    Gregorian ordinal 7, 0001-01-07, is a Sunday).
    """
    days = differenceInDays(start, end)
    if days is None:
        return None
    s = _parse_date(start)
    e = _parse_date(end)
    if not s or not e:
        return None
    return (e.toordinal() // 7) - (s.toordinal() // 7)


def _parse_difference_datetime(value: str) -> datetime | None:
    parsed = _parse_datetime(value)
    if parsed:
        return parsed
    parsed_time = _parse_time(value)
    if parsed_time:
        return _dt_class.combine(date(2000, 1, 1), parsed_time)
    return None


def differenceInHours(start: str | None, end: str | None) -> int | None:
    """Calculate difference in hours (boundary crossings)."""
    if start is None or end is None:
        return None
    try:
        s = _parse_difference_datetime(start)
        e = _parse_difference_datetime(end)
        if not s or not e:
            return None
        return _subday_boundary_difference(s, e, 3_600_000)
    except (ValueError, TypeError, AttributeError) as ex:
        _logger.warning("UDF differenceInHours failed: %s", ex)
        return None


def differenceInMinutes(start: str | None, end: str | None) -> int | None:
    """Calculate difference in minutes (boundary crossings)."""
    if start is None or end is None:
        return None
    try:
        s = _parse_difference_datetime(start)
        e = _parse_difference_datetime(end)
        if not s or not e:
            return None
        return _subday_boundary_difference(s, e, 60_000)
    except (ValueError, TypeError, AttributeError) as ex:
        _logger.warning("UDF differenceInMinutes failed: %s", ex)
        return None


def differenceInSeconds(start: str | None, end: str | None) -> int | None:
    """Calculate difference in seconds (boundary crossings)."""
    if start is None or end is None:
        return None
    try:
        s = _parse_difference_datetime(start)
        e = _parse_difference_datetime(end)
        if not s or not e:
            return None
        return _subday_boundary_difference(s, e, 1_000)
    except (ValueError, TypeError, AttributeError) as ex:
        _logger.warning("UDF differenceInSeconds failed: %s", ex)
        return None


def differenceInMilliseconds(start: str | None, end: str | None) -> int | None:
    """Calculate difference in milliseconds (boundary crossings)."""
    if start is None or end is None:
        return None
    try:
        s = _parse_difference_datetime(start)
        e = _parse_difference_datetime(end)
        if not s or not e:
            return None
        total_seconds = _elapsed_seconds(s, e)
        if total_seconds is None:
            return None
        return int(total_seconds * 1000)
    except (ValueError, TypeError, AttributeError) as ex:
        _logger.warning("UDF differenceInMilliseconds failed: %s", ex)
        return None


def dateComponent(value: str | None, component: str) -> int | None:
    """
    Extract a date/time component.

    Args:
        value: ISO date/datetime string
        component: 'year', 'month', 'day', 'hour', 'minute', 'second'

    Returns:
        Integer component value or None if invalid
    """
    if value is None:
        return None
    try:
        comp = component.lower()
        prec = _infer_precision(value)
        prec_idx = _PRECISION_INDEX.get(prec, -1)
        if prec_idx < 0:
            return None
        comps = _parse_components(value)
        stripped = value.strip()
        is_time_only = stripped.startswith('T') or (len(stripped) < 10 and ':' in stripped and '-' not in stripped)
        component_rank = {
            'year': 0,
            'month': 1,
            'day': 2,
            'hour': 3,
            'minute': 4,
            'second': 5,
            'millisecond': 6,
        }.get(comp)
        if component_rank is None or component_rank > prec_idx:
            return None
        if is_time_only and component_rank < 3:
            return None
        if not is_time_only and component_rank >= 3 and 'T' not in stripped and ' ' not in stripped:
            return None
        return comps[comp]
    except (ValueError, TypeError, AttributeError, KeyError) as e:
        _logger.warning("UDF dateComponent failed: %s", e)
        return None


# ========================================
# DateTime Comparison UDFs (SameAs, SameOrBefore, SameOrAfter)
# ========================================

def dateTimeSameAs(a: str | None, b: str | None, precision: str | None = None) -> bool | None:
    """
    Check if two datetimes are the same at the specified precision.

    Args:
        a: First datetime (ISO format)
        b: Second datetime (ISO format)
        precision: Comparison precision ('year', 'month', 'day', 'hour', 'minute', 'second', 'millisecond')

    Returns:
        True if same at precision, False if not, None if either is null
    """
    if a is None or b is None:
        return None

    if precision is None:
        return cqlDateTimeEqual(str(a), str(b))

    try:
        cmp, certain = _compare_at_specified_precision(str(a), str(b), str(precision).lower())
    except (ValueError, KeyError, OverflowError):
        return None
    if cmp != 0:
        return False
    if not certain:
        return None
    return True


def dateTimeSameOrBefore(a: str | None, b: str | None, precision: str | None = None) -> bool | None:
    """
    Check if A is the same as or before B at the specified precision.
    A same or before B means: A <= B (at precision)
    """
    if a is None or b is None:
        return None

    if precision is None:
        return cqlSameOrBefore(str(a), str(b))

    try:
        cmp, certain = _compare_at_specified_precision(str(a), str(b), str(precision).lower())
    except (ValueError, KeyError, OverflowError):
        return None
    if cmp < 0:
        return True
    if cmp > 0:
        return False
    if not certain:
        return None
    return True


def dateTimeSameOrAfter(a: str | None, b: str | None, precision: str | None = None) -> bool | None:
    """
    Check if A is the same as or after B at the specified precision.
    A same or after B means: A >= B (at precision)
    """
    if a is None or b is None:
        return None

    if precision is None:
        return cqlSameOrAfter(str(a), str(b))

    try:
        cmp, certain = _compare_at_specified_precision(str(a), str(b), str(precision).lower())
    except (ValueError, KeyError, OverflowError):
        return None
    if cmp > 0:
        return True
    if cmp < 0:
        return False
    if not certain:
        return None
    return True


# ========================================
# Quantity to Interval Conversion
# ========================================

# Mapping from UCUM time units to DuckDB INTERVAL components
UCUM_TIME_UNITS = {
    "year": ("year", "years"),
    "years": ("year", "years"),
    "a": ("year", "years"),  # UCUM for year
    "month": ("month", "months"),
    "months": ("month", "months"),
    "mo": ("month", "months"),  # UCUM for month
    "week": ("day", "days"),  # Weeks converted to days (7 days per week)
    "weeks": ("day", "days"),
    "wk": ("day", "days"),  # UCUM for week
    "day": ("day", "days"),
    "days": ("day", "days"),
    "d": ("day", "days"),  # UCUM for day
    "hour": ("hour", "hours"),
    "hours": ("hour", "hours"),
    "h": ("hour", "hours"),  # UCUM for hour
    "minute": ("minute", "minutes"),
    "minutes": ("minute", "minutes"),
    "min": ("minute", "minutes"),  # UCUM for minute
    "second": ("second", "seconds"),
    "seconds": ("second", "seconds"),
    "s": ("second", "seconds"),  # UCUM for second
    "millisecond": ("millisecond", "milliseconds"),
    "milliseconds": ("millisecond", "milliseconds"),
    "ms": ("millisecond", "milliseconds"),  # UCUM for millisecond
}


def quantityToInterval(quantity_json: str | None) -> str | None:
    """
    Convert a FHIR Quantity to a DuckDB INTERVAL expression string.

    This function extracts the value and unit from a quantity JSON and
    returns a string that can be used with DuckDB's date arithmetic.

    Args:
        quantity_json: JSON string representing a FHIR Quantity

    Returns:
        A string like "INTERVAL 6 MONTH" or None if invalid
    """
    if quantity_json is None:
        return None

    try:
        import orjson
        data = orjson.loads(quantity_json)
        value = data.get("value")
        unit = data.get("unit") or data.get("code")

        if value is None or unit is None:
            return None

        # Normalize unit to lowercase for lookup
        unit_lower = unit.lower()

        if unit_lower not in UCUM_TIME_UNITS:
            # Not a time unit - can't convert to interval
            return None

        # Get singular/plural forms
        singular, plural = UCUM_TIME_UNITS[unit_lower]

        # DuckDB INTERVAL syntax uses the plural form for values > 1
        interval_unit = plural if abs(float(value)) != 1 else singular

        # Special handling for weeks (convert to days since DuckDB doesn't have WEEK interval)
        if unit_lower in ("week", "weeks", "wk"):
            value = float(value) * 7
            interval_unit = "days" if abs(value) != 1 else "day"

        # Return the INTERVAL expression as a string
        # The caller will use this in date arithmetic
        return f"INTERVAL {int(value)} {interval_unit.upper()}"
    except (orjson.JSONDecodeError, ValueError, TypeError, KeyError) as e:
        _logger.warning("UDF quantityToInterval failed: %s", e)
        return None


def _format_result_at_input_precision(result: datetime, input_str: str) -> str:
    """Format a datetime result preserving the precision of the input string.

    CQL §18.9: The result of date/time arithmetic preserves the precision
    of the input.  E.g. adding hours to a day-precision date returns a
    day-precision result.
    """
    prec = _infer_precision(input_str)
    prec_idx = _PRECISION_INDEX.get(prec, 6)

    stripped = input_str.strip()
    _, tz_suffix = _split_timezone_suffix(stripped)

    # Build ISO 8601 string at the input precision level
    iso = f"{result.year:04d}"
    if prec_idx >= 1:
        iso += f"-{result.month:02d}"
    if prec_idx < 2 and 'T' in stripped:
        iso += "T"
    if prec_idx >= 2:
        iso += f"-{result.day:02d}"
        if prec_idx == 2 and 'T' in stripped:
            iso += "T"
    if prec_idx >= 3:
        iso += f"T{result.hour:02d}"
    if prec_idx >= 4:
        iso += f":{result.minute:02d}"
    if prec_idx >= 5:
        iso += f":{result.second:02d}"
    if prec_idx >= 6:
        ms = result.microsecond // 1000
        iso += f".{ms:03d}"
    if tz_suffix:
        iso += tz_suffix
    return iso


def _format_time_result_at_input_precision(result: datetime, input_str: str) -> str:
    """Format a time-only arithmetic result at the input time precision."""
    prec = _infer_precision(input_str)
    _, tz_suffix = _split_timezone_suffix(input_str.strip())
    iso = f"T{result.hour:02d}"
    if _PRECISION_INDEX.get(prec, 6) >= _PRECISION_INDEX["minute"]:
        iso += f":{result.minute:02d}"
    if _PRECISION_INDEX.get(prec, 6) >= _PRECISION_INDEX["second"]:
        iso += f":{result.second:02d}"
    if _PRECISION_INDEX.get(prec, 6) >= _PRECISION_INDEX["millisecond"]:
        ms = result.microsecond // 1000
        iso += f".{ms:03d}"
    if tz_suffix:
        iso += tz_suffix
    return iso


def _parse_date_quantity_payload(quantity_json: str) -> tuple[dict, float, str] | None:
    """Parse date/time Quantity JSON for row-resilient public helper calls."""
    data = orjson.loads(quantity_json)
    if not isinstance(data, dict):
        return None

    value = data.get("value")
    unit = data.get("unit") or data.get("code")
    if (
        value is None
        or isinstance(value, bool)
        or not isinstance(value, (int, float))
        or not math.isfinite(float(value))
        or not isinstance(unit, str)
    ):
        return None

    return data, float(value), unit


def _normalized_date_quantity_unit(unit_lower: str) -> str | None:
    if unit_lower in _YEAR_UNITS:
        return "year"
    if unit_lower in _MONTH_UNITS:
        return "month"
    if unit_lower in ("week", "weeks", "wk"):
        return "week"
    if unit_lower in ("day", "days", "d"):
        return "day"
    if unit_lower in ("hour", "hours", "h"):
        return "hour"
    if unit_lower in ("minute", "minutes", "min"):
        return "minute"
    if unit_lower in ("second", "seconds", "s"):
        return "second"
    if unit_lower in ("millisecond", "milliseconds", "ms"):
        return "millisecond"
    return None


def _is_supported_date_quantity_value(value: float, unit_lower: str) -> bool:
    normalized = _normalized_date_quantity_unit(unit_lower)
    if normalized is None:
        return False
    abs_value = abs(value)
    limits = {
        "year": 10000.0,
        "month": 120000.0,
        "week": 600000.0,
        "day": 4000000.0,
        "hour": 100000000.0,
        "minute": 6000000000.0,
        "second": 4000000.0 * 86400.0,
        "millisecond": 4000000.0 * 86400.0 * 1000.0,
    }
    return abs_value <= limits[normalized]


def dateAddQuantity(date_val: str | None, quantity_json: str | None) -> str | None:
    """Add a quantity to a date/datetime.

    CQL §5.6.4: Arithmetic is performed at the precision of the input.
    If the quantity's unit is below the input's precision, the quantity is
    converted to the input precision level using CQL conversion factors
    (1 year=12 months, 1 month=30 days, 1 day=24 hours, 1 hour=60 min,
    1 min=60 sec, 1 sec=1000 ms). Integer division truncates the remainder.

    Args:
        date_val: ISO date/datetime string
        quantity_json: JSON string with {value, unit}

    Returns:
        ISO string at the input's precision, or None.
    """
    if date_val is None or quantity_json is None:
        return None
    if _has_invalid_timezone_suffix(str(date_val)):
        return None

    try:
        parsed_quantity = _parse_date_quantity_payload(quantity_json)
    except (orjson.JSONDecodeError, TypeError):
        return None
    if parsed_quantity is None:
        return None
    _data, value, unit = parsed_quantity
    unit_lower = unit.lower()
    if not _is_supported_date_quantity_value(value, unit_lower):
        return None

    # CQL §Add / §Subtract: "For precisions above seconds, any decimal
    # portion of the time-valued quantity is ignored." The triggering
    # condition is the quantity unit, not the input precision, so the
    # truncation must happen here, before any Time/Date/DateTime branching.
    if unit_lower in _ABOVE_SECONDS_UNITS and isinstance(value, float):
        value = float(int(value))  # truncate toward zero

    try:
        # Time-only value (e.g. 'T15:59:59.999')
        t = _parse_time(date_val)
        if t is not None:
            # CQL 1.5 §8.1 Add / §8.15 Subtract: "For Time values, the
            # quantity unit must be one of: hours, minutes, seconds, or
            # milliseconds." Day-level units (year/month/week/day, keyword
            # or UCUM) on Time values return null rather than silently
            # no-opping (the reference-date shift is invisible at time
            # precision).
            if unit_lower not in (
                "hour", "hours", "h",
                "minute", "minutes", "min",
                "second", "seconds", "s",
                "millisecond", "milliseconds", "ms",
            ):
                return None
            ref_dt = _dt_class(2000, 1, 1, t.hour, t.minute, t.second, t.microsecond)
            if unit_lower in _TIMEDELTA_UNITS:
                result_dt = ref_dt + timedelta(**{_TIMEDELTA_UNITS[unit_lower]: value})
                return _format_time_result_at_input_precision(result_dt, str(date_val))
            return None

        # CQL 1.5 §8.1 Add / §8.15 Subtract: "For Date values, the quantity
        # unit must be one of: years, months, weeks, or days." Date values
        # carry no 'T' marker; sub-day units on them are invalid and return
        # null rather than silently converting down to zero days.
        if "T" not in str(date_val) and unit_lower in (
            "hour", "hours", "h",
            "minute", "minutes", "min",
            "second", "seconds", "s",
            "millisecond", "milliseconds", "ms",
        ):
            return None

        input_prec = _infer_precision(date_val)
        input_prec_idx = _PRECISION_INDEX.get(input_prec, 6)

        dt = _parse_datetime(date_val)
        if dt is None:
            dt = _parse_date(date_val)
            if dt is None:
                return None
            dt = _dt_class.combine(dt, _dt_class.min.time())

        # Map unit to its precision level
        _unit_to_prec_idx = {
            'year': 0, 'years': 0, 'a': 0,
            'month': 1, 'months': 1, 'mo': 1,
            'week': 2, 'weeks': 2, 'wk': 2,
            'day': 2, 'days': 2, 'd': 2,
            'hour': 3, 'hours': 3, 'h': 3,
            'minute': 4, 'minutes': 4, 'min': 4,
            'second': 5, 'seconds': 5, 's': 5,
            'millisecond': 6, 'milliseconds': 6, 'ms': 6,
        }
        unit_prec_idx = _unit_to_prec_idx.get(unit_lower, 6)

        # CQL conversion factors: how many of the finer unit per coarser unit
        # Index i → how many units at level i+1 per 1 unit at level i
        _conversion = {
            0: 12,     # 1 year = 12 months
            1: 30,     # 1 month = 30 days
            2: 24,     # 1 day = 24 hours
            3: 60,     # 1 hour = 60 minutes
            4: 60,     # 1 minute = 60 seconds
            5: 1000,   # 1 second = 1000 ms
        }

        # Convert quantity to input precision if quantity is finer
        effective_value = value
        effective_unit = unit_lower

        if unit_prec_idx > input_prec_idx:
            # Convert from finer to coarser by dividing through
            # E.g., 25 months → years: 25 / 12 = 2
            # E.g., 33 days → months: 33 / 30 = 1
            divisor = 1
            for lvl in range(input_prec_idx, unit_prec_idx):
                divisor *= _conversion[lvl]
            effective_value = int(int(value) / divisor) if divisor > 0 else int(value)
            # Map to the input precision unit
            prec_to_unit = {0: 'years', 1: 'months', 2: 'days', 3: 'hours',
                           4: 'minutes', 5: 'seconds', 6: 'milliseconds'}
            effective_unit = prec_to_unit.get(input_prec_idx, unit_lower)

        # Perform arithmetic at the effective precision
        if effective_unit in _YEAR_UNITS or effective_unit in ('years',):
            target_year = dt.year + int(effective_value)
            max_day = calendar.monthrange(target_year, dt.month)[1]
            result = dt.replace(year=target_year, day=min(dt.day, max_day))
        elif effective_unit in _MONTH_UNITS or effective_unit in ('months',):
            new_month = dt.month + int(effective_value)
            new_year = dt.year + (new_month - 1) // 12
            new_month = ((new_month - 1) % 12) + 1
            max_day = calendar.monthrange(new_year, new_month)[1]
            result = dt.replace(year=new_year, month=new_month, day=min(dt.day, max_day))
        elif effective_unit in ('weeks', 'week', 'wk'):
            result = dt + timedelta(weeks=int(effective_value))
        elif effective_unit in _TIMEDELTA_UNITS:
            result = dt + timedelta(**{_TIMEDELTA_UNITS[effective_unit]: effective_value})
        elif effective_unit in ('days',):
            result = dt + timedelta(days=int(effective_value))
        elif effective_unit in ('hours',):
            result = dt + timedelta(hours=int(effective_value))
        elif effective_unit in ('minutes',):
            result = dt + timedelta(minutes=int(effective_value))
        elif effective_unit in ('seconds',):
            result = dt + timedelta(seconds=int(effective_value))
        elif effective_unit in ('milliseconds',):
            result = dt + timedelta(milliseconds=int(effective_value))
        else:
            return None

        return _format_result_at_input_precision(result, date_val)
    except (ValueError, OverflowError) as e:
        raise ValueError(f"DateTime arithmetic overflow: {e}") from e


def dateSubtractQuantity(date_val: str | None, quantity_json: str | None) -> str | None:
    """
    Subtract a quantity from a date/datetime.

    Args:
        date_val: ISO date/datetime string
        quantity_json: JSON string representing a FHIR Quantity with time unit

    Returns:
        Resulting date/datetime as ISO string, or None if invalid
    """
    if quantity_json is None:
        return None

    try:
        parsed_quantity = _parse_date_quantity_payload(quantity_json)
    except (orjson.JSONDecodeError, TypeError):
        return None
    if parsed_quantity is None:
        return None
    data, value, _unit = parsed_quantity
    data["value"] = -value
    negated_json = orjson.dumps(data).decode("utf-8")
    return dateAddQuantity(date_val, negated_json)


# ========================================
# Precision-Aware Temporal Operations
# CQL §18.4 (Uncertainty), §19.15-16 (Comparison with precision)
# ========================================

# Precision levels ordered from coarsest to finest
_PRECISION_ORDER = ('year', 'month', 'day', 'hour', 'minute', 'second', 'millisecond')
_PRECISION_INDEX = {p: i for i, p in enumerate(_PRECISION_ORDER)}
_HOUR_PRECISION_INDEX = _PRECISION_INDEX["hour"]


def _is_time_only_text(value: str) -> bool:
    stripped = value.strip()
    try:
        body, _tz = _split_timezone_suffix(stripped)
    except ValueError:
        body = stripped
    return body.startswith('T') or (len(body) < 10 and ':' in body and '-' not in body)


def _should_normalize_timezone_for_compare(a_str: str, b_str: str, precision_idx: int) -> bool:
    """CQL timezone normalization applies to DateTime hour-or-finer comparisons only."""
    if precision_idx < _HOUR_PRECISION_INDEX:
        return False
    if _is_time_only_text(a_str) or _is_time_only_text(b_str):
        return False
    return bool(_parse_components(a_str).get('tz') or _parse_components(b_str).get('tz'))


def _infer_precision(iso_str: str) -> str:
    """Infer CQL precision from an ISO 8601 datetime string's length/format.

    CQL §18.2: Precision is determined by the number of specified components.
    '2014'           → year
    '2014-01'        → month
    '2014-01-15'     → day
    '2014-01-15T10'  → hour  (rare but valid)
    '2014-01-15T10:30' → minute
    '2014-01-15T10:30:00' → second
    '2014-01-15T10:30:00.000' → millisecond
    """
    s = iso_str.strip()
    try:
        s, _ = _split_timezone_suffix(s)
    except ValueError:
        return 'millisecond'

    # Time-only: T-prefixed or bare HH:MM:SS
    if s.startswith('T') or (len(s) < 10 and ':' in s and '-' not in s):
        s = s.lstrip('T')
        if '.' in s:
            return 'millisecond'
        parts = s.split(':')
        if len(parts) >= 3:
            return 'second'
        if len(parts) >= 2:
            return 'minute'
        return 'hour'

    # Date/DateTime
    if 'T' in s or ' ' in s:
        sep = 'T' if 'T' in s else ' '
        date_part, time_part = s.split(sep, 1)
        if not time_part:
            # 'T' suffix with no time components (e.g., '2014T') — use date precision
            dashes = date_part.count('-')
            if dashes >= 2:
                return 'day'
            if dashes == 1:
                return 'month'
            return 'year'
        if '.' in time_part:
            return 'millisecond'
        parts = time_part.split(':')
        if len(parts) >= 3:
            return 'second'
        if len(parts) >= 2:
            return 'minute'
        return 'hour'

    # Date only
    dashes = s.count('-')
    if dashes >= 2:
        return 'day'
    if dashes == 1:
        return 'month'
    return 'year'


def _parse_components(iso_str: str) -> dict:
    """Parse ISO 8601 string into component dict with precision."""
    s = iso_str.strip()
    s, tz_suffix = _split_timezone_suffix(s)

    def _validate_components(comps: dict, *, has_time: bool) -> None:
        year = comps['year']
        month = comps['month']
        day = comps['day']
        if not 1 <= year <= 9999:
            raise ValueError(f"Invalid year {year}")
        if not 1 <= month <= 12:
            raise ValueError(f"Invalid month {month}")
        if not 1 <= day <= calendar.monthrange(year, month)[1]:
            raise ValueError(f"Invalid day {day}")
        if has_time:
            if not 0 <= comps['hour'] <= 23:
                raise ValueError(f"Invalid hour {comps['hour']}")
            if not 0 <= comps['minute'] <= 59:
                raise ValueError(f"Invalid minute {comps['minute']}")
            if not 0 <= comps['second'] <= 59:
                raise ValueError(f"Invalid second {comps['second']}")
            if not 0 <= comps['millisecond'] <= 999:
                raise ValueError(f"Invalid millisecond {comps['millisecond']}")

    # Detect Time-only strings: 'T'-prefixed or bare HH:MM:SS patterns
    is_time_only = s.startswith('T') or (len(s) < 10 and ':' in s and '-' not in s)
    if is_time_only:
        time_s = s.lstrip('T')
        comps = {'year': 1, 'month': 1, 'day': 1, 'hour': 0, 'minute': 0,
                 'second': 0, 'millisecond': 0, 'tz': tz_suffix}
        time_parts = time_s.split(':')
        if len(time_parts) >= 1:
            comps['hour'] = int(time_parts[0])
        if len(time_parts) >= 2:
            comps['minute'] = int(time_parts[1])
        if len(time_parts) >= 3:
            sec_parts = time_parts[2].split('.')
            comps['second'] = int(sec_parts[0])
            if len(sec_parts) > 1:
                ms_str = sec_parts[1][:3].ljust(3, '0')
                comps['millisecond'] = int(ms_str)
        _validate_components(comps, has_time=True)
        return comps

    comps = {'year': 1, 'month': 1, 'day': 1, 'hour': 0, 'minute': 0,
             'second': 0, 'millisecond': 0, 'tz': tz_suffix}

    # Handle 'T' or space separator
    time_str = None
    if 'T' in s:
        date_str, time_str = s.split('T', 1)
    elif ' ' in s:
        date_str, time_str = s.split(' ', 1)
    else:
        date_str = s

    # Parse date part
    date_parts = date_str.split('-')
    if len(date_parts) >= 1 and date_parts[0]:
        comps['year'] = int(date_parts[0])
    if len(date_parts) >= 2:
        comps['month'] = int(date_parts[1])
    if len(date_parts) >= 3:
        comps['day'] = int(date_parts[2])

    # Parse time part
    if time_str:
        time_parts = time_str.split(':')
        if len(time_parts) >= 1:
            comps['hour'] = int(time_parts[0])
        if len(time_parts) >= 2:
            comps['minute'] = int(time_parts[1])
        if len(time_parts) >= 3:
            sec_parts = time_parts[2].split('.')
            comps['second'] = int(sec_parts[0])
            if len(sec_parts) > 1:
                ms_str = sec_parts[1][:3].ljust(3, '0')
                comps['millisecond'] = int(ms_str)

    _validate_components(comps, has_time=bool(time_str))
    return comps


def _format_at_precision(comps: dict, precision: str) -> str:
    """Format datetime components back to ISO 8601 at the given precision."""
    prec_idx = _PRECISION_INDEX.get(precision, 6)
    result = f"{comps['year']:04d}"
    if prec_idx >= 1:
        result += f"-{comps['month']:02d}"
    if prec_idx >= 2:
        result += f"-{comps['day']:02d}"
    if prec_idx >= 3:
        result += f"T{comps['hour']:02d}"
    if prec_idx >= 4:
        result += f":{comps['minute']:02d}"
    if prec_idx >= 5:
        result += f":{comps['second']:02d}"
    if prec_idx >= 6:
        result += f".{comps['millisecond']:03d}"
    tz = comps.get('tz', '')
    if tz:
        result += tz
    return result


def _normalize_to_utc(comps: dict) -> dict:
    """Normalize datetime components to UTC using timezone offset.

    CQL §22.1: Timezone-aware datetimes are compared by normalizing to UTC.
    If no timezone is present, the components are returned unchanged.
    """
    tz = comps.get('tz', '')
    if not tz or tz == 'Z':
        result = dict(comps)
        result['tz'] = ''
        return result

    # Parse offset: +HH:MM or -HH:MM
    sign = 1 if tz[0] == '+' else -1
    tz_parts = tz[1:].split(':')
    tz_hours = int(tz_parts[0])
    tz_minutes = int(tz_parts[1]) if len(tz_parts) > 1 else 0
    offset_minutes = sign * (tz_hours * 60 + tz_minutes)

    # Convert to UTC by subtracting the offset
    from datetime import datetime, timedelta
    dt = datetime(
        comps['year'], comps['month'], comps['day'],
        comps['hour'], comps['minute'], comps['second'],
        comps['millisecond'] * 1000,  # microseconds
    )
    dt_utc = dt - timedelta(minutes=offset_minutes)

    return {
        'year': dt_utc.year,
        'month': dt_utc.month,
        'day': dt_utc.day,
        'hour': dt_utc.hour,
        'minute': dt_utc.minute,
        'second': dt_utc.second,
        'millisecond': dt_utc.microsecond // 1000,
        'tz': '',
    }


def _compare_at_min_precision(
    a_str: str,
    b_str: str,
    *,
    promote_date_to_datetime: bool = False,
    combined_seconds_ms: bool = True,
) -> tuple:
    """Compare two datetime strings at min(a_precision, b_precision).

    Returns (result, is_certain):
    - result: -1 (a < b), 0 (a == b), 1 (a > b)
    - is_certain: True if result is definite; False if uncertain (should return NULL)

    CQL §19.15: When values have differing precisions, comparison proceeds
    component by component. If one value is specified at a precision and the
    other is not, the result is null (uncertain).
    """
    # CQL 1.5 comparison signatures are same-type (Time,Time)/(Date,Date)/
    # (DateTime,DateTime); there is no implicit Time<->DateTime conversion.
    # A mixed Time/DateTime pair is undefined — report uncertain, never a
    # definitive ordering from zero-filled date components.
    if _is_time_only_text(a_str) != _is_time_only_text(b_str):
        return (0, False)

    # Guard: reject non-datetime strings (interval JSON, quantity JSON, etc.)
    for s in (a_str, b_str):
        stripped = s.strip()
        if stripped.startswith('{') or stripped.startswith('['):
            raise ValueError(f"Not a datetime string: {stripped[:50]}")

    a_prec = _infer_precision(a_str)
    b_prec = _infer_precision(b_str)
    a_idx = _PRECISION_INDEX[a_prec]
    b_idx = _PRECISION_INDEX[b_prec]
    min_idx = min(a_idx, b_idx)

    # CQL 1.5 (DateTime/Time type semantics, §Equal): seconds and milliseconds
    # are combined and represented as a single decimal precision for the
    # purposes of comparison, with an unspecified milliseconds component
    # treated as 0. So `@T10:00:00.0 = @T10:00:00` is TRUE (not uncertain)
    # and `@T10:00:00.5 = @T10:00:00` is FALSE (certain).
    combined_sec_ms = (
        combined_seconds_ms and {a_prec, b_prec} == {'second', 'millisecond'}
    )
    if combined_sec_ms:
        min_idx = _PRECISION_INDEX['millisecond']

    a_comps = _parse_components(a_str)
    b_comps = _parse_components(b_str)

    # CQL DateTime comparison normalizes timezone offsets only for hour-or-finer
    # precision. Time values compare their specified components directly.
    if _should_normalize_timezone_for_compare(a_str, b_str, min_idx):
        a_comps = _normalize_to_utc(a_comps)
        b_comps = _normalize_to_utc(b_comps)

    for i, field in enumerate(_PRECISION_ORDER[:min_idx + 1]):
        a_val = a_comps[field]
        b_val = b_comps[field]
        if a_val < b_val:
            return (-1, True)
        if a_val > b_val:
            return (1, True)

    # All compared components are equal. Public CQL comparison operators must
    # treat differing precision as uncertain, but interval-boundary helpers use
    # closed endpoint normalization and need full-day Date bounds promoted.
    # The second/millisecond pair is exempt: they are one combined decimal
    # precision, so equality there is certain.
    if a_idx != b_idx and not combined_sec_ms:
        if not promote_date_to_datetime:
            return (0, False)

        # Interval boundary compatibility: promote a full Date to midnight
        # DateTime when the other side has explicit time components.
        a_has_time_sep = 'T' in a_str or ' ' in a_str[10:11]
        b_has_time_sep = 'T' in b_str or ' ' in b_str[10:11]
        a_is_date_only = (not a_has_time_sep and len(a_str.split('+')[0].split('Z')[0]) == 10)
        b_is_date_only = (not b_has_time_sep and len(b_str.split('+')[0].split('Z')[0]) == 10)

        if a_is_date_only and b_has_time_sep and not b_is_date_only:
            promoted = a_str + 'T00:00:00.000'
            a_comps2 = _parse_components(promoted)
            b_comps2 = b_comps
            new_max = _PRECISION_INDEX[_infer_precision(promoted)]
            compare_to = min(new_max, b_idx)
            if _should_normalize_timezone_for_compare(promoted, b_str, compare_to):
                a_comps2 = _normalize_to_utc(a_comps2)
                b_comps2 = _normalize_to_utc(b_comps2)
            for field in _PRECISION_ORDER[:compare_to + 1]:
                av = a_comps2[field]
                bv = b_comps2[field]
                if av < bv:
                    return (-1, True)
                if av > bv:
                    return (1, True)
            return (0, True)

        if b_is_date_only and a_has_time_sep and not a_is_date_only:
            promoted = b_str + 'T00:00:00.000'
            a_comps2 = a_comps
            b_comps2 = _parse_components(promoted)
            new_max = _PRECISION_INDEX[_infer_precision(promoted)]
            compare_to = min(a_idx, new_max)
            if _should_normalize_timezone_for_compare(a_str, promoted, compare_to):
                a_comps2 = _normalize_to_utc(a_comps2)
                b_comps2 = _normalize_to_utc(b_comps2)
            for field in _PRECISION_ORDER[:compare_to + 1]:
                av = a_comps2[field]
                bv = b_comps2[field]
                if av < bv:
                    return (-1, True)
                if av > bv:
                    return (1, True)
            return (0, True)

        return (0, False)  # equal so far, but uncertain due to unspecified components

    return (0, True)  # fully equal at same precision


def cqlSameOrBefore(a: str | None, b: str | None) -> bool | None:
    """CQL SameOrBefore without explicit precision (§19.16).

    Returns True if a <= b at min precision, None if uncertain.
    """
    if a is None or b is None:
        return None
    a_s, b_s = str(a), str(b)
    try:
        cmp, certain = _compare_at_min_precision(a_s, b_s)
    except (ValueError, KeyError, OverflowError):
        return None
    if cmp < 0:
        return True
    if cmp > 0:
        return False
    # cmp == 0: equal at compared precision
    if not certain:
        return None  # uncertain — different precisions
    return True  # same at same precision → True


def cqlSameOrAfter(a: str | None, b: str | None) -> bool | None:
    """CQL SameOrAfter without explicit precision (§19.17)."""
    if a is None or b is None:
        return None
    a_s, b_s = str(a), str(b)
    try:
        cmp, certain = _compare_at_min_precision(a_s, b_s)
    except (ValueError, KeyError, OverflowError):
        return None
    if cmp > 0:
        return True
    if cmp < 0:
        return False
    if not certain:
        return None
    return True


def cqlBefore(a: str | None, b: str | None) -> bool | None:
    """CQL Before without explicit precision (§19.20)."""
    if a is None or b is None:
        return None
    a_s, b_s = str(a), str(b)
    try:
        cmp, certain = _compare_at_min_precision(a_s, b_s)
    except (ValueError, KeyError, OverflowError):
        return None
    if cmp < 0:
        return True
    if cmp > 0:
        return False
    if not certain:
        return None
    return False


def cqlAfter(a: str | None, b: str | None) -> bool | None:
    """CQL After without explicit precision (§19.21)."""
    if a is None or b is None:
        return None
    a_s, b_s = str(a), str(b)
    try:
        cmp, certain = _compare_at_min_precision(a_s, b_s)
    except (ValueError, KeyError, OverflowError):
        return None
    if cmp > 0:
        return True
    if cmp < 0:
        return False
    if not certain:
        return None
    return False


def cqlDateTimeEqual(a: str | None, b: str | None) -> bool | None:
    """CQL DateTime equality (§12.1). Returns null if uncertain."""
    if a is None or b is None:
        return None
    a_s, b_s = str(a), str(b)
    cmp, certain = _compare_at_min_precision(a_s, b_s)
    if cmp != 0:
        return False
    if not certain:
        return None
    return True


def cqlDateTimeEqualListElement(a: str | None, b: str | None) -> bool | None:
    """List-element temporal equality (§10.3/§10.4 Equal (List) elements).

    Unlike direct ``=`` (where seconds+milliseconds are one combined decimal
    precision per §12.1, making ``T10:00:00.0 = T10:00:00`` certain), list
    element comparisons follow the §Equal precision-uncertainty rule: a
    second-vs-millisecond precision mismatch on the element type is
    UNCERTAIN (null), pinned by the official fixtures ProperContainsTimeNull
    / ProperInTimeNull (``{...@T15:59:59.999...} properly includes @T15:59:59``
    -> null) with no counter-pinning fixture for direct element equality.
    """
    if a is None or b is None:
        return None
    a_s, b_s = str(a), str(b)
    try:
        cmp, certain = _compare_at_min_precision(a_s, b_s, combined_seconds_ms=False)
    except (ValueError, KeyError, OverflowError):
        # Malformed temporal text: match the native C++
        # CqlDateTimeEqualListElementFunc, which returns NULL (validity
        # mask) on unparseable input instead of raising.
        return None
    if cmp != 0:
        return False
    if not certain:
        return None
    return True


def _extract_datetime_from_interval(s: str) -> str:
    """If *s* is an interval/period JSON string, return its start datetime.

    Handles both CQL interval format (``low``/``high``) and FHIR Period
    format (``start``/``end``).  If *s* is already a plain datetime string
    it is returned unchanged.
    """
    stripped = s.strip()
    if not stripped.startswith("{"):
        return s
    try:
        import orjson
        data = orjson.loads(stripped)
    except Exception:
        return s
    if not isinstance(data, dict):
        return s
    start = data.get("low") or data.get("start")
    if start is not None:
        return str(start)
    return s


def _compare_at_specified_precision(a_str: str, b_str: str, precision: str) -> tuple:
    """Compare two datetime strings at a specific precision.

    CQL §19.15: When precision is specified, compare components up to that
    precision. If either operand has coarser precision than specified,
    the result is uncertain (null).

    Returns (result, is_certain):
    - result: -1 (a < b), 0 (a == b), 1 (a > b)
    - is_certain: False if either operand is coarser than the target precision
    """
    # Unwrap interval JSON to its start datetime if needed
    if precision not in _PRECISION_INDEX:
        raise KeyError(f"Invalid temporal precision: {precision}")

    a_str = _extract_datetime_from_interval(a_str)
    b_str = _extract_datetime_from_interval(b_str)

    # CQL 1.5 comparison signatures are same-type; a mixed Time/DateTime
    # operand pair is undefined — uncertain (null), never a definitive
    # ordering derived from zero-filled date components.
    if _is_time_only_text(a_str) != _is_time_only_text(b_str):
        return (0, False)

    a_prec = _infer_precision(a_str)
    b_prec = _infer_precision(b_str)
    a_idx = _PRECISION_INDEX.get(a_prec, 0)
    b_idx = _PRECISION_INDEX.get(b_prec, 0)
    target_idx = _PRECISION_INDEX.get(precision, 2)

    a_comps = _parse_components(a_str)
    b_comps = _parse_components(b_str)

    # CQL Reference v1.5.3: timezone offsets are normalized for DateTime
    # comparisons only at hour/minute/second/millisecond precision.
    if _should_normalize_timezone_for_compare(a_str, b_str, target_idx):
        a_comps = _normalize_to_utc(a_comps)
        b_comps = _normalize_to_utc(b_comps)

    # If either operand is coarser than the target precision, uncertain
    if a_idx < target_idx or b_idx < target_idx:
        # Compare what we can, then report uncertainty
        usable_idx = min(a_idx, b_idx, target_idx)
        for i, field in enumerate(_PRECISION_ORDER[:usable_idx + 1]):
            a_val = a_comps[field]
            b_val = b_comps[field]
            if a_val < b_val:
                return (-1, True)  # definitely less even with uncertainty
            if a_val > b_val:
                return (1, True)  # definitely greater
        return (0, False)  # equal at shared precision, but uncertain at target

    # Both have sufficient precision — compare up to target
    for i, field in enumerate(_PRECISION_ORDER[:target_idx + 1]):
        a_val = a_comps[field]
        b_val = b_comps[field]
        if a_val < b_val:
            return (-1, True)
        if a_val > b_val:
            return (1, True)

    return (0, True)


def cqlSameOrBeforeP(a: str | None, b: str | None, precision: str | None) -> bool | None:
    """CQL SameOrBefore at specified precision (§19.16)."""
    if a is None or b is None:
        return None
    try:
        cmp, certain = _compare_at_specified_precision(str(a), str(b), str(precision))
    except (ValueError, KeyError, OverflowError):
        return None
    if cmp < 0:
        return True
    if cmp > 0:
        return False
    if not certain:
        return None
    return True


def cqlSameOrAfterP(a: str | None, b: str | None, precision: str | None) -> bool | None:
    """CQL SameOrAfter at specified precision (§19.17)."""
    if a is None or b is None:
        return None
    try:
        cmp, certain = _compare_at_specified_precision(str(a), str(b), str(precision))
    except (ValueError, KeyError, OverflowError):
        return None
    if cmp > 0:
        return True
    if cmp < 0:
        return False
    if not certain:
        return None
    return True


def cqlBeforeP(a: str | None, b: str | None, precision: str | None) -> bool | None:
    """CQL Before at specified precision (§19.20)."""
    if a is None or b is None:
        return None
    try:
        cmp, certain = _compare_at_specified_precision(str(a), str(b), str(precision))
    except (ValueError, KeyError, OverflowError):
        return None
    if cmp < 0:
        return True
    if cmp > 0:
        return False
    if not certain:
        return None
    return False


def cqlAfterP(a: str | None, b: str | None, precision: str | None) -> bool | None:
    """CQL After at specified precision (§19.21)."""
    if a is None or b is None:
        return None
    try:
        cmp, certain = _compare_at_specified_precision(str(a), str(b), str(precision))
    except (ValueError, KeyError, OverflowError):
        return None
    if cmp > 0:
        return True
    if cmp < 0:
        return False
    if not certain:
        return None
    return False


def cqlSameAsP(a: str | None, b: str | None, precision: str | None) -> bool | None:
    """CQL SameAs at specified precision (§19.14)."""
    if a is None or b is None:
        return None
    try:
        cmp, certain = _compare_at_specified_precision(str(a), str(b), str(precision))
    except (ValueError, KeyError, OverflowError):
        return None
    if cmp != 0:
        return False
    if not certain:
        return None
    return True


def cqlDateTimeAdd(dt_str: str | None, qty_json: str | None) -> str | None:
    """CQL DateTime add with precision preservation (§18.9).

    Adds a quantity to a datetime, preserving the input precision in the result.
    E.g., adding 5 hours to '2014-01-01' (day precision) returns '2014-01-01'
    (day precision preserved), not '2014-01-01T05:00:00'.
    """
    if dt_str is None or qty_json is None:
        return None

    # Delegate to dateAddQuantity for the actual computation
    full_result = dateAddQuantity(str(dt_str), str(qty_json))
    if full_result is None:
        return None

    # Preserve the input precision in the output
    input_prec = _infer_precision(str(dt_str))
    result_comps = _parse_components(full_result)
    return _format_at_precision(result_comps, input_prec)


def registerDatetimeUdfs(con: "duckdb.DuckDBPyConnection") -> None:
    """
    Register datetime UDFs.

    Note: Functions covered by macros (YearsBetween, MonthsBetween, DaysBetween,
    HoursBetween, MinutesBetween, SecondsBetween, Now, Today, TimeOfDay, Year,
    Month, Day, Hour, Minute, Second) are NOT registered here to avoid conflicts.
    DuckDB function names are case-insensitive.

    Only functions NOT covered by macros are registered here:
    - weeksBetween, millisecondsBetween (no macro equivalents)
    - dateTimeNow, dateTimeToday, dateTimeTimeOfDay (different names)
    - differenceInYears, differenceInMonths, differenceInDays (different semantics)
    - dateComponent (dynamic component extraction)
    - dateTimeSameAs, dateTimeSameOrBefore, dateTimeSameOrAfter (precision-based comparison)
    - cqlSameOrBefore, cqlSameOrAfter, cqlBefore, cqlAfter (precision-aware)
    """
    # Register ALL Between functions as Python UDFs (macros removed —
    # Python UDFs handle partial ISO 8601 strings and return uncertainty
    # intervals per CQL §22.21).
    # DuckDB function names are case-insensitive — register once only.
    con.create_function("YearsBetween", yearsBetween, null_handling="special")
    con.create_function("MonthsBetween", monthsBetween, null_handling="special")
    # weeks/milliseconds: the translator emits the camelCase spellings
    # (weeksBetween / millisecondsBetween — matching the C++ registration);
    # DuckDB names are case-insensitive so this covers both spellings on
    # pure-Python connections.
    con.create_function("weeksBetween", weeksBetween, null_handling="special")
    con.create_function("DaysBetween", daysBetween, null_handling="special")
    con.create_function("HoursBetween", hoursBetween, null_handling="special")
    con.create_function("MinutesBetween", minutesBetween, null_handling="special")
    con.create_function("SecondsBetween", secondsBetween, null_handling="special")
    con.create_function("millisecondsBetween", millisecondsBetween, null_handling="special")
    # Now/Today/TimeOfDay with different names (not conflicting with macros)
    con.create_function("dateTimeNow", dateTimeNow, null_handling="special")
    con.create_function("dateTimeToday", dateTimeToday, null_handling="special")
    con.create_function("dateTimeTimeOfDay", dateTimeTimeOfDay, null_handling="special")
    # Difference functions (different semantics than Between functions)
    con.create_function("differenceInYears", differenceInYears, null_handling="special")
    con.create_function("differenceInMonths", differenceInMonths, null_handling="special")
    con.create_function("differenceInDays", differenceInDays, null_handling="special")
    con.create_function("differenceInWeeks", differenceInWeeks, null_handling="special")
    con.create_function("differenceInHours", differenceInHours, null_handling="special")
    con.create_function("differenceInMinutes", differenceInMinutes, null_handling="special")
    con.create_function("differenceInSeconds", differenceInSeconds, null_handling="special")
    con.create_function("differenceInMilliseconds", differenceInMilliseconds, null_handling="special")
    con.create_function("dateComponent", dateComponent, null_handling="special")
    # DateTime comparison with precision
    con.create_function("dateTimeSameAs", dateTimeSameAs, null_handling="special")
    con.create_function("dateTimeSameOrBefore", dateTimeSameOrBefore, null_handling="special")
    con.create_function("dateTimeSameOrAfter", dateTimeSameOrAfter, null_handling="special")
    # Date arithmetic with quantity
    con.create_function("quantityToInterval", quantityToInterval, null_handling="special")
    con.create_function("dateAddQuantity", dateAddQuantity, null_handling="special")
    con.create_function("dateSubtractQuantity", dateSubtractQuantity, null_handling="special")
    # Precision-aware temporal comparison UDFs (CQL §18.4, §19.15-16)
    con.create_function("cqlSameOrBefore", cqlSameOrBefore, null_handling="special")
    con.create_function("cqlSameOrAfter", cqlSameOrAfter, null_handling="special")
    con.create_function("cqlBefore", cqlBefore, null_handling="special")
    con.create_function("cqlAfter", cqlAfter, null_handling="special")
    con.create_function("cqlDateTimeEqual", cqlDateTimeEqual, null_handling="special")
    con.create_function("cqlDateTimeEqualListElement", cqlDateTimeEqualListElement, null_handling="special")
    # Precision-aware arithmetic (preserves input precision in output)
    con.create_function("cqlDateTimeAdd", cqlDateTimeAdd, null_handling="special")
    # Precision-qualified temporal comparison UDFs (CQL §19.14-21)
    con.create_function("cqlSameOrBeforeP", cqlSameOrBeforeP, null_handling="special")
    con.create_function("cqlSameOrAfterP", cqlSameOrAfterP, null_handling="special")
    con.create_function("cqlBeforeP", cqlBeforeP, null_handling="special")
    con.create_function("cqlAfterP", cqlAfterP, null_handling="special")
    con.create_function("cqlSameAsP", cqlSameAsP, null_handling="special")
    # Uncertainty arithmetic UDFs (CQL §22.21 — interval propagation)
    con.create_function("cqlUncertainAdd", cqlUncertainAdd, null_handling="special")
    con.create_function("cqlUncertainSubtract", cqlUncertainSubtract, null_handling="special")
    con.create_function("cqlUncertainMultiply", cqlUncertainMultiply, null_handling="special")
    con.create_function("cqlUncertainCompare", cqlUncertainCompare, null_handling="special")
    # CQL-21 HISTORIAN QA-001..003: uncertainty-aware Min/Max for age-family
    # (§22.21 VARCHAR) operands — scalar pair form and list-aggregate form.
    con.create_function("cqlUncertainMin", cqlUncertainMin, null_handling="special")
    con.create_function("cqlUncertainMax", cqlUncertainMax, null_handling="special")
    con.create_function("cqlUncertainListMin", cqlUncertainListMin, null_handling="special")
    con.create_function("cqlUncertainListMax", cqlUncertainListMax, null_handling="special")
    con.create_function("cqlUncertainListSum", cqlUncertainListSum, null_handling="special")
    # Uncertainty-aware DurationBetween (returns VARCHAR — int string or interval JSON)
    con.create_function("cqlDurationBetween", cqlDurationBetween, null_handling="special")
    con.create_function("cqlDifferenceBetween", cqlDifferenceBetween, null_handling="special")


__all__ = [
    "registerDatetimeUdfs",
    "yearsBetween",
    "monthsBetween",
    "weeksBetween",
    "daysBetween",
    "hoursBetween",
    "minutesBetween",
    "secondsBetween",
    "millisecondsBetween",
    # Now/Today/TimeOfDay functions
    "dateTimeNow",
    "dateTimeToday",
    "dateTimeTimeOfDay",
    # DifferenceBetween functions
    "differenceInYears",
    "differenceInMonths",
    "differenceInDays",
    "cqlDifferenceBetween",
    "dateComponent",
    # DateTime comparison functions
    "dateTimeSameAs",
    "dateTimeSameOrBefore",
    "dateTimeSameOrAfter",
    # Date arithmetic with quantity
    "quantityToInterval",
    "dateAddQuantity",
    "dateSubtractQuantity",
]
