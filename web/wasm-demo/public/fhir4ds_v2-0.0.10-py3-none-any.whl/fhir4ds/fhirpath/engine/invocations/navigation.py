from collections import abc
from decimal import Decimal
from functools import reduce
import json
from ...engine import util as util
from ...engine import nodes as nodes

create_node = nodes.ResourceNode.create_node


def resolve(ctx, reference_collection):
    """
    Resolve a Reference to its target resource.

    For in-Bundle resolution:
    - Parse reference.reference (e.g., "Patient/123", "urn:uuid:...")
    - Search Bundle.entry for matching resource

    Args:
        ctx: Evaluation context with model and vars
        reference_collection: Collection of Reference objects

    Returns:
        Collection of resolved resources (or empty if not found)
    """
    if util.is_empty(reference_collection):
        return []

    results = []
    for ref in reference_collection:
        # Get the data from ResourceNode if needed
        ref_data = util.get_data(ref)

        if not isinstance(ref_data, dict):
            continue

        reference_str = ref_data.get('reference')
        if not reference_str:
            continue

        # Try to resolve from context (Bundle)
        resolved = _resolve_reference(ctx, reference_str)
        if resolved:
            results.append(resolved)

    return results


def _resolve_reference(ctx, reference_str):
    """Resolve a reference string to a resource."""
    # Get the root resource from dataRoot
    data_root = ctx.get('dataRoot', [])
    root_resource = data_root[0] if data_root else None

    if not root_resource:
        return None

    # Get the actual data if it's a ResourceNode
    root_data = util.get_data(root_resource)

    # Handle contained resource references (#id)
    if reference_str.startswith('#'):
        contained_id = reference_str[1:]  # Remove '#' prefix
        # Search the current resource's contained array
        if isinstance(root_data, dict):
            contained = root_data.get('contained', [])
            for resource in contained:
                resource_data = util.get_data(resource)
                if isinstance(resource_data, dict) and resource_data.get('id') == contained_id:
                    return resource
        return None

    # Handle Bundle.entry resolution
    if isinstance(root_data, dict) and root_data.get('resourceType') == 'Bundle':
        entries = root_data.get('entry', [])

        for entry in entries:
            resource = entry.get('resource')
            if not resource:
                continue

            # Get actual data if resource is a ResourceNode
            resource_data = util.get_data(resource)

            # Match by reference type
            if reference_str.startswith('urn:uuid:'):
                # UUID reference - match full.id or just the uuid part
                uuid_part = reference_str[9:]  # Remove "urn:uuid:" prefix
                if resource_data.get('id') == uuid_part:
                    return resource
            elif '/' in reference_str:
                # Resource type reference: "Patient/123" or "http://server/Patient/123"
                parts = reference_str.split('/')
                if len(parts) >= 2:
                    # Handle absolute URLs by taking last two parts
                    res_type = parts[-2]
                    res_id = parts[-1]
                    if resource_data.get('resourceType') == res_type and resource_data.get('id') == res_id:
                        return resource
            else:
                # Simple id reference (less common)
                if resource_data.get('id') == reference_str:
                    return resource

    return None


def create_reduce_children(ctx, exclude_primitive_extensions):
    model = ctx["model"]

    def func(acc, res):
        data = util.get_data(res)
        res = create_node(res)

        if isinstance(data, list):
            data = dict((i, data[i]) for i in range(0, len(data)))

        if not isinstance(data, abc.Mapping) and isinstance(getattr(res, "_data", None), abc.Mapping):
            data = res._data

        if isinstance(data, abc.Mapping):
            for prop in data.keys():
                value = data[prop]
                childPath = ""

                if prop == "resourceType":
                    continue

                # extensions shouldn't filter through here, yet they should for descendants?
                # unless this item is the node that is being processed (primitive extension)
                # though if you filter it, descendants will not work too
                if prop.startswith("_") and exclude_primitive_extensions:
                    continue

                if res.path is not None:
                    childPath = res.path + "." + prop

                fullPath = f"{res.propName}.{prop}" if res.propName else childPath # The full path to the node (weill evenutally be) e.g. Patient.name[0].given
                fullPath = fullPath.replace("_", "")

                if prop == "extension":
                    childPath = "Extension"

                if (
                    isinstance(model, dict)
                    and "pathsDefinedElsewhere" in model
                    and childPath in model["pathsDefinedElsewhere"]
                ):
                    childPath = model["pathsDefinedElsewhere"][childPath]

                childPath = (
                    model["path2Type"].get(childPath, childPath)
                    if isinstance(model, dict) and "path2Type" in model
                    else childPath
                )

                # If the prop tolower ends with the type tolower
                if res.path is not None and prop.lower().endswith(childPath.lower()) and len(prop) > len(childPath):
                    # Check if the path is actually in the choice types
                    altPropName = res.path + "." + prop[:-len(childPath)]
                    actualTypes = model["choiceTypePaths"].get(altPropName, [])
                    if len(actualTypes) > 0:
                        # If it is, we can use it
                        fullPath = f"{res.propName}.{prop[:-len(childPath)]}"

                shadow_value = data.get(f"_{prop}") if isinstance(prop, str) else None

                if isinstance(value, list):
                    shadow_items = shadow_value if isinstance(shadow_value, list) else []
                    mapped = [
                        create_node(
                            n,
                            childPath,
                            _data=shadow_items[i] if i < len(shadow_items) else None,
                            propName=f"{fullPath}[{i}]",
                            index=i,
                        )
                        for i, n in enumerate(value)
                    ]
                    acc = acc + mapped
                else:
                    acc.append(create_node(value, childPath, _data=shadow_value, propName=fullPath))
        return acc

    return func


def children(ctx, coll):
    return reduce(create_reduce_children(ctx, True), coll, [])


def descendants(ctx, coll):
    from collections import deque

    result = []
    seen = set()
    # FHIRPath §5.8.2 defines descendants() as shorthand for repeat(children()),
    # so it must use the same child projection as children().
    queue = deque(coll)
    while queue:
        item = queue.popleft()
        new_children = []
        pending = set()
        for child in reduce(create_reduce_children(ctx, True), [item], []):
            key = _descendant_repeat_key(child)
            if key not in seen and key not in pending:
                new_children.append(child)
                pending.add(key)
        result.extend(new_children)
        seen.update(pending)
        queue.extend(new_children)
    return result


def _descendant_repeat_key(item):
    data = util.get_data(item)
    if data is None:
        return ("null", None)
    if isinstance(data, bool):
        return ("boolean", data)
    if isinstance(data, (int, float, Decimal)) and not isinstance(data, bool):
        return ("number", str(Decimal(str(data)).normalize()))
    if isinstance(data, (dict, list)):
        return ("json", json.dumps(data, sort_keys=True, separators=(",", ":"), default=str))
    return (type(data).__name__, str(data))


def get_resource_key(ctx, coll):
    """Return {resourceType}/{id} for the current resource.

    Per SQL-on-FHIR v2, getResourceKey() returns the canonical key for the
    root resource being processed. The input collection is the resource itself.
    """
    if util.is_empty(coll):
        return []
    results = []
    for item in coll:
        data = util.get_data(item)
        if isinstance(data, dict):
            rt = data.get('resourceType', '')
            rid = data.get('id', '')
            if rt and rid:
                results.append(f"{rt}/{rid}")
    return results


def get_reference_key(ctx, coll, type_arg=None):
    """Resolve a Reference element to {resourceType}/{id}.

    Per SQL-on-FHIR v2, getReferenceKey() extracts the reference string from
    a FHIR Reference element. If a type argument is provided, returns empty
    when the reference doesn't match that type.

    Args:
        ctx: Evaluation context.
        coll: Collection of Reference elements.
        type_arg: Optional TypeInfo to filter by (e.g., Patient).
    """
    if util.is_empty(coll):
        return []
    results = []
    for item in coll:
        data = util.get_data(item)
        if isinstance(data, dict):
            ref = data.get('reference', '')
            if not ref:
                continue
            if type_arg is not None:
                type_name = type_arg.name if hasattr(type_arg, 'name') else str(type_arg)
                if not ref.startswith(type_name + '/'):
                    continue
            results.append(ref)
    return results
