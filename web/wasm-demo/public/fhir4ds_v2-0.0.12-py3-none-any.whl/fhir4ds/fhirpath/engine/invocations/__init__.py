from decimal import Decimal

from ...engine.invocations import collections as collections
from ...engine.invocations import existence as existence
from ...engine.invocations import filtering as filtering
from ...engine.invocations import subsetting as subsetting
from ...engine.invocations import strings as strings
from ...engine.invocations import navigation as navigation
from ...engine.invocations import combining as combining
from ...engine.invocations import math as math
from ...engine.invocations import misc as misc
from ...engine.invocations import equality as equality
from ...engine.invocations import logic as logic
from ...engine.invocations import datetime as datetime
from ...engine.invocations import types as types
from ...engine.invocations import aggregate as aggregate
from ...engine.nodes import FP_DateTime, FP_Date, FP_Quantity, FP_Time

invocation_registry = {
    "empty": {"fn": existence.empty_fn},
    "not": {"fn": existence.not_fn},
    "exists": {"fn": existence.exists_macro, "arity": {0: [], 1: ["Expr"]}},
    "all": {"fn": existence.all_macro, "arity": {1: ["Expr"]}},
    "union": {"fn": combining.union_op,   "arity": {1: ["AnyAtRoot"]}},
    "exclude": {"fn": combining.exclude_fn,   "arity": {1: ["AnyAtRoot"]}},
    "allTrue": {"fn": existence.all_true_fn},
    "anyTrue": {"fn": existence.any_true_fn},
    "allFalse": {"fn": existence.all_false_fn},
    "anyFalse": {"fn": existence.any_false_fn},
    "subsetOf": {"fn": existence.subset_of_fn, "arity": {1: ["AnyAtRoot"]}},
    "supersetOf": {"fn": existence.superset_of_fn, "arity": {1: ["AnyAtRoot"]}},
    "isDistinct": {"fn": existence.isdistinct_fn},
    "distinct": {"fn": existence.distinct_fn},
    "hasValue": {"fn": existence.has_value_fn},
    "getValue": {"fn": existence.get_value_fn},
    "count": {"fn": existence.count_fn},
    "repeat": {"fn": filtering.repeat_macro, "arity": {1: ["Expr"]}},
    "where": {"fn": filtering.where_macro, "arity": {1: ["Expr"]}},
    "extension": {"fn": filtering.extension, "arity": {0: [], 1: ["String"]}},
    "select": {"fn": filtering.select_macro, "arity": {1: ["Expr"]}},
    "single": {"fn": filtering.single_fn},
    "first": {"fn": filtering.first_fn},
    "last": {"fn": filtering.last_fn},
    "ofType": {"fn": filtering.of_type_fn, "arity": {1: ["TypeSpecifier"]}},
    "type": {"fn": types.type_fn, "arity": {0: []}},
    "is": {"fn": types.is_fn, "arity": {1: ["TypeSpecifier"]}},
    "as": {"fn": types.as_fn, "arity": {1: ["TypeSpecifier"]}},
    "tail": {"fn": filtering.tail_fn},
    "take": {"fn": filtering.take_fn, "arity": {1: ["Integer"]}},
    "skip": {"fn": filtering.skip_fn, "arity": {1: ["Integer"]}},
    "intersect": {"fn": subsetting.intersect_fn, "arity": {1: ["AnyAtRoot"]}},
    "combine": {"fn": combining.combine_fn, "arity": {1: ["AnyAtRoot"], 2: ["AnyAtRoot", "Boolean"]}},
    "iif": {"fn": misc.iif_macro, "arity": {2: ["Expr", "Expr"], 3: ["Expr", "Expr", "Expr"]}},
    "trace": {"fn": misc.trace_fn, "arity": {1: ["String"], 2: ["String", "Expr"]}},
    "defineVariable": {"fn": misc.define_variable, "arity": {1: ["String"], 2: ["String", "Expr"]}},
    "toInteger": {"fn": misc.to_integer},
    "toBoolean": {"fn": misc.to_boolean},
    "toDecimal": {"fn": misc.to_decimal, "arity": {0: []}},
    "toString": {"fn": misc.to_string, "arity": {0: []}},
    "toDate": {"fn": misc.to_date, "arity": {0: [], 1: ["String"]}},
    "toDateTime": {"fn": misc.to_date_time, "arity": {0: [], 1: ["String"]}},
    "toTime": {"fn": misc.to_time, "arity": {0: []}},
    "toQuantity": {"fn": misc.to_quantity, "arity": {0: [], 1: ["String"]}},
    "indexOf": {"fn": strings.index_of, "arity": {1: ["String"]}, "nullable_input": True},
    "substring": {
        "fn": strings.substring,
        "arity": {1: ["Integer"], 2: ["Integer", "Integer"]},
        "nullable_input": True,
    },
    "startsWith": {"fn": strings.starts_with, "arity": {1: ["String"]}, "nullable_input": True},
    "endsWith": {"fn": strings.ends_with, "arity": {1: ["String"]}, "nullable_input": True},
    "contains": {"fn": strings.contains_fn, "arity": {1: ["String"]}, "nullable_input": True},
    "upper": {"fn": strings.upper, "arity": {0: ["String"]}, "nullable_input": True},
    "lower": {"fn": strings.lower, "arity": {0: ["String"]}, "nullable_input": True},
    "replace": {"fn": strings.replace, "arity": {2: ["String", "String"]}, "nullable_input": True},
    "matches": {"fn": strings.matches, "arity": {1: ["String"], 2: ["String", "String"]}, "nullable_input": True},
    "replaceMatches": {
        "fn": strings.replace_matches,
        "arity": {2: ["String", "String"], 3: ["String", "String", "String"]},
        "nullable_input": True,
    },
    "length": {"fn": strings.length, "nullable_input": True},
    "toChars": {"fn": strings.toChars},
    "join": {"fn": strings.join, "arity": {0: [], 1: ["String"]}},
    "split": {"fn": strings.split, "arity": {1: ["String"]}, "nullable_input": True},
    "trim": {"fn": strings.trim, "nullable_input": True},
    "encode": {"fn": strings.encode, "arity": {1: ["String"]}},
    "decode": {"fn": strings.decode, "arity": {1: ["String"]}},
    "escape": {"fn": strings.escape, "arity": {1: ["String"]}, "nullable_input": True},
    "unescape": {"fn": strings.unescape, "arity": {1: ["String"]}, "nullable_input": True},
    "abs": {"fn": math.abs, "arity": {0: []}},
    "ceiling": {"fn": math.ceiling, "arity": {0: []}},
    "exp": {"fn": math.exp, "arity": {0: []}},
    "floor": {"fn": math.floor, "arity": {0: []}},
    "ln": {"fn": math.ln, "arity": {0: []}},
    "log": {"fn": math.log, "arity": {1: ["Number"]}, "nullable": True},
    "power": {"fn": math.power, "arity": {1: ["Number"]}, "nullable": True},
    "round": {"fn": math.rround, "arity": {0: [], 1: ["Number"]}},
    "sqrt": {"fn": math.sqrt, "arity": {0: []}},
    "truncate": {"fn": math.truncate, "arity": {0: []}},
    "now": {"fn": datetime.now},
    "today": {"fn": datetime.today},
    "timeOfDay": {"fn": datetime.timeOfDay},
    "lowBoundary": {"fn": datetime.lowBoundary, "arity": {0: [], 1: ["Integer"]}},
    "highBoundary": {"fn": datetime.highBoundary, "arity": {0: [], 1: ["Integer"]}},
    "precision": {"fn": datetime.precision},
    "sort": {"fn": collections.sort_fn, "arity": {0: [], 1: ["Expr"], 2: ["Expr", "Expr"]}},
    "matchesFull": {"fn": strings.matchesFull, "arity": {1: ["String"]}, "nullable_input": True},
    "comparable": {"fn": collections.comparable, "arity": {1: ["Any"]}},
    "children": {"fn": navigation.children},
    "descendants": {"fn": navigation.descendants},
    "resolve": {"fn": navigation.resolve},
    "getResourceKey": {"fn": navigation.get_resource_key, "arity": {0: []}},
    "getReferenceKey": {"fn": navigation.get_reference_key, "arity": {0: [], 1: ["TypeSpecifier"]}},
    "|": {"fn": combining.union_op, "arity": {2: ["Any", "Any"]}},
    "=": {"fn": equality.equal, "arity": {2: ["Any", "Any"]}, "nullable": True},
    "!=": {"fn": equality.unequal, "arity": {2: ["Any", "Any"]}, "nullable": True},
    "~": {"fn": equality.equival, "arity": {2: ["Any", "Any"]}},
    "!~": {"fn": equality.unequival, "arity": {2: ["Any", "Any"]}},
    "<": {"fn": equality.lt, "arity": {2: ["Any", "Any"]}, "nullable": True},
    ">": {"fn": equality.gt, "arity": {2: ["Any", "Any"]}, "nullable": True},
    "<=": {"fn": equality.lte, "arity": {2: ["Any", "Any"]}, "nullable": True},
    ">=": {"fn": equality.gte, "arity": {2: ["Any", "Any"]}, "nullable": True},
    "containsOp": {"fn": collections.contains, "arity": {2: ["Any", "Any"]}},
    "inOp": {"fn": collections.inn, "arity": {2: ["Any", "Any"]}},
    "isOp": {"fn": types.is_fn,  "arity": {2: ["Any", "TypeSpecifier"]}},
    "asOp": {"fn": types.as_fn,  "arity": {2: ["Any", "TypeSpecifier"]}},
    "&": {"fn": math.amp, "arity": {2: ["Any", "Any"]}},
    "+": {"fn": math.plus, "arity": {2: ["Any", "Any"]}, "nullable": True},
    "-": {"fn": math.minus, "arity": {2: ["Any", "Any"]}, "nullable": True},
    "*": {"fn": math.mul, "arity": {2: ["Number", "Number"]}, "nullable": True},
    "/": {"fn": math.div, "arity": {2: ["Number", "Number"]}, "nullable": True},
    "mod": {"fn": math.mod, "arity": {2: ["Number", "Number"]}, "nullable": True},
    "div": {"fn": math.intdiv, "arity": {2: ["Number", "Number"]}, "nullable": True},
    "or": {"fn": logic.or_op, "arity": {2: [["Any"], ["Any"]]}},
    "and": {"fn": logic.and_op, "arity": {2: [["Any"], ["Any"]]}},
    "xor": {"fn": logic.xor_op, "arity": {2: [["Any"], ["Any"]]}},
    "implies": {"fn": logic.implies_op, "arity": {2: [["Any"], ["Any"]]}},
    # FP-02 EXPLORER QA-001 (2026-08-16): sum/min/max/avg are NOT FHIRPath
    # N1/R4 functions (verified against the full hl7.org/fhirpath/N1
    # function list). The native extension treats them as unknown functions
    # (-> empty/NULL at the UDF boundary), and fhirpath_is_valid rejects
    # them on both surfaces. The legacy fhirpathpy-lineage registry entries
    # made the Python fallback silently evaluate expressions its own
    # validator rejects ({}.sum() -> 0 even violates the spec-wide
    # empty-input convention). The public direct-helper API in
    # fhir4ds/fhirpath/duckdb/functions/math.py is unaffected.
    "aggregate": {"fn": aggregate.aggregate_macro, "arity": {1: ["Expr"], 2: ["Expr", "Any"]}},
    "convertsToBoolean": {"fn": misc.create_converts_to_fn(misc.to_boolean, 'bool'), "arity": {0: []}},
    "convertsToInteger": {"fn": misc.create_converts_to_fn(misc.to_integer, 'int'), "arity": {0: []}},
    "convertsToDecimal": {"fn": misc.create_converts_to_fn(misc.to_decimal, Decimal), "arity": {0: []}},
    "convertsToString": {"fn": misc.create_converts_to_fn(misc.to_string, 'str'), "arity": {0: []}},
    "convertsToDate": {"fn": misc.converts_to_date, "arity": {0: [], 1: ["String"]}},
    "convertsToDateTime": {"fn": misc.converts_to_date_time, "arity": {0: [], 1: ["String"]}},
    "convertsToTime": {"fn": misc.create_converts_to_fn(misc.to_time, FP_Time), "arity": {0: []}},
    "convertsToQuantity": {"fn": misc.converts_to_quantity, "arity": {0: [], 1: ["String"]}},
    "conformsTo": {"fn": misc.conforms_to, "arity": {1: ["String"]}},
}
