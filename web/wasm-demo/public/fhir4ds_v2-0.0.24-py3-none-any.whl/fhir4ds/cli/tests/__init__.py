"""CLI tests."""

