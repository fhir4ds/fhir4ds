"""Tests for sqlonfhirpy package."""
